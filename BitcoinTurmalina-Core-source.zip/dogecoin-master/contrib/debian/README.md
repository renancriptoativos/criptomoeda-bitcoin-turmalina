
Debian
====================
This directory contains files used to package bitcointurmalinad/bitcointurmalina-qt
for Debian-based Linux systems. If you compile bitcointurmalinad/bitcointurmalina-qt yourself, there are some useful files here.

## dogecoin: URI support ##


bitcointurmalina-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install bitcointurmalina-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your bitcointurmalina-qt binary to `/usr/bin`
and the `../../share/pixmaps/dogecoin128.png` to `/usr/share/pixmaps`

bitcointurmalina-qt.protocol (KDE)

