Sample configuration files for:

SystemD: bitcointurmalinad.service
Upstart: bitcointurmalinad.conf
OpenRC:  bitcointurmalinad.openrc
         bitcointurmalinad.openrcconf
CentOS:  bitcointurmalinad.init
OS X:    org.dogecoin.bitcointurmalinad.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
