<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>AddPeerDialog</name>
    <message>
        <source>Add Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Rechtsklick zum Bearbeiten der Adresse oder der Bezeichnung</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Eine neue Adresse erstellen</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Neu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Ausgewählte Adresse in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ausgewählte Adresse aus der Liste entfernen</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>E&amp;xportieren</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Wählen Sie die Adresse aus, an die Sie Bitcoin Turmalinas überweisen möchten</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Wählen Sie die Adresse aus, über die Sie Bitcoin Turmalinas empfangen wollen</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Auswählen</translation>
    </message>
    <message>
        <source>Such sending addresses</source>
        <translation>Zahlungsadressen</translation>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation>Empfangsadressen</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Dies sind ihre Bitcoin Turmalina-Adressen zum Tätigen von Überweisungen. Bitte prüfen Sie den Betrag und die Empfangsadresse, bevor Sie Bitcoin Turmalinas überweisen.</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dies sind Ihre Bitcoin Turmalina-Adressen zum Empfangen von Zahlungen. Es wird empfohlen, für jede Transaktion eine neue Empfangsadresse zu verwenden.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>Adresse &amp;kopieren</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>&amp;Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>B&amp;earbeiten</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Addressliste exportieren</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Beim Speichern der Adressliste nach %1 ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Passphrasendialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Passphrase eingeben</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Neue Passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Neue Passphrase bestätigen</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Geben Sie die neue Passphrase für die Brieftasche ein.&lt;br&gt;Bitte benutzen Sie eine Passphrase bestehend aus &lt;b&gt;zehn oder mehr zufälligen Zeichen&lt;/b&gt; oder &lt;b&gt;acht oder mehr Wörtern&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Wallet verschlüsseln</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Dieser Vorgang benötigt ihre Passphrase, um die Brieftasche zu entsperren.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Wallet entsperren</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Dieser Vorgang benötigt Ihre Passphrase, um die Brieftasche zu entschlüsseln.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Brieftasche entschlüsseln</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Passphrase ändern</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Geben Sie die alte und neue Brieftschen-Passphrase ein.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Brieftaschen-Verschlüsselung bestätigen</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DOGECOINS&lt;/b&gt;!</source>
        <translation>Warnung: Wenn Sie Ihre Brieftasche verschlüsseln und Ihre Passphrase verlieren, werden Sie &lt;b&gt;alle Ihre Bitcoin Turmalinas verlieren&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Sind Sie sich sicher, dass Sie Ihre Brieftasche verschlüsseln möchten?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Brieftasche verschlüsselt</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your dogecoins from being stolen by malware infecting your computer.</source>
        <translation>%1 wird jetzt beendet, um den Verschlüsselungsprozess abzuschließen. Bitte beachten Sie, dass die Brieftaschen-Verschlüsselung nicht vollständig vor Diebstahl Ihrer Bitcoin Turmalinas durch Schadprogramme schützt, die Ihren Computer befällt.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>WICHTIG: Alle vorherigen Brieftaschen-Sicherungen sollten durch die neu erzeugte, verschlüsselte Brieftasche ersetzt werden. Aus Sicherheitsgründen werden vorherige Sicherungen der unverschlüsselten Brieftasche nutzlos, sobald Sie die neue, verschlüsselte Brieftasche verwenden.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Brieftaschen-Verschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Die Brieftaschen-Verschlüsselung ist aufgrund eines internen Fehlers fehlgeschlagen. Ihre Brieftasche wurde nicht verschlüsselt.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Die eingegebenen Passphrasen stimmen nicht überein.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Brieftaschen-Entsperrung fehlgeschlagen</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Die eingegebene Passphrase zur Brieftaschen-Entschlüsselung war nicht korrekt.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Brieftaschen-Entschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Die Brieftaschen-Passphrase wurde erfolgreich geändert.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Warnung: Die Feststelltaste ist aktiviert!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/Netzmaske</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Gesperrt bis</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Nachricht s&amp;ignieren...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronisiere mit Netzwerk...</translation>
    </message>
    <message>
        <source>&amp;Wow</source>
        <translation>&amp;Übersicht</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Knoten</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Allgemeine Wallet-Übersicht anzeigen</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktionen</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Transaktionsverlauf durchsehen</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Informationen über %1 anzeigen</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Über &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Informationen über Qt anzeigen</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Konfiguration...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Konfiguration von %1 bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Wallet &amp;verschlüsseln...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Wallet &amp;sichern...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Passphrase &amp;ändern...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;URI öffnen...</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Klicken zum Deaktivieren der Netzwerkaktivität.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Netzwerkaktivität deaktiviert.</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Klicken zum Aktivieren der Netzwerkaktivität.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Kopfdaten werden synchronisiert (%1%)...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Reindiziere Blöcke auf Datenträger...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin Turmalina address</source>
        <translation>Bitcoin Turmalinas an eine Bitcoin Turmalina-Adresse überweisen</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Eine Wallet-Sicherungskopie erstellen und abspeichern</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Ändert die Passphrase, die für die Wallet-Verschlüsselung benutzt wird</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Debugfenster</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Debugging- und Diagnosekonsole öffnen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Nachricht &amp;verifizieren...</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina</source>
        <translation>Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <source>&amp;Such Send</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>&amp;Much Receive</source>
        <translation>&amp;Empfangen</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Anzeigen / Verstecken</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Das Hauptfenster anzeigen oder verstecken</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Verschlüsselt die zu Ihrer Wallet gehörenden privaten Schlüssel</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin Turmalina addresses to prove you own them</source>
        <translation>Nachrichten signieren, um den Besitz Ihrer Bitcoin Turmalina-Adressen zu beweisen</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin Turmalina addresses</source>
        <translation>Nachrichten verifizieren, um sicherzustellen, dass diese mit den angegebenen Bitcoin Turmalina-Adressen signiert wurden</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Registerkartenleiste</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and dogecoin: URIs)</source>
        <translation>Zahlungen anfordern (erzeugt QR-Codes und &quot;dogecoin:&quot;-URIs)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Liste verwendeter Zahlungsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Liste verwendeter Empfangsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>Open a dogecoin: URI or payment request</source>
        <translation>Eine &quot;dogecoin:&quot;-URI oder Zahlungsanforderung öffnen</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Kommandozeilenoptionen</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin Turmalina network</source>
        <translation>
            <numerusform>%n aktive Verbindung zum Bitcoin Turmalina-Netzwerk</numerusform>
            <numerusform>%n aktive Verbindungen zum Bitcoin Turmalina-Netzwerk</numerusform>
        </translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Indiziere Blöcke auf Datenträger...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Verarbeite Blöcke auf Datenträger...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>%n Block des Transaktionsverlaufs verarbeitet.</numerusform>
            <numerusform>%n Blöcke des Transaktionsverlaufs verarbeitet.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 im Rückstand</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Der letzte empfangene Block ist %1 alt.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktionen hiernach werden noch nicht angezeigt.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Auf aktuellem Stand</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin Turmalina command-line options</source>
        <translation>Zeige den &quot;%1&quot;-Hilfetext, um eine Liste mit möglichen Kommandozeilenoptionen zu erhalten</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1 Client</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Verbinde mit Netzwerk...</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Hole auf...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Datum: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Betrag: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Typ: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Bezeichnung: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Adresse: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Gesendete Transaktion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Eingehende Transaktion</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation>HD Schlüssel Generierung ist &lt;b&gt;aktiviert&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>HD Schlüssel Generierung ist &lt;b&gt;deaktiviert&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;entsperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;gesperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Bitcoin Turmalina can no longer continue safely and will quit.</source>
        <translation>Ein schwerer Fehler ist aufgetreten. Bitcoin Turmalina kann nicht stabil weiter ausgeführt werden und wird beendet.</translation>
    </message>
    <message>
        <source>&amp;Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Such sending addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Much receiving addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import a Bitcoin Turmalina private key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Münzauswahl (&quot;Coin Control&quot;)</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>&quot;Dust&quot;:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>Alles (de)selektieren</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Baumansicht</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listenansicht</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Empfangen über Bezeichnung</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Empfangen über Adresse</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bestätigungen</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktions-ID kopieren</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Nicht ausgegebenen Betrag sperren</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Nicht ausgegebenen Betrag entsperren</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Bytes kopieren</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>&quot;Staub&quot; kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 gesperrt)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nein</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation>Diese Bezeichnung wird rot, wenn irgendein Empfänger einen Betrag kleiner als die derzeitige &quot;Staubgrenze&quot; erhält.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu(s) per input.</source>
        <translation type="vanished">Kann pro Eingabe um +/- %1 Koinu(s) abweichen.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>Wechselgeld von %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(Wechselgeld)</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu per input.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Adresse bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Bezeichnung</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Bezeichnung, die dem Adresslisteneintrag zugeordnet ist.</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adresse, die dem Adresslisteneintrag zugeordnet ist. Diese kann nur bei Zahlungsadressen verändert werden.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Neue Empfangsadresse</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Neue Zahlungsadresse</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Empfangsadresse bearbeiten</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Zahlungsadresse bearbeiten</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Bitcoin Turmalina address.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; ist keine gültige Bitcoin Turmalina-Adresse.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; befindet sich bereits im Adressbuch.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Brieftasche konnte nicht entsperrt werden.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Erzeugung eines neuen Schlüssels fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Es wird ein neues Datenverzeichnis angelegt.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Verzeichnis existiert bereits. Fügen Sie %1 an, wenn Sie beabsichtigen hier ein neues Verzeichnis anzulegen.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Pfad existiert bereits und ist kein Verzeichnis.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Datenverzeichnis kann hier nicht angelegt werden.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-Bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Benutzung:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>UI Einstellungen:</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Datenverzeichnis beim Starten auswählen (Standard: %u)</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Sprache einstellen, zum Beispiel &quot;de_DE&quot; (Standard: Systemgebietsschema)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Minimiert starten</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>SSL-Wurzelzertifikate für Zahlungsanforderungen festlegen (Standard: Systemstandard)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Startbildschirm beim Starten anzeigen (Standard: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Setze alle Einstellungen zurück, die über die grafische Oberfläche geändert wurden.</translation>
    </message>
</context>
<context>
    <name>ImportKeysDialog</name>
    <message>
        <source>Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private key to import into your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label for this private key in your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label (optional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">A&amp;bbrechen</translation>
    </message>
    <message>
        <source>Invalid private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid address generated from private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to add private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation type="unfinished">Durchsuche erneut...</translation>
    </message>
    <message>
        <source>Reset this form.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Willkommen</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Willkommen zu %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>Da Sie das Programm gerade zum ersten Mal starten, können Sie nun auswählen wo %1 seine Daten ablegen wird.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Bitcoin Turmalina block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 wird eine Kopie der Blockkette herunterladen und speichern. Mindestens %2GB Daten werden in diesem Verzeichnis abgelegt und die Datenmenge wächst über die Zeit an. Auch die Wallet wird in diesem Verzeichnis abgelegt.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Standard-Datenverzeichnis verwenden</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Ein benutzerdefiniertes Datenverzeichnis verwenden:</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation>Fehler: Angegebenes Datenverzeichnis &quot;%1&quot; kann nicht angelegt werden.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation>
            <numerusform>%n GB freier Speicherplatz verfügbar</numerusform>
            <numerusform>%n GB freier Speicherplatz verfügbar</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation>
            <numerusform>(von benötigtem %n GB)</numerusform>
            <numerusform>(von benötigten %n GB)</numerusform>
        </translation>
    </message>
    <message>
        <source>Choose data directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet&apos;s balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the dogecoin network, as detailed below.</source>
        <translation>Neueste Transaktionen werden eventuell noch nicht angezeigt, daher könnte Ihr Kontostand veraltet sein. Er wird korrigiert, sobald Ihr Wallet die Synchronisation mit dem Bitcoin Turmalina-Netzwerk erfolgreich abgeschlossen hat. Details dazu finden sich weiter unten.</translation>
    </message>
    <message>
        <source>Attempting to spend dogecoins that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation>Versuche, Bitcoin Turmalinas aus noch nicht angezeigten Transaktionen auszugeben, werden vom Netzwerk nicht akzeptiert.</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>Anzahl verbleibender Blöcke</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Unbekannt...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Letzte Blockzeit</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Fortschritt</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation>Fortschritt pro Stunde</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>berechne...</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>Abschätzung der verbleibenden Zeit bis synchronisiert</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ausblenden</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1)...</source>
        <translation>Unbekannt. Synchronisiere Headers (%1)...</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI öffnen</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Zahlungsanforderung über URI oder aus Datei öffnen</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Zahlungsanforderungsdatei auswählen</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Zu öffnende Zahlungsanforderungsdatei auswählen</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Allgemein</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>%1 nach der Anmeldung am System automatisch ausführen.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>&amp;Starte %1 nach Systemanmeldung</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Größe des &amp;Datenbankcaches</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Anzahl an Skript-&amp;Verifizierungs-Threads</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Eingehende Verbindungen annehmen</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Erlaubt eingehende Verbindungen</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-Adresse des Proxies (z.B. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Minimiert die Anwendung anstatt sie zu beenden wenn das Fenster geschlossen wird. Wenn dies aktiviert ist, müssen Sie die Anwendung über &quot;Beenden&quot; im Menü schließen.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Externe URLs (z.B. ein Block-Explorer), die im Kontextmenü des Transaktionsverlaufs eingefügt werden. In der URL wird %s durch den Transaktionshash ersetzt. Bei Angabe mehrerer URLs müssen diese durch &quot;|&quot; voneinander getrennt werden.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Externe Transaktions-URLs</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktive Kommandozeilenoptionen, die obige Konfiguration überschreiben:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Setzt die Clientkonfiguration auf Standardwerte zurück.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>Konfiguration &amp;zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Netzwerk</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = automatisch, &lt;0 = so viele Kerne frei lassen)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>W&amp;allet</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Erweiterte Wallet-Optionen</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>&quot;&amp;Coin Control&quot;-Funktionen aktivieren</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Wenn Sie das Ausgeben von unbestätigtem Wechselgeld deaktivieren, kann das Wechselgeld einer Transaktion nicht verwendet werden, bis es mindestens eine Bestätigung erhalten hat. Dies wirkt sich auf die Berechnung des Kontostands aus.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Unbestätigtes Wechselgeld darf ausgegeben werden</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin Turmalina client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatisch den Bitcoin Turmalina-Clientport auf dem Router öffnen. Dies funktioniert nur, wenn Ihr Router UPnP unterstützt und dies aktiviert ist.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Portweiterleitung via &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a SOCKS5 proxy.</source>
        <translation>Über einen SOCKS5-Proxy mit dem Bitcoin Turmalina-Netzwerk verbinden.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>Über einen SOCKS5-Proxy &amp;verbinden (Standardproxy):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-&amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port des Proxies (z.B. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Benutzt um Gegenstellen zu erreichen über:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Zeigt an, ob der eingegebene Standard SOCKS5 Proxy genutzt wird um Peers mit dem Netzwerktyp zu erreichen.</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Über einen separaten SOCKS5 Proxy für Tor Services mit dem Dogecoint Netzwerk verbinden.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>Separaten SOCKS5-Proxy verwenden, um Gegenstellen über versteckte Tor-Dienste zu erreichen:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Programmfenster</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>&amp;Das Icon im System Tray verstecken.</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>Tray Icon verstecken</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Nur ein Symbol im Infobereich anzeigen, nachdem das Programmfenster minimiert wurde.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>In den Infobereich anstatt in die Taskleiste &amp;minimieren</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Beim Schließen m&amp;inimieren</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>Anzei&amp;ge</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Sprache der Benutzeroberfläche:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>Die Benutzeroberflächensprache kann hier festgelegt werden. Diese Einstellung wird nach einem Neustart von %1 wirksam werden.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Einheit der Beträge:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Wählen Sie die standardmäßige Untereinheit, die in der Benutzeroberfläche und beim Überweisen von Bitcoin Turmalinas angezeigt werden soll.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Legt fest, ob die &quot;Coin Control&quot;-Funktionen angezeigt werden.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>A&amp;bbrechen</translation>
    </message>
    <message>
        <source>default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>keine</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Zurücksetzen der Konfiguration bestätigen</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Clientneustart nötig, um die Änderungen zu aktivieren.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Client wird beendet. Möchten Sie den Vorgang fortsetzen?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Diese Änderung würde einen Clientneustart benötigen.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Die eingegebene Proxyadresse ist ungültig.</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin Turmalina network after a connection is established, but this process has not completed yet.</source>
        <translation>Die angezeigten Informationen sind möglicherweise nicht mehr aktuell. Ihre Wallet wird automatisch synchronisiert, nachdem eine Verbindung zum Bitcoin Turmalina-Netzwerk hergestellt wurde. Dieser Prozess ist jedoch derzeit noch nicht abgeschlossen.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Beobachtet:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Verfügbar:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ihr aktuell verfügbarer Kontostand</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Ausstehend:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Betrag aus unbestätigten Transaktionen, der noch nicht im aktuell verfügbaren Kontostand enthalten ist</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Unreif:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Erarbeiteter Betrag der noch nicht gereift ist</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Kontostände</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Gesamtbetrag:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Aktueller Gesamtbetrag aus obigen Kategorien</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Ihr aktueller Kontostand beobachteter Adressen</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Verfügbar:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Letzte Transaktionen</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Unbestätigte Transaktionen von beobachteten Adressen</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Erarbeiteter Betrag in beobachteten Adressen der noch nicht gereift ist</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Aktueller Gesamtbetrag in beobachteten Adressen aus obigen Kategorien</translation>
    </message>
    <message>
        <source>Helpful tip of the day:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encrypt your wallet with a strong passphrase for maximum security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backup your private key to recover your coins, using &apos;File&apos; &gt; &apos;Backup Wallet&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always do your own research before using an external cryptocurrency service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services that claim to double your dogecoins are always ponzi schemes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your wallet.dat file with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For advanced operations, use the console in &apos;Help&apos; -&gt; &apos;Debug Window&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make sure to keep your wallet software updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your private key with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Who owns the private keys, owns the coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To see ongoing development and contribute, check out the Bitcoin Turmalina Core repository on GitHub</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaperWalletDialog</name>
    <message>
        <source>Print Your Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very New Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>So Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many Wallets?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Network Activity Detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is recommended to disconnect from the internet before printing paper wallets. Even though paper wallets are generated on your local computer, it is still possible to unknowingly have malware that transmits your screen to a remote location. It is also recommended to print to a local printer vs a network printer since that network traffic can be monitored. Some advanced printers also store copies of each printed document. Proceed with caution relative to the amount of value you plan to store on each address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding Address into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding private key into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>failed to open file, is it writable?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The paper wallet printing process has begun.&lt;br/&gt;Please wait for the wallets to print completely and verify that everything printed correctly.&lt;br/&gt;Check for misalignments, ink bleeding, smears, or anything else that could make the private keys unreadable.&lt;br/&gt;Now, enter the number of BTURM you wish to send to each wallet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper wallet %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Bitcoin Turmalinas überweisen</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0</source>
        <translation type="unfinished">Der zu zahlende Betrag muss größer als 0 sein. {0?}</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">Der angegebene Betrag übersteigt Ihren Kontostand.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the transaction fee is included</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">Transaktionserstellung fehlgeschlagen!</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished">Wollen Sie die Überweisung ausführen?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation type="unfinished">als Transaktionsgebühr hinzugefügt</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">oder</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">Überweisung bestätigen</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>fehlerhafte Zahlungsanforderung</translation>
    </message>
    <message>
        <source>Cannot start dogecoin: click-to-pay handler</source>
        <translation>Kann Bitcoin Turmalina nicht starten: Klicken-zum-Bezahlen-Handler</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>URI-Verarbeitung</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Abruf-URL der Zahlungsanforderung ist ungültig: %1</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Ungültige Zahlungsadresse %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Bitcoin Turmalina address or malformed URI parameters.</source>
        <translation>URI kann nicht analysiert werden! Dies kann durch eine ungültige Bitcoin Turmalina-Adresse oder fehlerhafte URI-Parameter verursacht werden.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Zahlungsanforderungsdatei-Verarbeitung</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Zahlungsanforderungsdatei kann nicht gelesen werden! Dies kann durch eine ungültige Zahlungsanforderungsdatei verursacht werden.</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Zahlungsanforderung abgelehnt</translation>
    </message>
    <message>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation>Netzwerk der Zahlungsanforderung stimmt nicht mit dem Client-Netzwerk überein.</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Zahlungsanforderung abgelaufen.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>Zahlungsanforderung ist nicht initialisiert.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Unverifizierte Zahlungsanforderungen an benutzerdefinierte Zahlungsskripte werden nicht unterstützt.</translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation>Ungültige Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Rücküberweisung von %1</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>Zahlungsanforderung %1 ist zu groß (%2 Byte, erlaubt sind %3 Byte).</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Kommunikationsfehler mit %1: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>Zahlungsanforderung kann nicht verarbeitet werden!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Fehlerhafte Antwort vom Server: %1</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>fehlerhafte Netzwerkanfrage</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Zahlung bestätigt</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (below discard threshold).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BIP70 payment requests are deprecated and disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request file handling is disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>User-Agent</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Knoten/Dienst</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation>Knoten Identität</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTools</name>
    <message>
        <source>Error: Peer-to-peer functionality missing or disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to one try node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node not found in connected nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnected the node: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Returned OK.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Node address is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Unable to add node</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Enter a Bitcoin Turmalina address (e.g. %1)</source>
        <translation>Bitcoin Turmalina-Adresse eingeben (z.B. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Keine</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n Sekunde</numerusform>
            <numerusform>%n Sekunde(n)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n Minute</numerusform>
            <numerusform>%n Minute(n)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation>
            <numerusform>%n Stunde</numerusform>
            <numerusform>%n Stunden</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation>
            <numerusform>%n Tag</numerusform>
            <numerusform>%n Tage</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation>
            <numerusform>%n Woche</numerusform>
            <numerusform>%n Wochen</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 und %2</translation>
    </message>
    <message>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation>%1 wurde noch nicht sicher beendet...</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation type="unfinished">%1 B</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation type="obsolete">%1 GB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation type="obsolete">%1 KB</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>Fehler: Angegebenes Datenverzeichnis &quot;%1&quot; existiert nicht.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>Fehler: Konfigurationsdatei kann nicht analysiert werden: %1. Bitte nur &quot;Schlüssel=Wert&quot;-Syntax verwenden.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Fehler: %1</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>Grafik &amp;kopieren</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR-Code speichern</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG-Grafik (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Clientversion</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Debugfenster</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Verwendete BerkeleyDB-Version</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Datenverzeichnis</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Startzeit</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netzwerk</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Anzahl Verbindungen</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blockkette</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktuelle Anzahl Blöcke</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Speicherpool</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Aktuelle Anzahl der Transaktionen</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Speichernutzung</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Empfangen</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Übertragen</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Gegenstellen</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Gesperrte Peers</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Gegenstelle auswählen, um detaillierte Informationen zu erhalten.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Zugelassene</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Richtung</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Start Block</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Synchronisierte Kopfdaten</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Synchronisierte Blöcke</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>User-Agent</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Öffnet die %1-Debugprotokolldatei aus dem aktuellen Datenverzeichnis. Dies kann bei großen Protokolldateien einige Sekunden dauern.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Schrift verkleinern</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Schrift vergrößern</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Dienste</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Sperrpunktzahl</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Verbindungsdauer</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Letzte Übertragung</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Letzter Empfang</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Pingzeit</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>Die Laufzeit eines aktuell ausstehenden Ping.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Ping Wartezeit</translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation>Minimaler Ping</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Zeitversatz</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Letzte Blockzeit</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsole</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Netzwerkauslastung</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Gesamtbetrag:</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>eingehend:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>ausgehend:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debugprotokolldatei</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Konsole zurücksetzen</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;Stunde</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;Tag</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;Woche</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;Jahr</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>&amp;Trennen</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>Banne für</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>&amp;Node entsperren</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Willkommen in der %1 RPC Konsole.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Pfeiltaste hoch und runter, um den Verlauf durchzublättern und &lt;b&gt;Strg-L&lt;/b&gt;, um die Konsole zurückzusetzen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Bitte &lt;b&gt;help&lt;/b&gt; eingeben, um eine Übersicht verfügbarer Befehle zu erhalten.</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramification of a command.</source>
        <translation>WARNUNG: Betrüger versuchen aktiv Nutzer dazu zu bringen Kommandos hier auszuführen um die Wallet Inhalte zu stehlen. Diese Konsole sollte nicht benutzt werden ausser man kennt die möglichen Folgen des Kommandos.</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation>Netzwerkaktivität deaktiviert</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(Knotenkennung: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>über %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>nie</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>eingehend</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>ausgehend</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <source>Connected peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One try peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fehler</translation>
    </message>
    <message>
        <source>Remove Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the peer: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No peer was selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Betrag:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Nachricht:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Eine der bereits verwendeten Empfangsadressen wiederverwenden. Addressen wiederzuverwenden birgt Sicherheits- und Datenschutzrisiken. Außer zum Neuerstellen einer bereits erzeugten Zahlungsanforderung sollten Sie dies nicht nutzen.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>Vorhandene Empfangsadresse &amp;wiederverwenden (nicht empfohlen)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin Turmalina network.</source>
        <translation>Eine optionale Nachricht, die an die Zahlungsanforderung angehängt wird. Sie wird angezeigt, wenn die Anforderung geöffnet wird. Hinweis: Diese Nachricht wird nicht mit der Zahlung über das Bitcoin Turmalina-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Eine optionale Bezeichnung, die der neuen Empfangsadresse zugeordnet wird.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Verwenden Sie dieses Formular, um Zahlungen anzufordern. Alle Felder sind &lt;b&gt;optional&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Ein optional angeforderte Betrag. Lassen Sie dieses Feld leer oder setzen Sie es auf 0, um keinen spezifischen Betrag anzufordern.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Verlauf der angeforderten Zahlungen</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Zahlung anfordern</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Ausgewählte Zahlungsanforderungen anzeigen (entspricht einem Doppelklick auf einen Eintrag)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Ausgewählte Einträge aus der Liste entfernen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>&amp;URI kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Nachricht kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-Code</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>&amp;URI kopieren</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Addresse kopieren</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Zahlung anfordern an %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Zahlungsinformationen</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resultierende URI ist zu lang, bitte den Text für Bezeichnung/Nachricht kürzen.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Beim Enkodieren der URI in den QR-Code ist ein Fehler aufgetreten.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(keine Nachricht)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(kein Betrag angefordert)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>Angefordert</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Bitcoin Turmalinas überweisen</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>&quot;Coin Control&quot;-Funktionen</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Eingaben...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automatisch ausgewählt</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Unzureichender Kontostand!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Wenn dies aktivert, und die Wechselgeld-Adresse leer oder ungültig ist, wird das Wechselgeld einer neu erzeugten Adresse gutgeschrieben.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Benutzerdefinierte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transaktionsgebühr:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Auswählen...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>Transaktionsgebühreneinstellungen ausblenden</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>pro Kilobyte</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ausblenden</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>Mindestbetrag</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for dogecoin transactions than the network can process.</source>
        <translation>Nur die minimale Gebühr zu bezahlen ist so lange in Ordnung, wie weniger Transaktionsvolumen als Platz in den Blöcken vorhanden ist. Aber Vorsicht, diese Option kann dazu führen, dass Transaktionen nicht bestätigt werden, wenn mehr Bedarf an Bitcoin Turmalina-Transaktionen besteht als das Netzwerk verarbeiten kann.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(den Hinweistext lesen)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Empfehlungen:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Benutzerdefiniert:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>An mehrere Empfänger auf einmal überweisen</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Empfänger &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>&quot;Dust&quot;:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Kontostand:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Byte kopieren</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>&quot;Staub&quot; kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 an %2</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Wollen Sie die Überweisung ausführen?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>als Transaktionsgebühr hinzugefügt</translation>
    </message>
    <message>
        <source>Total Amount %1</source>
        <translation>Gesamtbetrag %1</translation>
    </message>
    <message>
        <source>or</source>
        <translation>oder</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation>Die Zahlungsadresse ist ungültig, bitte nochmals überprüfen.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Der zu zahlende Betrag muss größer als 0 sein.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Der angegebene Betrag übersteigt Ihren Kontostand.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Der angegebene Betrag übersteigt aufgrund der Transaktionsgebühr in Höhe von %1 Ihren Kontostand.</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation>Doppelte Adresse entdeckt: Adressen dürfen jeweils nur einmal vorkommen.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Transaktionserstellung fehlgeschlagen!</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>Die Transaktion wurde aus folgendem Grund abgelehnt: %1</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>Eine höhere Gebühr als %1 wird als unsinnig hohe Gebühr angesehen.</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Zahlungsanforderung abgelaufen.</translation>
    </message>
    <message>
        <source>Pay only the required fee of %1</source>
        <translation>Nur die notwendige Gebühr in Höhe von %1 zahlen</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin Turmalina address</source>
        <translation>Warnung: Ungültige Bitcoin Turmalina-Adresse</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Warnung: Unbekannte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation>Bestätige benutzerdefinierte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>Die ausgewählte Wechselgeld-Adresse ist nicht Bestandteil dieses Wallets. Einige oder alle Mittel aus Ihrem Wallet könnten an diese Adresse gesendet werden. Wollen Sie das wirklich?</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 satoshis in fee, while &quot;total at least&quot; pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 koinu and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 koinu in fee, while &quot;total at least&quot; pays 1000 koinu. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Betra&amp;g:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>E&amp;mpfänger:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Dies ist eine normale Überweisung.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to send the payment to</source>
        <translation>Die Zahlungsadresse der Überweisung</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Diesen Eintrag entfernen</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less dogecoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>Die Gebühr wird vom zu überweisenden Betrag abgezogen. Der Empfänger wird also weniger Bitcoin Turmalinas erhalten, als Sie im Betrags-Feld eingegeben haben. Falls mehrere Empfänger ausgewählt wurden, wird die Gebühr gleichmäßig verteilt.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>Gebühr vom Betrag ab&amp;ziehen</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>Dies ist keine beglaubigte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>Dies ist eine beglaubigte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Adressbezeichnung eingeben, die dann zusammen mit der Adresse der Liste bereits verwendeter Adressen hinzugefügt wird.</translation>
    </message>
    <message>
        <source>A message that was attached to the dogecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin Turmalina network.</source>
        <translation>Eine an die &quot;dogecoin:&quot;-URI angefügte Nachricht, die zusammen mit der Transaktion gespeichert wird. Hinweis: Diese Nachricht wird nicht über das Bitcoin Turmalina-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Empfänger:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Geben Sie eine Bezeichnung für diese Adresse ein, um sie zu Ihrem Adressbuch hinzuzufügen</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 wird beendet...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Fahren Sie den Computer nicht herunter, bevor dieses Fenster verschwindet.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signaturen - eine Nachricht signieren / verifizieren</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Nachricht &amp;signieren</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive dogecoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Sie können Nachrichten/Vereinbarungen mit Hilfe Ihrer Adressen signieren, um zu beweisen, dass Sie Bitcoin Turmalinas empfangen können, die an diese Adressen überwiesen werden. Seien Sie vorsichtig und signieren Sie nichts Vages oder Willkürliches, um Ihre Indentität vor Phishingangriffen zu schützen. Signieren Sie nur vollständig-detaillierte Aussagen, mit denen Sie auch einverstanden sind.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to sign the message with</source>
        <translation>Die Bitcoin Turmalina-Adresse mit der die Nachricht signiert wird</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Zu signierende Nachricht hier eingeben</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Aktuelle Signatur in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin Turmalina address</source>
        <translation>Die Nachricht signieren, um den Besitz dieser Bitcoin Turmalina-Adresse zu beweisen</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;Nachricht signieren</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Alle &quot;Nachricht signieren&quot;-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>Nachricht &amp;verifizieren</translation>
    </message>
    <message>
        <source>Enter the receiver&apos;s address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Geben Sie die Zahlungsadresse des Empfängers, Nachricht (achten Sie darauf Zeilenumbrüche, Leerzeichen, Tabulatoren usw. exakt zu kopieren) und Signatur unten ein, um die Nachricht zu verifizieren. Vorsicht, interpretieren Sie nicht mehr in die Signatur hinein, als in der signierten Nachricht selber enthalten ist, um nicht von einem Man-in-the-middle-Angriff hinters Licht geführt zu werden. Beachten Sie dass dies nur beweißt, dass die signierende Partei über diese Adresse Überweisungen empfangen kann.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address the message was signed with</source>
        <translation>Die Bitcoin Turmalina-Adresse mit der die Nachricht signiert wurde</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin Turmalina address</source>
        <translation>Die Nachricht verifizieren, um sicherzustellen, dass diese mit der angegebenen Bitcoin Turmalina-Adresse signiert wurde</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;Nachricht verifizieren</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Alle &quot;Nachricht verifizieren&quot;-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Auf &quot;Nachricht signieren&quot; klicken, um die Signatur zu erzeugen</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Die eingegebene Adresse ist ungültig.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Bitte überprüfen Sie die Adresse und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Die eingegebene Adresse verweist nicht auf einen Schlüssel.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Wallet-Entsperrung wurde abgebrochen.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Privater Schlüssel zur eingegebenen Adresse ist nicht verfügbar.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Signierung der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Nachricht signiert.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Die Signatur konnte nicht dekodiert werden.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Bitte überprüfen Sie die Signatur und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Die Signatur entspricht nicht dem &quot;Message Digest&quot;.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verifikation der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Nachricht verifiziert.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[Testnetz]</translation>
    </message>
</context>
<context>
    <name>TestPeerDialog</name>
    <message>
        <source>Test Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Peer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>Offen für %n weiteren Block</numerusform>
            <numerusform>Offen für %n weitere Blöcke</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation>steht im Konflikt mit einer Transaktion mit %1 Bestätigungen</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation type="vanished">%1/offline</translation>
    </message>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation>%1/unbestätigt</translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation>im Speicherpool</translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation>nicht im Speicherpool</translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation>eingestellt</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/unbestätigt</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 Bestätigungen</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation type="vanished">, wurde noch nicht erfolgreich übertragen</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation type="vanished">
            <numerusform>, über %n Knoten übertragen</numerusform>
            <numerusform>, über %n Knoten übertragen</numerusform>
        </translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Quelle</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Erzeugt</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Von</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <source>To</source>
        <translation>An</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>eigene Adresse</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>beobachtet</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Gutschrift</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>reift noch %n weiteren Block</numerusform>
            <numerusform>reift noch %n weitere Blöcke</numerusform>
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>nicht angenommen</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Belastung</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Gesamtbelastung</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Gesamtgutschrift</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Transaktionsgebühr</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettobetrag</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Transaktionskennung</translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation>Gesamte Transaktionsgröße</translation>
    </message>
    <message>
        <source>Output index</source>
        <translation>Ausgabeindex</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Händler</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Erzeugte Bitcoin Turmalinas müssen %1 Blöcke lang reifen, bevor sie ausgegeben werden können. Als Sie diesen Block erzeugten, wurde er an das Netzwerk übertragen, um ihn der Blockkette hinzuzufügen. Falls dies fehlschlägt wird der Status in &quot;nicht angenommen&quot; geändert und Sie werden keine Bitcoin Turmalinas gutgeschrieben bekommen. Das kann gelegentlich passieren, wenn ein anderer Knoten einen Block fast zeitgleich erzeugt.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Debuginformationen</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Eingaben</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>true</source>
        <translation>wahr</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falsch</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Dieser Bereich zeigt eine detaillierte Beschreibung der Transaktion an</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation>Details für %1</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>Offen für %n weiteren Block</numerusform>
            <numerusform>Offen für %n weitere Blöcke</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation type="vanished">Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Unbestätigt</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation>Eingestellt</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Wird bestätigt (%1 von %2 empfohlenen Bestätigungen)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bestätigt (%1 Bestätigungen)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>in Konflikt stehend</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Unreif (%1 Bestätigungen, wird verfügbar sein nach %2)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation type="vanished">Dieser Block wurde vom Netzwerk nicht angenommen und wird wahrscheinlich nicht bestätigt werden!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generiert, aber nicht akzeptiert</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Empfangen von</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>beobachtet</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(k.A.)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus. Fahren Sie mit der Maus über dieses Feld, um die Anzahl der Bestätigungen zu sehen.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum und Zeit als die Transaktion empfangen wurde.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Art der Transaktion</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Zeigt an, ob eine beobachtete Adresse in diese Transaktion involviert ist.</translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation>Benutzerdefinierte Absicht bzw. Verwendungszweck der Transaktion</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Der Betrag, der dem Kontostand abgezogen oder hinzugefügt wurde.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Diese Woche</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Diesen Monat</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Letzten Monat</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Dieses Jahr</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Zeitraum...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andere</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Zu suchende Adresse oder Bezeichnung eingeben</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Mindestbetrag</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>Transaktion einstellen</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktionskennung kopieren</translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation>Rohe Transaktion kopieren</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>Vollständige Transaktionsdetails kopieren</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Bezeichnung bearbeiten</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Transaktionsdetails anzeigen</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Transaktionsverlauf exportieren</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Nur beobachten</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Beim Speichern des Transaktionsverlaufs nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Exportieren erfolgreich</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Speichern des Transaktionsverlaufs nach %1 war erfolgreich.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Zeitraum:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>bis</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Die Einheit in der Beträge angezeigt werden. Klicken, um eine andere Einheit auszuwählen.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Es wurde keine Wallet geladen.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Bitcoin Turmalinas überweisen</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>E&amp;xportieren</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Wallet sichern</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Wallet-Daten (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Sicherung fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Beim Speichern der Wallet-Daten nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Sicherung erfolgreich</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Speichern der Wallet-Daten nach %1 war erfolgreich.</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Optionen:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Datenverzeichnis festlegen</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Mit dem angegebenen Knoten verbinden, um Adressen von Gegenstellen abzufragen, danach trennen</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Die eigene öffentliche Adresse angeben</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Kommandozeilen- und JSON-RPC-Befehle annehmen</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect/-noconnect)</source>
        <translation>Eingehende Verbindungen annehmen (Standard: 1, wenn nicht -proxy oder -connect/-noconnect)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s); -noconnect or -connect=0 alone to disable automatic connections</source>
        <translation>Verbindungen nur zu spezifizierten Node(s); verwenden Sie -noconnect oder -connect=0 alleine um automatische Verbindungen zu deaktivieren</translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation>Veröffentlicht unter der MIT-Softwarelizenz, siehe beiligende Datei %s oder %s.</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>Wenn &lt;category&gt; nicht angegeben wird oder &lt;category&gt;=1, jegliche Debugginginformationen ausgeben.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>Kürzungsmodus wurde kleiner als das Minimum in Höhe von %d MiB konfiguriert. Bitte verwenden Sie einen größeren Wert.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Prune (Kürzung): Die letzte Syncronisation der Wallet liegt vor gekürzten (gelöschten) Blöcken. Es ist ein -reindex (download der gesamten Blockkette) notwendig.</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Rescans sind im pruned mode nicht möglich. Ein -reindex ist notwendig, welcher die gesmate Blockkette erneut herunterlädt.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Fehler: Ein schwerer interner Fehler ist aufgetreten, siehe debug.log für Details.</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>Gebühr (in %s/kB), die von Ihnen gesendeten Transaktionen hinzugefügt wird (Standard: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Kürze Blockspeicher...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Als Hintergrunddienst ausführen und Befehle annehmen</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Kann HTTP Server nicht starten. Siehe debug log für Details.</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina Core</source>
        <translation>Bitcoin Turmalina Core</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>Die %s-Entwickler</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>Eine Transaktionsgebühr (in %s/kB) wird genutzt, wenn für die Gebührenschützung zu wenig Daten vorliegen (Standardwert: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>Geben Sie immer die Transaktionen, die Sie von freigegebenen Peers erhalten haben, weiter (Voreinstellung: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>An die angegebene Adresse binden und immer abhören. Für IPv6 &quot;[Host]:Port&quot;-Notation verwenden</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Datenverzeichnis %s kann nicht gesperrt werden. Evtl. wurde %s bereits gestartet.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Alle Wallet-Transaktionen löschen und nur diese Teilbereiche der Blockkette durch -rescan beim Starten wiederherstellen</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Lesen von %s fehlgeschlagen! Alle Schlüssel wurden korrekt gelesen, Transaktionsdaten bzw. Adressbucheinträge fehlen aber möglicherweise oder sind inkorrekt.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation type="vanished">Befehl ausführen wenn sich eine Wallet-Transaktion verändert (%s im Befehl wird durch die Transaktions-ID ersetzt)</translation>
    </message>
    <message>
        <source>Extra transactions to keep in memory for compact block reconstructions (default: %u)</source>
        <translation>Zusätzliche Transaktionen für kompakten Block-Nachbau im Speicher vorhalten (default: %u)</translation>
    </message>
    <message>
        <source>If this block is in the chain assume that it and its ancestors are valid and potentially skip their script verification (0 to verify all, default: %s, testnet: %s)</source>
        <translation>Sofern dieser Block Bestandteil der Blockchain ist, nehme an das er und seine Vorgänger gültig sind und überspringe ggf. dessen Skriptverifikation (0 um alle zu verifizieren, default: %s, testnet: %s)</translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation>Maximale Gesamtgebühr (in %s) in einer Börsentransaktion; wird dies zu niedrig gesetzten können große Transaktionen abgebrochen werden (Standard: %s)</translation>
    </message>
    <message>
        <source>Please check that your computer&apos;s date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Bitte korrigieren Sie die Datums- und Uhrzeiteinstellungen Ihres Computers, da %s ansonsten nicht ordnungsgemäß funktionieren wird.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>Wenn sie %s nützlich finden, sind Helfer sehr gern gesehen. Besuchen Sie %s um mehr über das Softwareprojekt zu erfahren.</translation>
    </message>
    <message>
        <source>Reduce storage requirements by enabling pruning (deleting) of old blocks. This allows the pruneblockchain RPC to be called to delete specific blocks, and enables automatic pruning of old blocks if a target size in MiB is provided. This mode is incompatible with -txindex and -rescan. Warning: Reverting this setting requires re-downloading the entire blockchain. (default: 0 = disable pruning blocks, 1 = allow manual pruning via RPC, &gt;%u = automatically prune block files to stay under the specified target size in MiB)</source>
        <translation>Speicherplatzanforderung durch Kürzen (Pruning) alter Blöcke reduzieren. Dies erlaubt das Aufrufen des sogenannten Pruneblockchain RPC zum Löschen spezifischer Blöcke und und aktiviert das automatische Pruning alter Blöcke, sofern eine Zielgröße in MIB angegeben wird. Dieser Modus ist nicht mit -txindex und -resacan kompatibel. Warnung: Das Rücksetzen dieser Einstellung erfordert das erneute Herunterladen der gesamten Blockchain. (Standard: 0 = deaktiviert das Pruning, 1 = erlaubt manuelles Pruning via RPC, &gt;%u = automatisches Pruning der Blockdateien, um angegebene Maximalgröße nicht zu überschreiten)</translation>
    </message>
    <message>
        <source>Set lowest fee rate (in %s/kB) for transactions to be included in block creation. (default: %s)</source>
        <translation>Niedrigste Gebühr (in %s/kB) für Transaktionen einstellen, die bei der Blockerzeugung berücksichtigt werden sollen. (default: %s)</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Maximale Anzahl an Skript-Verifizierungs-Threads festlegen (%u bis %d, 0 = automatisch, &lt;0 = so viele Kerne frei lassen, Standard: %d)</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer&apos;s date and time being set incorrectly. Only rebuild the block database if you are sure that your computer&apos;s date and time are correct</source>
        <translation>Die Block-Datenbank enthält einen Block, der in der Zukunft auftaucht. Dies kann daran liegen, dass die Systemzeit Ihres Computers falsch eingestellt ist. Stellen Sie die Block-Datenbank nur wieder her, wenn Sie sich sicher sind, dass Ihre Systemzeit korrekt eingestellt ist.</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dies ist eine Vorab-Testversion - Verwendung auf eigene Gefahr - nicht für Mining- oder Handelsanwendungen nutzen!</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>Sie müssen die Datenbank mit Hilfe von -reindex neu aufbauen, um zum ungekürzten Modus zurückzukehren. Dies erfordert, dass die gesamte Blockkette erneut heruntergeladen wird.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: 1, wenn abgehört wird und -proxy nicht gesetzt ist)</translation>
    </message>
    <message>
        <source>Username and hashed password for JSON-RPC connections. The field &lt;userpw&gt; comes in the format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. A canonical python script is included in share/rpcuser. The client then connects normally using the rpcuser=&lt;USERNAME&gt;/rpcpassword=&lt;PASSWORD&gt; pair of arguments. This option can be specified multiple times</source>
        <translation>Benutzername und gehashtes Passwort für JSON-RPC Verbindungen. Das Feld &lt;userpw&gt; kommt im Format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. Ein kanonisches Pythonskript ist in share/rpcuser inbegriffen. Der client benutzt wie gehabt, die rpcuser/rpcpassword Parameter. Diese Option kann mehrere Male spezifiziert werden</translation>
    </message>
    <message>
        <source>Wallet will not create transactions that violate mempool chain limits (default: %u)</source>
        <translation>Das Wallet erzeugt keine Transaktionen, die das Mempool Chain Limit überschreiten (Standardeinstellung: %u)</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Warnung: Das Netzwerk scheint nicht vollständig übereinzustimmen! Einige Miner scheinen Probleme zu haben.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Warnung: Wir scheinen nicht vollständig mit unseren Gegenstellen übereinzustimmen! Sie oder die anderen Knoten müssen unter Umständen Ihre Client-Software aktualisieren.</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>Sie müssen die Datenbank mit Hilfe von -reindex-chainstate neu aufbauen, um -txindex zu verändern</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s beschädigt, Datenrettung fehlgeschlagen</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool muss mindestens %d MB betragen</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; kann sein:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>Hänge ein Kommentar zur User Agent-Zeichenkette an</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>Es wird versucht, private Schlüssel beim Starten aus einem beschädigtem Wallet wiederherzustellen</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blockerzeugungsoptionen:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: &apos;%s&apos;</source>
        <translation>Kann Adresse in -%s nicht auflösen: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Chain selection options:</source>
        <translation>Chain Auswahloptionen:</translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation>Position des Wechselgelds außerhalb des Bereichs</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Verbindungsoptionen:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Copyright (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Beschädigte Blockdatenbank erkannt</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Debugging-/Testoptionen:</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Die Wallet nicht laden und Wallet-RPC-Aufrufe deaktivieren</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Möchten Sie die Blockdatenbank jetzt neu aufbauen?</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>Aktiviere das Veröffentlichen des Hash-Blocks in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation>Aktiviere das Veröffentlichen der Hash-Transaktion in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation>Aktiviere das Veröffentlichen des Raw-Blocks in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation>Aktiviere das Veröffentlichen der Roh-Transaktion in &lt;address&gt;</translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation>Maximal &lt;n&gt; nicht-verbindbare Transaktionen im Speicher halten (Standard: %u)</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Fehler beim Initialisieren der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Fehler beim Initialisieren der Wallet-Datenbankumgebung %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Fehler beim Laden von %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Fehler beim Laden von %s: Das Wallet ist beschädigt</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Fehler beim Laden von %s: Das Wallet benötigt eine neuere Version von %s</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Fehler beim Laden der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Fehler beim Öffnen der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fehler: Zu wenig freier Speicherplatz auf dem Datenträger!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Fehler, es konnte kein Port abgehört werden. Wenn dies so gewünscht wird -listen=0 verwenden.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importiere...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Fehlerhafter oder kein Genesis-Block gefunden. Falsches Datenverzeichnis für das Netzwerk?</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Initialisierungsplausibilitätsprüfung fehlgeschlagen. %s wird beendet.</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Ungültige &quot;-onion&quot;-Adresse: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ungültiger Betrag für -%s=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ungültiger Betrag für -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>Halten Sie den Transaktionsspeicherpool unter &lt;n&gt; Megabytes (Voreinstellung: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Lade Sperrliste...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>Dateiort für das Auth-Cookie (Standard: Datenverzeichnis)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Nicht genügend Datei-Deskriptoren verfügbar.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Nur zu Knoten des Netzwerktyps &lt;net&gt; verbinden (ipv4, ipv6 oder onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Drucke diese Hilfemeldung und beende</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Gibt die Versionsnummer aus und beendet das Programm</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>Kürzungsmodus kann nicht mit einem negativen Wert konfiguriert werden.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>Kürzungsmodus ist nicht mit -txindex kompatibel.</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>Blockkettenindex aus aktuellen Dateien blk000??.dat beim Starten wiederaufbauen</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>Blockkettenindex aus aktuellen Dateien blk000??.dat wiederaufbauen</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>Verifiziere Blöcke...</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Größe des Datenbankcaches in Megabyte festlegen (%d bis %d, Standard: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Maximale Blockgröße in Byte festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Wallet-Datei angeben (innerhalb des Datenverzeichnisses)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>Der Quellcode ist von %s verfügbar.</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Kann auf diesem Computer nicht an %s binden. Evtl. wurde %s bereits gestartet.</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Nicht unterstütztes Argument -benchmark wurde ignoriert, bitte -debug=bench verwenden.</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Nicht unterstütztes Argument -debugnet wurde ignoriert, bitte -debug=net verwenden.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Nicht unterstütztes Argument -tor gefunden, bitte -onion verwenden.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: %u)</translation>
    </message>
    <message>
        <source>Use the test chain</source>
        <translation>Die Testchain verwenden</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>Der User Agent Kommentar  (%s) enthält unsichere Zeichen.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifiziere Blöcke...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifiziere Wallet...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Wallet %s liegt außerhalb des Datenverzeichnisses %s</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>Wallet Debugging-/Testoptionen:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Wallet musste neu geschrieben werden: starten Sie %s zur Fertigstellung neu</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Wallet-Optionen:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>JSON-RPC-Verbindungen von der angegeben Quelle erlauben. Gültig für &lt;ip&gt; ist eine einzelne IP-Adresse (z.B. 1.2.3.4), ein Netzwerk bzw. eine Netzmaske (z.B. 1.2.3.4/255.255.255.0), oder die CIDR-Notation (z.B. 1.2.3.4/24). Kann mehrmals angegeben werden.</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>An die angegebene Adresse binden und Gegenstellen, die sich dorthin verbinden, immer zulassen. Für IPv6 &quot;[Host]:Port&quot;-Notation verwenden</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>An die angegebene Adresse binden und nach eingehenden JSON-RPC-Verbindungen abhören. Für IPv6 &quot;[Host]:Port&quot;-Notation verwenden. Kann mehrmals angegeben werden. (Standard: an alle Schnittstellen binden)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Neue Dateien mit Standard-Systemrechten erzeugen, anstatt mit umask 077 (nur mit deaktivierter Walletfunktion nutzbar)</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>Eigene IP-Adressen ermitteln (Standard: 1, wenn abgehört wird und nicht -externalip oder -proxy)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Fehler: Abhören nach eingehenden Verbindungen fehlgeschlagen (listen meldete Fehler %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="vanished">Befehl ausführen wenn ein relevanter Alarm empfangen wird oder wir einen wirklich langen Fork entdecken (%s im Befehl wird durch die Nachricht ersetzt)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>Niedrigere Gebühren (in %s/Kb) als diese werden bei der Transaktionserstellung als gebührenfrei angesehen (Standard: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Wenn -paytxfee nicht festgelegt wurde Gebühren einschließen, so dass mit der Bestätigung von Transaktionen im Schnitt innerhalb von n Blöcken begonnen wird (Standard: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Ungültiger Betrag für -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (muss mindestens die minimale Weiterleitungsgebühr in Höhe von %s sein, um zu verhindern dass Transaktionen nicht bearbeitet werden)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maximale Datengröße in &quot;Data Carrier&quot;-Transaktionen die weitergeleitet und erarbeitet werden (Standard: %u)</translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation>Zufällige Anmeldedaten für jede Proxyverbindung verwenden. Dies aktiviert Tor-Datenflussisolation (Standard: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Maximale Größe in Byte von &quot;high-priority/low-fee&quot;-Transaktionen festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>Der Transaktionsbetrag ist zum senden zu niedrig, nachdem die Gebühr abgezogen wurde.</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Erlaubte Gegenstellen werden nicht für DoS-Attacken gesperrt und ihre Transkationen werden immer weitergeleitet, auch wenn sie sich bereits im Speicherpool befinden, was z.B. für Gateways sinnvoll ist.</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>Sie müssen die Datenbank mit Hilfe von -reindex neu aufbauen, um zum ungekürzten Modus zurückzukehren. Dies erfordert, dass die gesamte Blockkette erneut heruntergeladen wird.</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(Standard: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Öffentliche REST-Anfragen annehmen (Standard: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>Automatisch versteckten Tor-Dienst erstellen (Standard: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Über einen SOCKS5-Proxy &amp;verbinden</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Fehler beim lesen der Datenbank, Ausführung wird beendet.</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>Blöcke beim Starten aus externer Datei blk000??.dat importieren</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation>Ungültiger Betrag für -paytxfee=&lt;amount&gt;: &apos;%s&apos; (muss mindestens %s sein)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation>Ungültige Netzmaske angegeben in -whitelist: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Maximal &lt;n&gt; nicht-verbindbare Transaktionen im Speicher halten (Standard: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation>Angabe eines Ports benötigt für -whitebind: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Knoten-Weiterleitungsoptionen:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC-Serveroptionen:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Reduziere -maxconnections von %d zu %d, aufgrund von Systemlimitierungen.</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>Blockkette beim Starten erneut nach fehlenden Wallet-Transaktionen durchsuchen</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Rückverfolgungs- und Debuginformationen an die Konsole senden, anstatt sie in debug.log zu schreiben</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Transaktionen, wenn möglich, als gebührenfreie Transaktion senden (Standard: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Zeige alle Debuggingoptionen (Benutzung: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Protokolldatei debug.log beim Starten des Clients kürzen (Standard: 1, wenn kein -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signierung der Transaktion fehlgeschlagen</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>Der Transaktionsbetrag ist zu niedrig, um die Gebühr zu bezahlen.</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Dies ist experimentelle Software.</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>TOR Kontrollport Passwort (Standard: leer)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>Zu benutzender TOR Kontrollport wenn Onion Auflistung aktiv ist (Standard: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbetrag zu niedrig</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transaktion ist für die Gebührenrichtlinie zu groß</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktion zu groß</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Kann auf diesem Computer nicht an %s binden (bind meldete Fehler %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>Wallet beim Starten auf das neueste Format aktualisieren</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Benutzername für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>Warnung: Unbekannte neue Regeln aktiviert (Versionsbit %i)</translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation>Legt fest ob nur Blöcke Modus aktiv sein soll (Standard: %u)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Lösche alle Transaktionen aus Wallet...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>ZeroMQ-Benachrichtigungsoptionen:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Passwort für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Erlaube DNS-Abfragen für -addnode, -seednode und -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Lade Adressen...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = TX-Metadaten wie z.B. Accountbesitzer und Zahlungsanforderungsinformationen behalten, 2 = TX-Metadaten verwerfen)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee ist auf einen sehr hohen Wert festgelegt! Gebühren dieser Höhe könnten für eine einzelne Transaktion bezahlt werden.</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Die Transaktion nicht länger im Speicherpool behalten als &lt;n&gt; Stunden (Standard: %u)</translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation>Maximale Datengröße in &quot;Data Carrier&quot;-Transaktionen die weitergeleitet und erarbeitet werden (Standard: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Niedrigere Gebühren (in %s/Kb) als diese werden bei der Transaktionserstellung als gebührenfrei angesehen (Standard: %s)</translation>
    </message>
    <message>
        <source>Force relay of transactions from whitelisted peers even if they violate local relay policy (default: %d)</source>
        <translation>Leite Transaktionen von Peers auf der Positivliste auf jeden Fall weiter, auch wenn sie die lokale Weiterleitungsregeln verletzen (Standardeinstellung: %d)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Legt fest, wie gründlich die Blockverifikation von -checkblocks ist (0-4, Standard: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Einen vollständigen Transaktionsindex führen, der vom RPC-Befehl &quot;getrawtransaction&quot; genutzt wird (Standard: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Anzahl Sekunden, während denen sich nicht konform verhaltenden Gegenstellen die Wiederverbindung verweigert wird (Standard: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Debugginginformationen ausgeben (Standard: %u, &lt;category&gt; anzugeben ist optional)</translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect/-noconnect)</source>
        <translation>Adressen von Gegenstellen via DNS-Namensauflösung finden, falls zu wenige Adressen verfügbar sind (Standard: 1, außer bei -connect/-noconnect)</translation>
    </message>
    <message>
        <source>Sets the serialization of raw transaction or block hex returned in non-verbose mode, non-segwit(0) or segwit(1) (default: %d)</source>
        <translation>Setzt die Serialisierung von Rohtransaktionen oder Block Hex-Daten auf non-verbose mode, nicht-Segwit(0) oder Segwit(1) (default: %d)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>Unterstütze Blöcke und Transaktionen mit  Bloomfiltern zu filtern (default: %u)</translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation>Das ist die Transaktionsgebühr, welche du zahlen müsstest, wenn die Gebührenschätzungen nicht verfügbar sind.</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>Gesamtlänge des Netzwerkversionstrings (%i) erreicht die maximale Länge (%i). Reduzieren Sie die Nummer oder die Größe von uacomments.</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>Versucht ausgehenden Datenverkehr unter dem gegebenen Wert zu halten (in MiB pro 24h), 0 = kein Limit (default: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Nicht unterstütztes Argument -socks gefunden. Das Festlegen der SOCKS-Version ist nicht mehr möglich, nur noch SOCKS5-Proxies werden unterstützt.</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>Das Argument -whitelistalwaysrelay wird nicht unterstützt und deswegen ignoriert. Benutze -whitelistrelay und/oder -whitelistforcerelay.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Separaten SOCKS5-Proxy verwenden, um Gegenstellen über versteckte Tor-Dienste zu erreichen (Standard: %s)</translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It&apos;s possible unknown rules are in effect</source>
        <translation>Warnung: Unbekannte Blockversion wird durch Mining erzeugt! Es ist möglich, dass unbekannte Regeln in Kraft sind.</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given IP address (e.g. 1.2.3.4) or CIDR notated network (e.g. 1.2.3.0/24). Can be specified multiple times.</source>
        <translation>Gegenstellen die sich von der angegebenen IP-Adresse (e.g. 1.2.3.4) oder CIDR Notation (eg. 1.2.3.0/24) aus verbinden immer zulassen. Kann mehrmals angegeben werden.</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation>%s wurde sehr hoch Eingestellt!</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(Standard: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Adressen von Gegenstellen immer über DNS-Namensauflösung abfragen (Standard: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Wieviele Blöcke beim Starten geprüft werden sollen (Standard: %u, 0 = alle)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>IP-Adressen in Debugausgabe einschließen (Standard: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ungültige Adresse in -proxy: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation>Der Keypool ist erschöpft. Bitte rufen Sie zunächst keypoolrefill auf.</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>&lt;port&gt; nach JSON-RPC-Verbindungen abhören (Standard: %u oder Testnetz: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>&lt;port&gt; nach Verbindungen abhören (Standard: %u oder Testnetz: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Maximal &lt;n&gt; Verbindungen zu Gegenstellen aufrechterhalten (Standard: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>Die Wallet soll Transaktionen übertragen/broadcasten</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximale Größe des Empfangspuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximale Größe des Sendepuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Debugausgaben einen Zeitstempel voranstellen (Standard: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>&quot;Data Carrier&quot;-Transaktionen weiterleiten und erarbeiten (Standard: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Nicht-&quot;P2SH-Multisig&quot; weiterleiten (Standard: %u)</translation>
    </message>
    <message>
        <source>Send transactions with full-RBF opt-in enabled (default: %u)</source>
        <translation>Wähle alle zu sendenden Transaktionen als full-RBF (Standard: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Größe des Schlüsselpools festlegen auf &lt;n&gt; (Standard: %u)</translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation>Maximales BIP141 Blockgewicht festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Maximale Anzahl an Threads zur Verarbeitung von RPC-Anfragen festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Konfigurationsdatei festlegen (Standard: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Verbindungzeitüberschreitung in Millisekunden festlegen (Minimum: 1, Standard: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>PID-Datei festlegen (Standard: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Unbestätigtes Wechselgeld darf beim Senden von Transaktionen ausgegeben werden (Standard: %u)</translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation>Netzwerk-Threads werden gestartet...</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation>Das Wallet verhindert Zahlungen, die die Mindesttransaktionsgebühr nicht berücksichtigen.</translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation>Dies ist die minimale Gebühr die beim Senden einer Transaktion fällig wird.</translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Dies ist die Gebühr die beim Senden einer Transaktion fällig wird.</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Schwellenwert, um Verbindungen zu sich nicht konform verhaltenden Gegenstellen zu beenden (Standard: %u)</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation>Transaktionsbeträge dürfen nicht negativ sein.</translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation>Die Speicherpoolkette der Transaktion ist zu lang.</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation>Die Transaktion muss mindestens einen Empfänger enthalten.</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Unbekannter Netztyp in -onlynet angegeben: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Unzureichender Kontostand</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Lade Blockindex...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Mit dem angegebenen Knoten verbinden und versuchen die Verbindung aufrecht zu erhalten</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Lade Wallet...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Wallet kann nicht auf eine ältere Version herabgestuft werden</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Standardadresse kann nicht geschrieben werden</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Durchsuche erneut...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Laden abgeschlossen</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Bitcoin Core and Bitcoin Turmalina Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered dust, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t enable HD on a already existing non-HD wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash, %i is replaced by block number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard. Paper wallet art provided by Anacoluthia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amaze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t disable HD on a already existing HD wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many generous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Such expensive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-discardthreshold is set very high! This is the output amount that the wallet will discard (to fee) if it is smaller than this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered non-standard and will not be accepted or relayed, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid amount for -discardthreshold=&lt;amount&gt;: &apos;%s&apos; (must be at least the dust limit of %s to prevent stuck transactions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The minimum transaction output size (in %s) used to validate wallet transactions and discard change (to fee) (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Namecoin-compatible AuxPow API structure, (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify directory where to write backups and data dumps (default datadir/backups)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID, %i with block height, with a value of 0 if tx is no longer in chaintip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable BIP-70 PaymentServer (default: 0)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
