<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>AddPeerDialog</name>
    <message>
        <source>Add Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Högerklicka för att ändra adressen eller etiketten.</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Skapa ny adress</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Ny</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopiera den markerade adressen till systemets Urklipp</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>S&amp;täng</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ta bort den valda adressen från listan</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportera informationen i den nuvarande fliken till en fil</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportera</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Radera</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Välj en adress att sända betalning till</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Välj en adress att ta emot betalning till</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>V&amp;älj</translation>
    </message>
    <message>
        <source>Such sending addresses</source>
        <translation>Avsändaradresser</translation>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation>Mottagaradresser</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Detta är dina Bitcoin Turmalina adresser för att skicka betalningar. Kolla alltid summan och den mottagande adressen innan du skickar Bitcoin Turmalinas.</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Detta är dina Bitcoin Turmalina adresser för att ta emot betalningar. Det rekommenderas att använda en ny mottagningsadress för varje transaktion.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Kopiera adress</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopiera &amp;etikett</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Redigera</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Exportera adresslista</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommaseparerad fil (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Export misslyckades</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Det inträffade ett fel när adresslistan skulle sparas till %1.
Var vänlig och försök igen.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Ingen etikett)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Lösenordsdialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Ange lösenord</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nytt lösenord</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Upprepa nytt lösenord</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Ange plånbokens nya lösenord. &lt;br/&gt; Använd ett lösenord på &lt;b&gt;tio eller fler slumpmässiga tecken,&lt;/b&gt; eller &lt;b&gt;åtta eller fler ord.&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Kryptera plånbok</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Denna operation behöver din plånboks lösenord för att låsa upp plånboken.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Lås upp plånbok</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Denna operation behöver din plånboks lösenord för att dekryptera plånboken.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Dekryptera plånbok</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Ändra lösenord</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Ge det gamla lösenordet och det nya lösenordet för plånboken.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Bekräfta kryptering av plånbok</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DOGECOINS&lt;/b&gt;!</source>
        <translation>VARNING: Om du krypterar din plånbok och glömmer ditt lösenord, kommer du att &lt;b&gt;FÖRLORA ALLA DINA DOGECOIN&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Är du säker på att du vill kryptera din plånbok?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Plånbok krypterad</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your dogecoins from being stolen by malware infecting your computer.</source>
        <translation>%1 kommer nu att stänga ner för att färdigställa krypteringen. Tänk på att en krypterad plånbok inte skyddar mot stöld om din dator är infekterad med en keylogger.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>VIKTIGT: Alla tidigare säkerhetskopior du har gjort av plånboksfilen ska ersättas med den nya genererade, krypterade plånboksfilen. Av säkerhetsskäl kommer tidigare säkerhetskopior av den okrypterade plånboksfilen blir oanvändbara när du börjar använda en ny, krypterad plånbok.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Kryptering av plånbok misslyckades</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Kryptering av plånbok misslyckades på grund av ett internt fel. Din plånbok blev inte krypterad.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>De angivna lösenorden överensstämmer inte.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Misslyckades låsa upp plånboken</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Lösenordet för dekryptering av plånboken var felaktig.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Dekryptering av plånbok misslyckades</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Plånbokens lösenord har ändrats.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Varning: Caps Lock är påslaget!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/nätmask</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Bannad tills</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Signera &amp;meddelande...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synkroniserar med nätverk...</translation>
    </message>
    <message>
        <source>&amp;Wow</source>
        <translation>&amp;Översikt</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nod</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Visa generell översikt av plånboken</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktioner</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Bläddra i transaktionshistorik</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Avsluta</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Avsluta programmet</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Om %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Visa information om %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Om &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Visa information om Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Alternativ...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Ändra konfigurationsalternativ för %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Kryptera plånbok...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Säkerhetskopiera plånbok...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Byt lösenord...</translation>
    </message>
    <message>
        <source>Such &amp;sending addresses...</source>
        <translation type="vanished">Av&amp;sändaradresser...</translation>
    </message>
    <message>
        <source>Much &amp;receiving addresses...</source>
        <translation type="vanished">Mottaga&amp;radresser...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Öppna &amp;URI...</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Klicka för att inaktivera nätverksaktivitet.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Nätverksaktivitet inaktiverad.</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Klicka för att aktivera nätverksaktivitet igen.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Synkar huvuden (%1%)...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Återindexerar block på disken...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin Turmalina address</source>
        <translation>Skicka dogecoins till en Bitcoin Turmalina-adress</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Säkerhetskopiera plånboken till en annan plats</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Byt lösenfras för kryptering av plånbok</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Debug-fönster</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Öppna debug- och diagnostikkonsolen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifiera meddelande...</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina</source>
        <translation>Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Plånbok</translation>
    </message>
    <message>
        <source>&amp;Such Send</source>
        <translation>&amp;Skicka</translation>
    </message>
    <message>
        <source>&amp;Much Receive</source>
        <translation>&amp;Ta emot</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Visa / Göm</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Visa eller göm huvudfönstret</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Kryptera de privata nycklar som tillhör din plånbok</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin Turmalina addresses to prove you own them</source>
        <translation>Signera meddelanden med din Bitcoin Turmalina-adress för att bevisa att du äger dem</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin Turmalina addresses</source>
        <translation>Verifiera meddelanden för att vara säker på att de var signerade med specificerade Bitcoin Turmalina-adresser</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Arkiv</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Inställningar</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjälp</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Verktygsfält för tabbar</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and dogecoin: URIs)</source>
        <translation>Begär betalning (genererar QR-koder och dogecoin-URI)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Visa listan av använda avsändaradresser och etiketter</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Visa listan av använda mottagningsadresser och etiketter</translation>
    </message>
    <message>
        <source>Open a dogecoin: URI or payment request</source>
        <translation>Öppna en dogecoin: URI eller betalningsbegäran</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Kommandoradsalternativ</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin Turmalina network</source>
        <translation>
            <numerusform>%n aktiva anslutningar till Bitcoin Turmalina-nätverket.</numerusform>
            <numerusform>%n aktiva anslutningar till Bitcoin Turmalina-nätverket.</numerusform>
        </translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Indexerar block på disken...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Bearbetar block på disken...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>Bearbetade %n block av transaktionshistoriken.</numerusform>
            <numerusform>Bearbetade %n block av transaktionshistoriken.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 efter</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Senast mottagna block genererades för %1 sen.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktioner efter denna kommer inte ännu vara synliga.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Uppdaterad</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin Turmalina command-line options</source>
        <translation>Visa %1 hjälpmeddelande för att få en lista med möjliga Bitcoin Turmalina kommandoradsalternativ.</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1-klient</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Ansluter till noder...</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Hämtar senaste...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Datum: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Belopp: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Typ: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Etikett: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Adress: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transaktion skickad</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Inkommande transaktion</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Denna plånbok är &lt;b&gt;krypterad&lt;/b&gt; och för närvarande &lt;b&gt;olåst&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Denna plånbok är &lt;b&gt;krypterad&lt;/b&gt; och för närvarande &lt;b&gt;låst&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Bitcoin Turmalina can no longer continue safely and will quit.</source>
        <translation>Ett kritiskt fel uppstod. Bitcoin Turmalina kan inte fortsätta att köra säkert och kommer att avslutas.</translation>
    </message>
    <message>
        <source>&amp;Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Such sending addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Much receiving addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import a Bitcoin Turmalina private key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Myntval</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Kvantitet:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Antal byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Belopp:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Avgift:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Damm:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter avgift:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Växel:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(av)markera allt</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Trädvy</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listvy</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Mängd</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Mottagen med etikett</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Mottagen med adress</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bekräftelser</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bekräftad</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiera adress</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiera etikett</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiera belopp</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiera transaktions-ID</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nej</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Ingen etikett)</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu per input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(change)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Redigera adress</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etikett</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Etiketten associerad med denna adresslistas post</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adressen associerad med denna adresslistas post. Detta kan bara ändras för sändningsadresser.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adress</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Kunde inte låsa upp plånboken.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Bitcoin Turmalina address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>En ny datakatalog kommer att skapas.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>namn</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Katalogen finns redan. Lägg till %1 om du vill skapa en ny katalog här.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Sökvägen finns redan, och är inte en katalog.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Kan inte skapa datakatalog här.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Kommandoradsalternativ</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Användning:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>kommandoradsalternativ</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>UI-inställningar:</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Välj datakatalog vid uppstart (standard: %u)</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Ange språk, till exempel &quot;de_DE&quot; (standard: systemspråk)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Starta minimerad</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Ange SSL rotcertifikat för betalningsansökan (standard: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Visa startbild vid uppstart (standard: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Återställ alla inställningar som gjorts i GUI</translation>
    </message>
</context>
<context>
    <name>ImportKeysDialog</name>
    <message>
        <source>Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private key to import into your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label for this private key in your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label (optional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset this form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Avbryt</translation>
    </message>
    <message>
        <source>Invalid private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid address generated from private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to add private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation type="unfinished">Söker igen...</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Välkommen</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Välkommen till %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>Eftersom detta är första gången programmet startas får du välja var %1 skall lagra sitt data.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Bitcoin Turmalina block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 kommer att ladda ner och spara en kopia av Bitcoin Turmalina blockkedjan. Åtminstone %2GB av data kommer att sparas i denna katalog, och den kommer att växa över tiden. Plånboken kommer också att sparas i denna katalog.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Använd den förvalda datakatalogen</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Använd en anpassad datakatalog:</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation>Fel: Den angivna datakatalogen &quot;%1&quot; kan inte skapas.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation>
            <numerusform>%n GB fritt utrymme kvar</numerusform>
            <numerusform>%n GB fritt utrymme kvar</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation>
            <numerusform>(av %n GB behövs)</numerusform>
            <numerusform>(av %n GB behövs)</numerusform>
        </translation>
    </message>
    <message>
        <source>Choose data directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>Antal block kvar</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Okänt...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Sista blocktid</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Förlopp</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>beräknar...</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Göm</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1)...</source>
        <translation>Okänd. Synkar huvuden (%1)...</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet&apos;s balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the dogecoin network, as detailed below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempting to spend dogecoins that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Öppna URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Öppna betalningsbegäran från URI eller fil</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Välj betalningsbegäransfil</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Allmänt</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Starta %1 automatiskt efter inloggningen.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>&amp;Starta %1 vid systemlogin</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Storleken på &amp;databascache</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Antalet skript&amp;verifikationstrådar</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Acceptera anslutningar utifrån</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Acceptera inkommande anslutningar</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>Proxyns IP-adress (t.ex.  IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Minimera istället för att stänga programmet när fönstret stängs. När detta alternativ är aktiverat stängs programmet endast genom att välja Stäng i menyn.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Tredjeparts URL:er (t.ex. en blockutforskare) som finns i transaktionstabben som ett menyval i sammanhanget. %s i URL:en ersätts med tansaktionshashen. Flera URL:er är separerade med vertikala streck |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Tredjeparts transaktions-URL:er</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktiva kommandoradsalternativ som ersätter alternativen ovan:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Återställ alla klientinställningar till förvalen.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Återställ alternativ</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Nätverk</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = auto, &lt;0 = lämna så många kärnor lediga)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>&amp;Plånbok</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Aktivera mynt&amp;kontrollfunktioner</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Om du avaktiverar betalning med obekräftad växel, kan inte växeln från en transaktion användas förrän den transaktionen har minst en bekräftelse.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Spendera obekräftad växel</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin Turmalina client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Öppna automatiskt Bitcoin Turmalina-klientens port på routern. Detta fungerar endast om din router har UPnP aktiverat.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Tilldela port med hjälp av &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a SOCKS5 proxy.</source>
        <translation>Anslut till Bitcoin Turmalina-nätverket genom en SOCKS5-proxy.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Anslut genom SOCKS5-proxy (förvald proxy):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-&amp;IP: </translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port: </translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Proxyns port (t.ex. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Används för att nå noder via:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Visas, om den angivna standard-SOCKS5-proxyn används för att nå noder via den här nätverkstypen.</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Anslut till Bitcoin Turmalina-nätverket genom en separat SOCKS5-proxy för dolda tjänster i Tor.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>Använd separat SOCKS5-proxy för att nå noder via dolda tjänster i Tor:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Fönster</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>&amp;Göm ikonen från systemfältet.</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>Göm systemfältsikonen</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Visa endast en systemfältsikon vid minimering.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimera till systemfältet istället för aktivitetsfältet</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimera vid stängning</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Visa</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Användargränssnittets &amp;språk: </translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>Användargränssnittets språk kan ställas in här. Denna inställning träder i kraft efter en omstart av %1.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Måttenhet att visa belopp i: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Välj en måttenhet att visa i gränssnittet och när du skickar mynt.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Om myntkontrollfunktioner skall visas eller inte</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Avbryt</translation>
    </message>
    <message>
        <source>default</source>
        <translation>standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ingen</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Bekräfta att alternativen ska återställs</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Klientomstart är nödvändig för att aktivera ändringarna.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Programmet kommer att stängas. Vill du fortsätta?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Denna ändring kräver en klientomstart.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Den angivna proxy-adressen är ogiltig.</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin Turmalina network after a connection is established, but this process has not completed yet.</source>
        <translation>Den visade informationen kan vara inaktuell. Plånboken synkroniseras automatiskt med Bitcoin Turmalina-nätverket efter att anslutningen är upprättad, men denna process har inte slutförts ännu.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Granska-bara:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Tillgängligt:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ditt tillgängliga saldo</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Pågående:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Totalt antal transaktioner som ännu inte bekräftats, och som ännu inte räknas med i aktuellt saldo</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Omogen:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Den genererade balansen som ännu inte har mognat</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Balanser</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Totalt:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Ditt nuvarande totala saldo</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Ditt nuvarande saldo i granska-bara adresser</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Spenderbar:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Nyligen genomförda transaktioner</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Okonfirmerade transaktioner till granska-bara adresser</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Den genererade balansen i granska-bara adresser som ännu inte har mognat</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Nuvarande total balans i granska-bara adresser</translation>
    </message>
    <message>
        <source>Helpful tip of the day:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your wallet.dat file with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For advanced operations, use the console in &apos;Help&apos; -&gt; &apos;Debug Window&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encrypt your wallet with a strong passphrase for maximum security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make sure to keep your wallet software updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backup your private key to recover your coins, using &apos;File&apos; &gt; &apos;Backup Wallet&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always do your own research before using an external cryptocurrency service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your private key with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Who owns the private keys, owns the coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To see ongoing development and contribute, check out the Bitcoin Turmalina Core repository on GitHub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services that claim to double your dogecoins are always ponzi schemes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaperWalletDialog</name>
    <message>
        <source>Print Your Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very New Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>So Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many Wallets?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Network Activity Detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is recommended to disconnect from the internet before printing paper wallets. Even though paper wallets are generated on your local computer, it is still possible to unknowingly have malware that transmits your screen to a remote location. It is also recommended to print to a local printer vs a network printer since that network traffic can be monitored. Some advanced printers also store copies of each printed document. Proceed with caution relative to the amount of value you plan to store on each address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding Address into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding private key into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>failed to open file, is it writable?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The paper wallet printing process has begun.&lt;br/&gt;Please wait for the wallets to print completely and verify that everything printed correctly.&lt;br/&gt;Check for misalignments, ink bleeding, smears, or anything else that could make the private keys unreadable.&lt;br/&gt;Now, enter the number of BTURM you wish to send to each wallet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper wallet %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Skicka pengar</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The total exceeds your balance when the transaction fee is included</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">eller</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI-hantering</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Återbetalning från %1</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Felaktigt svar från server %1</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot start dogecoin: click-to-pay handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Bitcoin Turmalina address or malformed URI parameters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (below discard threshold).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BIP70 payment requests are deprecated and disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request file handling is disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Användaragent</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Nod/Tjänst</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTools</name>
    <message>
        <source>Error: Node address is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Peer-to-peer functionality missing or disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to one try node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Unable to add node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node not found in connected nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnected the node: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Returned OK.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Mängd</translation>
    </message>
    <message>
        <source>Enter a Bitcoin Turmalina address (e.g. %1)</source>
        <translation>Ange en Bitcoin Turmalina-adress (t.ex. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>ej tillgänglig</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n sekund</numerusform>
            <numerusform>%n sekunder</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n minut</numerusform>
            <numerusform>%n minuter</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation>
            <numerusform>%n timme</numerusform>
            <numerusform>%n timmar</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation>
            <numerusform>%n dag</numerusform>
            <numerusform>%n dagar</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation>
            <numerusform>%n vecka</numerusform>
            <numerusform>%n veckor</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 och %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation>
            <numerusform>%n år</numerusform>
            <numerusform>%n år</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation type="unfinished">%1 B</translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB</translation>
    </message>
    <message>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: %1</source>
        <translation>Fel: %1</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation type="unfinished">&amp;Spara Bild...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>ej tillgänglig</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Klient-version</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Debug fönster</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generell</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Använder BerkeleyDB versionen</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Datakatalog</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Uppstartstid</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Nätverk</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Antalet anslutningar</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blockkedja</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktuellt antal block</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Minnespool</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Nuvarande antal transaktioner</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Minnesåtgång</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Mottagen</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Skickad</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Klienter</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Bannade noder</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Välj en klient för att se detaljerad information.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Vitlistad</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Riktning</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Startblock</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Synkade huvuden</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Synkade block</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Användaragent</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Öppna %1 debug-loggfilen från aktuell datakatalog. Detta kan ta några sekunder för stora loggfiler.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Minska fontstorleken</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Öka fontstorleken</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Tjänster</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Banpoäng</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Anslutningstid</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Senast sänt</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Senast mottagen</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Pingtid</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>Tidsåtgången för en nuvarande utestående ping.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Pingväntetid</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Tidsförskjutning</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Sista blocktid</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öppna</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsol</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Nätverkstrafik</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Rensa</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totalt:</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>In:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Ut:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debugloggfil</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Rensa konsollen</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;timme</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;dag</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;vecka</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;år</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Välkommen till %1 RPC-konsolen.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Använd upp- och ner-pilarna för att navigera i historiken, och &lt;b&gt;Ctrl-L&lt;/b&gt; för att rensa skärmen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Skriv &lt;b&gt;help&lt;/b&gt; för en översikt av alla kommandon.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(nod-id: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>via %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>aldrig</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Inkommande</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Utgående</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <source>Connected peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One try peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramification of a command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Fel</translation>
    </message>
    <message>
        <source>Remove Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the peer: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No peer was selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Belopp:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etikett:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Meddelande:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Återanvänd en av tidigare använda mottagningsadresser. Återanvändning av adresser har både säkerhets och integritetsbrister. Använd inte samma mottagningsadress om du inte gör om samma betalningsbegäran.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>Åt&amp;eranvänd en existerande mottagningsadress (rekommenderas inte)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin Turmalina network.</source>
        <translation>Ett frivilligt meddelande att bifoga betalningsbegäran, vilket visas när begäran öppnas. NB: Meddelandet kommer inte att sändas med betalningen över Dogecoinnätverket.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>En frivillig etikett att associera med den nya mottagningsadressen.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Använd detta formulär för att begära betalningar. Alla fält är  &lt;b&gt;frivilliga&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>En valfri summa att begära. Lämna denna tom eller noll för att inte begära en specifik summa.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Rensa alla formulärfälten</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Historik för begärda betalningar</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>Begä&amp;r betalning</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Visa valda begäranden (gör samma som att dubbelklicka på en post)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Visa</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Ta bort valda poster från listan</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Kopiera URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiera etikett</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Kopiera meddelande</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiera belopp</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-kod</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopiera &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopiera &amp;Adress</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Spara Bild...</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Betalinformaton</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Mängd</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Ingen etikett)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(inget meddelande)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requested</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Skicka pengar</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Myntkontrollfunktioner</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Inmatningar...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automatiskt vald</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Otillräckliga medel!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Kvantitet:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Antal Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Belopp:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Avgift:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter avgift:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Växel:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Om denna är aktiverad men växeladressen är tom eller felaktig kommer växeln att sändas till en nygenererad adress.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Specialväxeladress</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transaktionsavgift:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Välj...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>Fäll ihop avgiftsinställningarna</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>per kilobyte</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 koinu and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 koinu in fee, while &quot;total at least&quot; pays 1000 koinu. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Om den anpassad avgiften är satt till 1000 koinu och transaktionen bara är 250 byte, betalar &quot;per kilobyte&quot; bara 250 koinu i avgift, medans &quot;totalt minst&quot; betalar 1000 koinu. För transaktioner större än en kilobyte betalar både per kilobyte.</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Göm</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>totalt minst</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for dogecoin transactions than the network can process.</source>
        <translation>Att betala endast den minsta avgiften är bara bra så länge det är mindre transaktionsvolym än utrymme i blocken. Men tänk på att det kan hamna i en aldrig bekräftar transaktion när det finns mer efterfrågan på dogecoin transaktioner än nätverket kan bearbeta.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(läs verktygstips)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Rekommenderad:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Anpassad:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation type="vanished">(Smartavgiften är inte initierad än. Detta tar vanligen några block...)</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="vanished">normal</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="vanished">snabb</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Skicka till flera mottagare samtidigt</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Lägg till &amp;mottagare</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Rensa alla formulärfälten</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Damm:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Rensa &amp;alla</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balans:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Bekräfta sändordern</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Skicka</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiera belopp</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 till %2</translation>
    </message>
    <message>
        <source>or</source>
        <translation>eller</translation>
    </message>
    <message numerus="yes">
        <source>%n block(s)</source>
        <translation type="vanished">
            <numerusform>%n block</numerusform>
            <numerusform>%n block</numerusform>
        </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Ingen etikett)</translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 satoshis in fee, while &quot;total at least&quot; pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Amount %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pay only the required fee of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin Turmalina address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Belopp:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Betala &amp;Till:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etikett:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Välj tidigare använda adresser</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Detta är en normal betalning.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to send the payment to</source>
        <translation>Dogecoinadress att sända betalning till</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Klistra in adress från Urklipp</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Radera denna post</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less dogecoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>Avgiften dras från beloppet som skickas. Mottagaren kommer att få mindre dogecoins än du angivit i belopp-fältet. Om flera mottagare valts kommer avgiften delas jämt.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>S&amp;ubtrahera avgiften från beloppet</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Meddelande:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>Detta är en oautentiserad betalningsbegäran.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>Detta är en autentiserad betalningsbegäran.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Ange en etikett för denna adress att adderas till listan över använda adresser</translation>
    </message>
    <message>
        <source>A message that was attached to the dogecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin Turmalina network.</source>
        <translation>Ett meddelande som bifogades dogecoin-URI, vilket lagras med transaktionen som referens. NB: Meddelandet kommer inte att sändas över Dogecoinnätverket.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Betala Till:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>PM:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 stängs av...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Stäng inte av datorn förrän denna ruta försvinner.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signaturer - Signera / Verifiera ett Meddelande</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signera Meddelande</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive dogecoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Du kan underteckna meddelanden/avtal med dina adresser för att bevisa att du kan ta emot dogecoins som skickats till dem. Var försiktig så du inte undertecknar något oklart eller konstigt, eftersom phishing-angrepp kan försöka få dig att underteckna din identitet till dem. Underteckna endast väldetaljerade meddelanden som du godkänner.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to sign the message with</source>
        <translation>Dogecoinadress att signera meddelandet med</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Välj tidigare använda adresser</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Klistra in adress från Urklipp</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Skriv in meddelandet du vill signera här</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopiera signaturen till systemets Urklipp</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin Turmalina address</source>
        <translation>Signera meddelandet för att bevisa att du äger denna adress</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Signera &amp;Meddelande</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Rensa alla fält</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Rensa &amp;alla</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifiera Meddelande</translation>
    </message>
    <message>
        <source>Enter the receiver&apos;s address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Ange mottagarens adress, meddelande (kopiera radbrytningar, mellanrum, flikar, etc. exakt) och signatur nedan för att verifiera meddelandet. Undvik att läsa in mera information i signaturen än vad som stod i själva undertecknade meddelandet, för att undvika ett man-in-the-middle-angrepp. Notera att detta endast bevisar att undertecknad tar emot med adressen, det bevisar inte vem som skickat transaktionen!</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address the message was signed with</source>
        <translation>Dogecoinadressen som meddelandet signerades med</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin Turmalina address</source>
        <translation>Verifiera meddelandet för att vara säker på att den var signerad med den angivna Bitcoin Turmalina-adressen</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verifiera &amp;Meddelande</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Rensa alla fält</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Meddelande signerat.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Signaturen kunde inte avkodas.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Meddelande verifierat.</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TestPeerDialog</name>
    <message>
        <source>Test Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Peer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>own address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Mängd</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Den här panelen visar en detaljerad beskrivning av transaktionen</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Ingen etikett)</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Enter address or label to search</source>
        <translation>Ange en adress eller etikett att söka efter</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minsta belopp</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>Avbryt transaktionen</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiera adress</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiera etikett</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiera belopp</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiera transaktions-ID</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommaseparerad fil (*.csv)</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Export misslyckades</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation type="unfinished">Bekräftad</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>&amp;Enhet att visa belopp i. Klicka för att välja annan enhet.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">Skicka pengar</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation type="unfinished">&amp;Exportera</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished">Exportera informationen i den nuvarande fliken till en fil</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Inställningar:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Ange katalog för data</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Anslut till en nod för att hämta klientadresser, och koppla från</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Ange din egen publika adress</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Tillåt kommandon från kommandotolken och JSON-RPC-kommandon</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>Om &lt;kategori&gt; inte anges eller om &lt;category&gt; = 1, visa all avlusningsinformation.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>Beskärning konfigurerad under miniminivån %d MiB. Vänligen använd ett högre värde.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Beskärning: sista plånbokssynkroniseringen ligger utanför beskuren data. Du måste använda -reindex (ladda ner hela blockkedjan igen eftersom noden beskurits)</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Omskanningar kan inte göras i beskuret läge. Du måste använda -reindex vilket kommer ladda ner hela blockkedjan igen.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Fel: Ett kritiskt internt fel uppstod, se debug.log för detaljer</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>Avgift (i %s/kB) att lägga till på transaktioner du skickar (förvalt: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Rensar blockstore...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Kör i bakgrunden som tjänst och acceptera kommandon</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Kunde inte starta HTTP-server. Se avlusningsloggen för detaljer.</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina Core</source>
        <translation>Bitcoin Turmalina Core</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>%s-utvecklarna</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>En avgiftskurs (i %s/kB) som används när det inte finns tillräcklig data för att uppskatta avgiften (förvalt: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>Acceptera vidarebefodrade transaktioner från vitlistade noder även när transaktioner inte vidarebefodras (förvalt: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Bind till given adress och lyssna alltid på den. Använd [värd]:port notation för IPv6</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Kan inte låsa data-mappen %s. %s körs förmodligen redan.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Ta bort alla plånbokstransaktioner och återskapa bara dom som är en del av blockkedjan genom att ange -rescan vid uppstart</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t enable HD on a already existing non-HD wallet</source>
        <translation>Fel vid laddning av %s: Du kan inte aktivera HD på en existerande icke-HD plånbok</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Fel vid läsning av %s! Alla nycklar lästes korrekt, men transaktionsdatat eller adressbokens poster kanske saknas eller är felaktiga.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation type="vanished">Exekvera kommando när en plånbokstransaktion ändras (%s i cmd är ersatt av TxID)</translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation>Maximalt tillåten median-peer tidsoffset justering. Lokalt perspektiv av tiden kan bli påverkad av partners, framåt eller bakåt denna tidsrymd. (förvalt: %u sekunder)</translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation>Maximal total avgift (i %s) att använda i en plånbokstransaktion eller råa transaktioner. Sätts denna för lågt kan stora transaktioner avbrytas (förvalt: %s)</translation>
    </message>
    <message>
        <source>Please check that your computer&apos;s date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Vänligen kolla så att din dators datum och tid är korrekt! Om din klocka går fel kommer %s inte att fungera korrekt.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>Var snäll och bidra om du finner %s användbar. Besök %s för mer information om mjukvaran.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Ange antalet skriptkontrolltrådar (%u till %d, 0 = auto, &lt;0 = lämna så många kärnor lediga, förval: %d)</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer&apos;s date and time being set incorrectly. Only rebuild the block database if you are sure that your computer&apos;s date and time are correct</source>
        <translation>Blockdatabasen innehåller ett block som verkar vara från framtiden. Detta kan vara på grund av att din dators datum och tid är felaktiga. Bygg bara om blockdatabasen om du är säker på att datorns datum och tid är korrekt</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>Kan inte spola tillbaka databasen till obeskärt läge. Du måste ladda ner blockkedjan igen</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>Använd UPnP för att mappa den lyssnande porten (förvalt: 1 när lyssning aktiverat och utan -proxy)</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>Du måste återskapa databasen med -reindex-chainstate för att ändra -txindex</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s är korrupt, räddning misslyckades</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool måste vara minst %d MB</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; Kan vara:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>Lägg till kommentar till user-agent-strängen</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>Försök att rädda privata nycklar från en korrupt plånbok vid uppstart</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Block skapande inställningar:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: &apos;%s&apos;</source>
        <translation>Kan inte matcha -%s adress: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation>Förändringsindexet utom räckhåll</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Anslutningsalternativ:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Copyright (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Korrupt blockdatabas har upptäckts</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Avlusnings/Test-alternativ:</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Ladda inte plånboken och stäng av RPC-anrop till plånboken</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Vill du bygga om blockdatabasen nu?</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>Aktivera publicering av hashblock i &lt;adress&gt;</translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation>Aktivera publicering av hashtransaktion i &lt;adress&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation>Aktivera publicering av råa block i &lt;adress&gt;</translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation>Aktivera publicering av råa transaktioner i &lt;adress&gt;</translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation>Aktivera byte av transaktioner i minnespoolen (förvalt: %u)</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Fel vid initiering av blockdatabasen</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Fel vid initiering av plånbokens databasmiljö %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Fel vid inläsning av %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Fel vid inläsningen av %s: Plånboken är koruppt</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Fel vid inläsningen av %s: Plånboken kräver en senare version av %s</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t disable HD on a already existing HD wallet</source>
        <translation>Fel vid laddning av %s: Du kan inte avaktivera HD på en redan existerande HD plånbok</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Fel vid inläsning av blockdatabasen</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Fel vid öppning av blockdatabasen</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fel: Hårddiskutrymme är lågt!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Misslyckades att lyssna på någon port. Använd -listen=0 om du vill detta.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importerar...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Felaktig eller inget genesisblock hittades. Fel datadir för nätverket?</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Initieringschecken fallerade. %s stängs av.</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Ogiltig -onion adress:&apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ogiltigt belopp för -%s=&lt;belopp&gt;:&apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ogiltigt belopp för -fallbackfee=&lt;belopp&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>Håll minnespoolen över transaktioner under &lt;n&gt; megabyte (förvalt: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Laddar svarta listan...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>Plats för authcookie (förvalt: datamapp)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Inte tillräckligt med filbeskrivningar tillgängliga.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Anslut enbart till noder i nätverket &lt;net&gt; (IPv4, IPv6 eller onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Visa denna hjälptext och avsluta</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Visa version och avsluta</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>Beskärning kan inte konfigureras med ett negativt värde.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>Beskärningsläge är inkompatibel med -txindex.</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>Återskapa blockkedjans status och index från blk*.dat filer på disken</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>Återskapa blockkedjans status från aktuella indexerade block</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>Spolar tillbaka blocken...</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Sätt databasens cachestorlek i megabyte (%d till %d, förvalt: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Sätt maximal blockstorlek i byte (förvalt: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Ange plånboksfil (inom datakatalogen)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>Källkoden är tillgänglig från %s.</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Det går inte att binda till %s på den här datorn. %s är förmodligen redan igång.</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Argumentet -benchmark stöds inte och ignoreras, använd -debug=bench.</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Argumentet -debugnet stöds inte och ignoreras, använd -debug=net.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Argumentet -tor hittades men stöds inte, använd -onion.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>Använd UPnP för att mappa den lyssnande porten (förvalt: %u)</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>Kommentaren i användaragent (%s) innehåller osäkra tecken.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifierar block...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifierar plånboken...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Plånbok %s ligger utanför datakatalogen %s</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>Plånbokens Avlusnings/Testnings optioner:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Plånboken behöver sparas om: Starta om %s för att fullfölja</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Plånboksinställningar:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>Tillåt JSON-RPC-anslutningar från specifik källa. Tillåtna &lt;ip&gt; är enkel IP (t.ex 1.2.3.4), en nätverk/nätmask (t.ex. 1.2.3.4/255.255.255.0) eller ett nätverk/CIDR (t.ex. 1.2.3.4/24). Detta alternativ anges flera gånger</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>Bind till given adress och vitlista klienter som ansluter till den. Använd [värd]:port notation för IPv6</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Bind till angiven adress för att lyssna på JSON-RPC-anslutningar. Använd [värd]:port-format for IPv6. Detta alternativ kan anges flera gånger (förvalt: bind till alla gränssnitt)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Skapa nya filer med systemets förvalda rättigheter, istället för umask 077 (bara effektivt med avaktiverad plånboks funktionalitet)</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>Upptäck egna IP adresser (standard: 1 vid lyssning ingen -externalip eller -proxy)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Fel: Avlyssning av inkommande anslutningar misslyckades (Avlyssningen returnerade felkod %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="vanished">Exekvera kommando när ett relevant meddelande är mottagen eller när vi ser en väldigt lång förgrening (%s i cmd är utbytt med ett meddelande)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>Avgifter (i %s/kB) mindre än detta betraktas som nollavgift för vidarebefordran, mining och transaktionsskapande (förvalt: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Om paytxfee inte är satt, inkludera tillräcklig avgift så att transaktionen börjar att konfirmeras inom n blocks (förvalt: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Otillåtet belopp för -maxtxfee=&lt;belopp&gt;: &apos;%s&apos; (måste åtminstånde vara minrelay avgift %s för att förhindra stoppade transkationer)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maximal storlek på data i databärartransaktioner som vi reläar och bryter (förvalt: %u) </translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation>Slumpa autentiseringen för varje proxyanslutning. Detta möjliggör Tor ström-isolering (förvalt: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Sätt den maximala storleken av hög-prioriterade/låg-avgifts transaktioner i byte (förvalt: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>Transaktionen är för liten att skicka efter det att avgiften har dragits</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>Använd hierarkisk deterministisk nyckel generering (HD) efter BIP32. Har bara effekt under plånbokens skapande/första användning.</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Vitlistade klienter kan inte bli DoS-bannade och deras transaktioner reläas alltid, även om dom redan är i mempoolen, användbart för t.ex en gateway  </translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>Du måste bygga om databasen genom att använda -reindex för att återgå till obeskärt läge. Detta kommer att ladda ner hela blockkedjan.</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(förvalt: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Acceptera publika REST förfrågningar (förvalt: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>Skapa automatiskt dold tjänst i Tor (förval: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Anslut genom SOCKS5 proxy</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Fel vid läsning från databas, avslutar.</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>Importera block från extern blk000??.dat-fil vid uppstart</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation>Ogiltigt belopp för -paytxfee=&lt;belopp&gt;:&apos;%s&apos; (måste vara minst %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation>Ogiltig nätmask angiven i -whitelist: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Håll som mest &lt;n&gt; oanslutningsbara transaktioner i minnet (förvalt: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation>Port måste anges med -whitelist: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Nodreläalternativ:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC-serveralternativ:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Minskar -maxconnections från %d till %d, på grund av systembegränsningar.</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>Sök i blockkedjan efter saknade plånbokstransaktioner vid uppstart</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Skicka trace-/debuginformation till terminalen istället för till debug.log</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Sänd transaktioner som nollavgiftstransaktioner om möjligt (förvalt: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Visa alla avlusningsalternativ (använd: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Krymp debug.log filen vid klient start (förvalt: 1 vid ingen -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signering av transaktion misslyckades</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>Transaktionen är för liten för att betala avgiften</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Detta är experimentmjukvara.</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>Lösenord för Tor-kontrollport (förval: inget)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>Tor-kontrollport att använda om onion är aktiverat (förval: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktions belopp för liten</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transaktionen är för stor för avgiftspolicyn</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktionen är för stor</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Det går inte att binda till %s på den här datorn (bind returnerade felmeddelande %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>Uppgradera plånbok till senaste formatet vid uppstart</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Användarnamn för JSON-RPC-anslutningar</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>Varning: okända nya regler aktiverade (versionsbit %i)</translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation>Ska allt göras i endast block-läge (förval: %u)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Töm plånboken på alla transaktioner...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>ZeroMQ-alternativ för notiser:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Lösenord för JSON-RPC-anslutningar</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation type="vanished">Exekvera kommando när det bästa blocket ändras (%s i cmd är utbytt av blockhash)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Tillåt DNS-sökningar för -addnode, -seednode och -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Laddar adresser...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = spara tx metadata t.ex. kontoägare och betalningsbegäransinformation, 2 = släng tx metadata)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee är väldigt högt satt! Så höga avgifter kan komma att betalas för en enstaka transaktion.</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Håll inte transaktioner i minnespoolen längre än &lt;n&gt; timmar (förvalt: %u)</translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation>Samma antal byte per sigop i transaktioner som vi reläar och bryter (förvalt: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Avgifter (i %s/kB) mindre än detta anses vara nollavgifter vid skapande av transaktion (standard: %s)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Hur grundlig blockverifikationen vid -checkblocks är (0-4, förvalt: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Upprätthåll ett fullständigt transaktionsindex, som används av getrawtransaction rpc-anrop (förval: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Antal sekunder att hindra klienter som missköter sig från att ansluta (förvalt: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Skriv ut avlusningsinformation (förvalt: %u, att ange &lt;category&gt; är frivilligt)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>Stöd filtrering av block och transaktioner med bloomfilter (standard: %u)</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>Total längd på strängen för nätverksversion (%i) överskrider maxlängden (%i). Minska numret eller storleken på uacomments.</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>Försöker hålla utgående trafik under givet mål (i MiB per 24 timmar), 0 = ingen gräns (förvalt: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Argumentet -socks hittades och stöds inte. Det är inte längre möjligt att sätta SOCKS-version längre, bara SOCKS5-proxy stöds.</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>Argumentet -whitelistalwaysrelay stöds inte utan ignoreras, använd -whitelistrelay och/eller -whitelistforcerelay.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Använd separat SOCKS5 proxy för att nå kollegor via dolda tjänster i Tor (förvalt: -%s)</translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It&apos;s possible unknown rules are in effect</source>
        <translation>Varning: Okända blockversioner bryts! Det är möjligt att okända regler används</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Varning: Plånboksfilen var korrupt, datat har räddats! Den ursprungliga %s har sparas som %s i %s. Om ditt saldo eller transaktioner är felaktiga bör du återställa från en säkerhetskopia.</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(förvalt: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Sök alltid efter klientadresser med DNS sökningen (förvalt: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Hur många block att kontrollera vid uppstart (förvalt: %u, 0 = alla)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>Inkludera IP-adresser i debugutskrift (förvalt: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ogiltig -proxy adress: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Lyssna på JSON-RPC-anslutningar på &lt;port&gt; (förval: %u eller testnet: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Lyssna efter anslutningar på &lt;port&gt; (förvalt: %u eller testnet: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Ha som mest &lt;n&gt; anslutningar till andra klienter (förvalt: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>Gör så att plånboken sänder ut transaktionerna</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximal mottagningsbuffert per anslutning, &lt;n&gt;*1000 byte (förvalt: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximal sändningsbuffert per anslutning, &lt;n&gt;*1000 byte (förvalt: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Skriv ut tidsstämpel i avlusningsinformationen (förvalt: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>Reläa och bearbeta databärartransaktioner (förvalt: %u) </translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Reläa icke-P2SH multisig (förvalt: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Sätt storleken på nyckelpoolen till &lt;n&gt; (förvalt: %u)</translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation>Sätt maximal BIP141 blockvikt (förvalt: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Ange antalet trådar för att hantera RPC anrop (förvalt: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Ange konfigurationsfil (förvalt: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Ange timeout för uppkoppling i millisekunder (minimum:1, förvalt: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Ange pid-fil (förvalt: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Spendera okonfirmerad växel när transaktioner sänds (förvalt: %u)</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Tröskelvärde för att koppla ifrån klienter som missköter sig (förvalt: %u)</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Okänt nätverk som anges i -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Otillräckligt med dogecoins</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Laddar blockindex...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Lägg till en nod att koppla upp mot och försök att hålla anslutningen öppen</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Laddar plånbok...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Kan inte nedgradera plånboken</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Kan inte skriva standardadress</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Söker igen...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Klar med laddning</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <source>Bitcoin Core and Bitcoin Turmalina Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-discardthreshold is set very high! This is the output amount that the wallet will discard (to fee) if it is smaller than this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect/-noconnect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered dust, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered non-standard and will not be accepted or relayed, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect only to the specified node(s); -noconnect or -connect=0 alone to disable automatic connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash, %i is replaced by block number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extra transactions to keep in memory for compact block reconstructions (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force relay of transactions from whitelisted peers even if they violate local relay policy (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If this block is in the chain assume that it and its ancestors are valid and potentially skip their script verification (0 to verify all, default: %s, testnet: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid amount for -discardthreshold=&lt;amount&gt;: &apos;%s&apos; (must be at least the dust limit of %s to prevent stuck transactions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect/-noconnect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reduce storage requirements by enabling pruning (deleting) of old blocks. This allows the pruneblockchain RPC to be called to delete specific blocks, and enables automatic pruning of old blocks if a target size in MiB is provided. This mode is incompatible with -txindex and -rescan. Warning: Reverting this setting requires re-downloading the entire blockchain. (default: 0 = disable pruning blocks, 1 = allow manual pruning via RPC, &gt;%u = automatically prune block files to stay under the specified target size in MiB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set lowest fee rate (in %s/kB) for transactions to be included in block creation. (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sets the serialization of raw transaction or block hex returned in non-verbose mode, non-segwit(0) or segwit(1) (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify directory where to write backups and data dumps (default datadir/backups)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The minimum transaction output size (in %s) used to validate wallet transactions and discard change (to fee) (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard. Paper wallet art provided by Anacoluthia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username and hashed password for JSON-RPC connections. The field &lt;userpw&gt; comes in the format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. A canonical python script is included in share/rpcuser. The client then connects normally using the rpcuser=&lt;USERNAME&gt;/rpcpassword=&lt;PASSWORD&gt; pair of arguments. This option can be specified multiple times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wallet will not create transactions that violate mempool chain limits (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given IP address (e.g. 1.2.3.4) or CIDR notated network (e.g. 1.2.3.0/24). Can be specified multiple times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amaze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chain selection options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many generous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send transactions with full-RBF opt-in enabled (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Such expensive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Namecoin-compatible AuxPow API structure, (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the test chain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID, %i with block height, with a value of 0 if tx is no longer in chaintip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable BIP-70 PaymentServer (default: 0)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
