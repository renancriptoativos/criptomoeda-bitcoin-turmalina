<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>AddPeerDialog</name>
    <message>
        <source>Add Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>右鍵點一下來修改位址或標記</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>產生一個新位址</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>新增</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>複製目前選擇的位址到系統剪貼簿</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>複製</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>關閉</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>把目前選擇的位址從列表中刪掉</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>把目前分頁的資料匯出存成檔案</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>刪掉</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>選擇要付錢過去的位址</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>選擇要收錢進來的位址</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>選取</translation>
    </message>
    <message>
        <source>Such sending addresses</source>
        <translation>付款位址</translation>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation>收款位址</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>這些是你要付款過去的 Bitcoin Turmalina 位址。在付錢之前，務必要檢查金額和收款位址是否正確。</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>這些是你用來收款的 Bitcoin Turmalina 位址。建議在每次交易時，都使用一個新的收款位址。</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>複製位址</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>複製標記</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>匯出位址清單</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>逗點分隔資料檔(*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>匯出失敗</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>儲存位址列表到 %1 時發生錯誤。請重試一次。</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>標記</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>位址</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(無標記)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>密碼對話視窗</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>請輸入密碼</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>新密碼</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>重複新密碼</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>輸入錢包的新密碼。&lt;br/&gt;密碼請用&lt;b&gt;10 個以上的隨機字元&lt;/b&gt;，或是&lt;b&gt;8 個以上的字詞&lt;/b&gt;。</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>加密錢包</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>這個動作需要你的錢包密碼來解鎖錢包。</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>解鎖錢包</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>這個動作需要你的錢包密碼來把錢包解密。</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>解密錢包</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>改變密碼</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>請輸入錢包的舊密碼和新密碼。</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>確認錢包加密</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DOGECOINS&lt;/b&gt;!</source>
        <translation>警告: 如果把錢包加密後又忘記密碼，你就會從此&lt;b&gt;失去其中所有的 Bitcoin Turmalina 了&lt;/b&gt;！</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>你確定要把錢包加密嗎？</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>錢包已加密</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your dogecoins from being stolen by malware infecting your computer.</source>
        <translation>%1 現在要關閉，好完成加密程序。請注意，加密錢包不能完全防止入侵你的電腦的惡意程式偷取錢幣。</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>重要: 請改用新產生有加密的錢包檔，來取代舊錢包檔的備份。為了安全性的理由，當你開始使用新的有加密的錢包後，舊錢包檔的備份就不能再使用了。</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>錢包加密失敗</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>因為內部錯誤導致錢包加密失敗。你的錢包還是沒加密。</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>提供的密碼不一樣。</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>錢包解鎖失敗</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>輸入要用來解密錢包的密碼不對。</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>錢包解密失敗</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>錢包密碼改成功了。</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>警告: 大寫字母鎖定作用中！</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>網路位址/遮罩</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>禁止期限</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>簽署訊息...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>正在跟網路進行同步...</translation>
    </message>
    <message>
        <source>&amp;Wow</source>
        <translation>總覽</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>節點</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>顯示錢包一般總覽</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>交易</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>瀏覽交易紀錄</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>結束</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>結束應用程式</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>關於%1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>顯示 %1 的相關資訊</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>關於 &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>顯示 Qt 相關資訊</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>選項...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>修改 %1 的設定選項</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>加密錢包...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>備份錢包...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>改變密碼...</translation>
    </message>
    <message>
        <source>Such &amp;sending addresses...</source>
        <translation type="vanished">付款位址...</translation>
    </message>
    <message>
        <source>Much &amp;receiving addresses...</source>
        <translation type="vanished">收款位址...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>開啓 URI...</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>按一下就會不使用網路。</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>網路活動關閉了。</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>按一下就又會使用網路。</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>正在同步前導資料(%1%)中...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>正在為磁碟裡的區塊重建索引...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin Turmalina address</source>
        <translation>付錢給一個 Bitcoin Turmalina 位址</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>把錢包備份到其它地方</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>改變錢包加密用的密碼</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>除錯視窗</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>開啓除錯和診斷主控台</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>驗證訊息...</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina</source>
        <translation>Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>錢包</translation>
    </message>
    <message>
        <source>&amp;Such Send</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>&amp;Much Receive</source>
        <translation>收款</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>顯示或隱藏</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>顯示或隱藏主視窗</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>把錢包中的密鑰加密</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin Turmalina addresses to prove you own them</source>
        <translation>用 Bitcoin Turmalina 位址簽署訊息來證明位址是你的</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin Turmalina addresses</source>
        <translation>驗證訊息是用來確定訊息是用指定的 Bitcoin Turmalina 位址簽署的</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>檔案</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>說明</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>分頁工具列</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and dogecoin: URIs)</source>
        <translation>要求付款(產生 QR Code 和 dogecoin 付款協議的資源識別碼: URI)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>顯示已使用過的付款位址和標記的清單</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>顯示已使用過的收款位址和標記的清單</translation>
    </message>
    <message>
        <source>Open a dogecoin: URI or payment request</source>
        <translation>開啓 dogecoin 協議的資源識別碼(URI)或付款要求</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>命令列選項</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin Turmalina network</source>
        <translation>
            <numerusform>%n 個運作中的 Bitcoin Turmalina 網路連線</numerusform>
        </translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>正在為磁碟裡的區塊建立索引...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>正在處理磁碟裡的區塊資料...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>已經處理了 %n 個區塊的交易紀錄。</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>落後 %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>最近收到的區塊是在 %1 以前生出來的。</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>暫時會看不到在這之後的交易。</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>資訊</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>最新狀態</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin Turmalina command-line options</source>
        <translation>顯示 %1 的說明訊息，來取得可用命令列選項的列表</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1 客戶端軟體</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>正在跟其他節點連線中...</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>正在趕進度...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>日期: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>金額: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>種類: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>標記: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>位址: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>付款交易</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>收款交易</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation>產生 HD 金鑰&lt;b&gt;已經啟用&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>產生 HD 金鑰&lt;b&gt;已經停用&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>錢包&lt;b&gt;已加密&lt;/b&gt;並且&lt;b&gt;解鎖中&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>錢包&lt;b&gt;已加密&lt;/b&gt;並且&lt;b&gt;上鎖中&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Bitcoin Turmalina can no longer continue safely and will quit.</source>
        <translation>發生了致命的錯誤。Bitcoin Turmalina 軟體沒辦法再繼續安全執行，只好結束。</translation>
    </message>
    <message>
        <source>&amp;Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print paper wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Such sending addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Much receiving addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import a Bitcoin Turmalina private key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>選擇錢幣</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>數目:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>位元組數:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>金額:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>手續費:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>零散錢:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>計費後金額:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>找零金額:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>全選或全不選</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>樹狀模式</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>列表模式</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>收款標記</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>收款位址</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>確認次數</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>已確認</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>複製位址</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>複製標記</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>複製金額</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>複製交易識別碼</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>鎖定不用</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>解鎖可用</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>複製數目</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>複製手續費</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>複製計費後金額</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>複製位元組數</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>複製零散金額</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>複製找零金額</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(鎖定 %1 枚)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>no</source>
        <translation>否</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation>當任何一個收款金額小於目前的零散金額上限時，文字會變紅色。</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu(s) per input.</source>
        <translation type="vanished">每組輸入可能有 +/- %1 個 koinu 的誤差。</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(無標記)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>找零前是 %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(找零)</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu per input.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>編輯位址</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>標記</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>跟這個位址簿項目關聯的標記</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>跟這個位址簿項目關聯的位址。只有付款位址能被修改。</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>位址</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>造新的收款位址</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>造新的付款位址</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>編輯收款位址</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>編輯付款位址</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Bitcoin Turmalina address.</source>
        <translation>輸入的位址 %1 並不是有效的 Bitcoin Turmalina 位址。</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>輸入的位址 %1 在位址簿中已經有了。</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>沒辦法把錢包解鎖。</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>產生新的密鑰失敗了。</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>就要產生新的資料目錄。</translation>
    </message>
    <message>
        <source>name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>已經有這個目錄了。如果你要在裡面造出新的目錄的話，請加上 %1.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>已經有指定的路徑了，並且不是一個目錄。</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>沒辦法在這裡造出資料目錄。</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>版本</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1 位元)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>關於 %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>命令列選項</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>用法:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>命令列選項</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>使用介面選項:</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>啓動時選擇資料目錄(預設值: %u)</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>設定語言，比如說 de_DE (預設值: 系統語系)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>啓動時縮到最小</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>設定付款請求時所使用的 SSL 根憑證(預設值: 系統憑證庫)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>顯示啓動畫面(預設值: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>重置所有在使用界面更改的設定</translation>
    </message>
</context>
<context>
    <name>ImportKeysDialog</name>
    <message>
        <source>Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import Private Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private key to import into your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label for this private key in your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label (optional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset this form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">取消</translation>
    </message>
    <message>
        <source>Invalid private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid address generated from private key; please check and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to add private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation type="unfinished">正在重新掃描...</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>歡迎</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>歡迎使用 %1。</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>因為這是程式第一次啓動，你可以選擇 %1 儲存資料的地方。</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Bitcoin Turmalina block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 會下載並儲存一份 Bitcoin Turmalina 區塊鏈的拷貝。至少有 %2GB 的資料會儲存到這個目錄中，並且還會持續增長。另外錢包資料也會儲存在這個目錄。</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>使用預設的資料目錄</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>使用自訂的資料目錄:</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation>錯誤: 無法新增指定的資料目錄: %1</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation>
            <numerusform>可用空間尚存 %n GB</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation>
            <numerusform>(需要 %n GB)</numerusform>
        </translation>
    </message>
    <message>
        <source>Choose data directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet&apos;s balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the dogecoin network, as detailed below.</source>
        <translation>最近的交易可能還看不到，因此錢包餘額可能不正確。在錢包軟體完成跟 dogecoin 網路的同步後，這裡的資訊就會正確。詳情請見下面。</translation>
    </message>
    <message>
        <source>Attempting to spend dogecoins that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation>使用還沒顯示出來的交易所影響到的 dogecoin 可能會不被網路所接受。</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>剩餘區塊數</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>不明...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>最近區塊時間</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>進度</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation>每小時進度</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>正在計算中...</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>預估完成同步所需時間</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>隱藏</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1)...</source>
        <translation>不明。正在同步前導資料(%1)中...</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>開啓 URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>從 URI 或檔案開啟付款要求</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>選擇付款要求資料檔</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>選擇要開啟的付款要求資料檔</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>選項</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>在登入系統後自動啓動 %1。</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>系統登入時啟動 %1</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>資料庫快取大小</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB (百萬位元組)</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>指令碼驗證執行緒數目</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>接受外來連線</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>接受外來連線</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>代理伺服器的網際網路位址(像是 IPv4 的 127.0.0.1 或 IPv6 的 ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>當視窗關閉時，把應用程式縮到最小，而不是結束。當勾選這個選項時，只能夠用選單中的結束來關掉應用程式。</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>在交易頁籤的情境選單出現的第三方網址連結(URL)，比如說區塊探索網站。網址中的 %s 會被取代為交易的雜湊值。可以用直線符號 | 來分隔多個連結。</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>交易的第三方網址連結</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>從命令列取代掉以上設定的選項有:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>重設所有客戶端軟體選項成預設值。</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>重設選項</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>網路</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 表示程式自動決定，小於 0 表示保留處理器核心不用的數目)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>錢包</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>專家</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>開啟錢幣控制功能</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>如果你關掉「可以花還沒確認的零錢」，那麼交易中找零的零錢就必須要等交易至少有一次確認後，才能夠使用。這也會影響餘額的計算方式。</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>可以花還沒確認的零錢</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin Turmalina client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>自動在路由器上開放 Bitcoin Turmalina 的客戶端通訊埠。只有在你的路由器支援且開啓「通用即插即用」協定(UPnP)時才有作用。</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>用 &amp;UPnP 設定通訊埠對應</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a SOCKS5 proxy.</source>
        <translation>透過 SOCKS5 代理伺服器來連線到 Bitcoin Turmalina 網路。</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>透過 SOCKS5 代理伺服器連線(預設代理伺服器):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>代理位址:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>埠號:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>代理伺服器的通訊埠(像是 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>用來跟其他節點聯絡的中介:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>如果對這種網路類型，有指定用來跟其他節點聯絡的 SOCKS5 代理伺服器的話，就會顯示在這裡。</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>透過另外的 SOCKS5 代理伺服器來連線到 Bitcoin Turmalina 網路中的 Tor 隱藏服務。</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>用另外的 SOCKS5 代理伺服器，來透過 Tor 隱藏服務跟其他節點聯絡:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>視窗</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>不在通知區顯示圖示。</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>不顯示通知區圖示</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>視窗縮到最小後只在通知區顯示圖示。</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>縮到最小到通知區而不是工作列</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>關閉時縮到最小</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>顯示</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>使用界面語言:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>可以在這裡設定使用者介面的語言。這個設定在重啓 %1 後才會生效。</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>金額顯示單位:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>選擇操作界面和付款時，預設顯示金額的細分單位。</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>是否要顯示錢幣控制功能。</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>好</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>default</source>
        <translation>預設值</translation>
    </message>
    <message>
        <source>none</source>
        <translation>無</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>確認重設選項</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>需要重新啟動客戶端軟體來讓改變生效。</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>客戶端軟體就要關掉了。繼續做下去嗎？</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>這項改變需要重新啟動客戶端軟體。</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>提供的代理伺服器位址無效。</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>表單</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin Turmalina network after a connection is established, but this process has not completed yet.</source>
        <translation>顯示的資訊可能是過期的。跟 Bitcoin Turmalina 網路的連線建立後，你的錢包會自動和網路同步，但是這個步驟還沒完成。</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>只能看:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>可用金額:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>目前可用餘額</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>未定金額:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>還沒被確認的交易的總金額，可用餘額不包含這些金額</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>未成熟金額:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>還沒成熟的開採金額</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>餘額</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>總金額:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>目前全部餘額</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>所有只能看位址的目前餘額</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>可支配:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>最近的交易</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>所有只能看位址還沒確認的交易</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>所有只能看位址還沒成熟的開採金額</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>所有只能看位址的目前全部餘額</translation>
    </message>
    <message>
        <source>Helpful tip of the day:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your wallet.dat file with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>For advanced operations, use the console in &apos;Help&apos; -&gt; &apos;Debug Window&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encrypt your wallet with a strong passphrase for maximum security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make sure to keep your wallet software updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backup your private key to recover your coins, using &apos;File&apos; &gt; &apos;Backup Wallet&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always do your own research before using an external cryptocurrency service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never share your private key with anyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Who owns the private keys, owns the coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To see ongoing development and contribute, check out the Bitcoin Turmalina Core repository on GitHub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Services that claim to double your dogecoins are always ponzi schemes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaperWalletDialog</name>
    <message>
        <source>Print Your Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very New Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>So Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many Wallets?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Network Activity Detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is recommended to disconnect from the internet before printing paper wallets. Even though paper wallets are generated on your local computer, it is still possible to unknowingly have malware that transmits your screen to a remote location. It is also recommended to print to a local printer vs a network printer since that network traffic can be monitored. Some advanced printers also store copies of each printed document. Proceed with caution relative to the amount of value you plan to store on each address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding Address into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error encoding private key into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>failed to open file, is it writable?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Paper Wallets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The paper wallet printing process has begun.&lt;br/&gt;Please wait for the wallets to print completely and verify that everything printed correctly.&lt;br/&gt;Check for misalignments, ink bleeding, smears, or anything else that could make the private keys unreadable.&lt;br/&gt;Now, enter the number of BTURM you wish to send to each wallet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper wallet %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Coins</source>
        <translation type="unfinished">付款</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0</source>
        <translation type="unfinished">付款金額必須大於零。 {0?}</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished">金額超過餘額了。</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the transaction fee is included</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation type="unfinished">製造交易失敗了！</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished">你確定要付錢出去嗎？</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation type="unfinished">加做交易手續費</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">或</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation type="unfinished">確認付款金額</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>要求付款時發生錯誤</translation>
    </message>
    <message>
        <source>Cannot start dogecoin: click-to-pay handler</source>
        <translation>沒辦法啟動 dogecoin 協議的「按就付」處理器</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>URI 處理</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>取得付款要求的 URL 無效: %1</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>無效的付款位址 %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Bitcoin Turmalina address or malformed URI parameters.</source>
        <translation>沒辦法解析 URI 位址！可能是因為 Bitcoin Turmalina 位址無效，或是 URI 參數格式錯誤。</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>處理付款要求檔案</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>沒辦法讀取付款要求檔案！可能是無效的檔案造成的。</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>付款的要求被拒絕了</translation>
    </message>
    <message>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation>付款要求的網路類型跟客戶端不符。</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>付款的要求過期了。</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>付款的要求沒有完成初始化。</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>不支援含有自訂付款指令碼，且沒驗證過的付款要求。</translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation>付款的要求無效。</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation type="vanished">要求付款的金額 %1 太少(會被網路認為是沒必要的零散錢)。</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>來自 %1 的退款</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>付款要求 %1 過大 (%2 位元組, 上限 %3 位元組).</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>跟 %1 通訊時發生錯誤: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>沒辦法解析付款要求內容！</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>伺服器 %1 的回應有誤</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>發出要求時發生網路錯誤</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>付款已確認</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (below discard threshold).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BIP70 payment requests are deprecated and disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment request file handling is disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>使用者代理</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>節點/服務</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation>節點識別碼</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Ping  時間</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTools</name>
    <message>
        <source>Error: Node address is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Peer-to-peer functionality missing or disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to one try node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: Unable to add node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node not found in connected nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnected the node: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Returned OK.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Enter a Bitcoin Turmalina address (e.g. %1)</source>
        <translation>輸入 Bitcoin Turmalina 位址 (比如說 %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 天</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 小時</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 分鐘</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 秒</translation>
    </message>
    <message>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 毫秒</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n 秒鐘</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n 分鐘</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation>
            <numerusform>%n 小時</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation>
            <numerusform>%n 天</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation>
            <numerusform>%n 星期</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1又 %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation>
            <numerusform>%n 年</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation>%1 還沒有安全地結束...</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation type="unfinished">%1 B (位元組)</translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB (百萬位元組)</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>錯誤: 不存在指定的資料目錄 &quot;%1&quot; 。</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>錯誤: 沒辦法解析設定檔: %1。只能用「名稱=設定值」這種語法。</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>錯誤: %1</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>儲存圖片...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>複製圖片</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>儲存 QR Code</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG 圖檔(*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>客戶端軟體版本</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>資訊</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>除錯視窗</translation>
    </message>
    <message>
        <source>General</source>
        <translation>普通</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>使用 BerkeleyDB 版本</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>資料目錄</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>啓動時間</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>網路</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>連線數</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>區塊鏈</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>目前區塊數</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>記憶體暫存池</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>目前交易數目</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>記憶體使用量</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>收到</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>送出</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>節點</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>被禁節點</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>選一個節點來看詳細資訊</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>列在白名單</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>起始區塊</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>已同步前導資料</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>已同步區塊</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>使用者代理</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>從目前的資料目錄下開啓 %1 的除錯紀錄檔。當紀錄檔很大時，可能會花好幾秒的時間。</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>縮小文字</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>放大文字</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>服務</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>惡劣分數</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>連線時間</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>最近送出</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>最近收到</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping 時間</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>目前這一次 ping 已經過去的時間。</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Ping 等待時間</translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation>Ping 最短時間</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>時間差</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>最近區塊時間</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>開啓</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>主控台</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>網路流量</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>清掉</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>總計</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>來:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>去:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>除錯紀錄檔</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>清主控台</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 小時</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 天</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 星期</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 年</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>斷線</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>禁止連線</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>連線解禁</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>歡迎使用 %1 的 RPC 主控台。</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>請用上下游標鍵來瀏覽先前指令的紀錄，並用 &lt;b&gt;Ctrl-L&lt;/b&gt; 來清畫面。</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>請打 &lt;b&gt;help&lt;/b&gt; 來看可用指令的簡介。</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramification of a command.</source>
        <translation>警告:  已知有詐騙集團會叫人在這個畫面輸入指令，以偷取他們錢包的內容物。請不要在沒有充分理解指令可能造成後果的情況下使用主控台。</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation>網路活動已關閉</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B (位元組)</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB (千位元組)</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB (百萬位元組)</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB (十億位元組)</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(節點識別碼: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>經由 %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>沒有過</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>進來</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>出去</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>不明</translation>
    </message>
    <message>
        <source>Connected peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add new peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One try peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <source>Remove Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove the peer: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No peer was selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>金額:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>標記:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>訊息:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>重複使用先前使用過的收款位址。重複使用位址會有安全和隱私方面的問題。除非是要重新產生先前的付款要求，不然請不要使用。</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>重複使用現有的收款位址(不建議)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin Turmalina network.</source>
        <translation>附加在付款要求中的訊息，可以不填，打開要求內容時會顯示。注意: 這個訊息不會隨著付款送到 Bitcoin Turmalina 網路上。</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>跟新收款位址關聯的標記，可以不填。</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>請用這份表單來要求付款。所有欄位都&lt;b&gt;可以不填&lt;/b&gt;。</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>要求付款的金額，可以不填。不確定金額時可以留白或是填零。</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>把表單中的所有欄位清空。</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>先前要求付款的記錄</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>要求付款</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>顯示選擇的要求內容(效果跟按它兩下一樣)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>顯示</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>從列表中刪掉選擇的項目</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>刪掉</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>複製 URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>複製標記</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>複製訊息</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>複製金額</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR Code</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>複製 URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>複製位址</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>儲存圖片...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>付款給 %1 的要求</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>付款資訊</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>位址</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標記:</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>訊息</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>產生的 URI 過長，請試著縮短標記或訊息的文字內容。</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>把 URI 編碼成 QR Code 時發生錯誤。</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標記:</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>訊息</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(無標記)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(無訊息)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(無要求金額)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>要求金額</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>錢幣控制功能</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>輸入...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>自動選擇</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>累計金額不足！</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>數目:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>位元組數:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>金額:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>手續費:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>計費後金額:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>找零金額:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>如果這項有打開，但是找零位址是空的或無效，那麼找零的錢會送到一個新產生的位址去。</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>自訂找零位址</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>交易手續費:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>選項...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>展開手續費設定</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>每千位元組</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 koinu and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 koinu in fee, while &quot;total at least&quot; pays 1000 koinu. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>如果自訂手續費設定為 1000 koinu, 而交易資料大小只有 250 個位元組的話，那麽選擇「每千位元組」就只會付 250 koinu 的手續費，換做選「總共至少」就會付 1000 koinu. 但是如果交易資料大小超過一千個位元組，那麽兩者都是每千位元組的費用。</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>隱藏</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>總共最少</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for dogecoin transactions than the network can process.</source>
        <translation>當交易量少於區塊可容納的空間時，只付最低手續費不會有什麽問題。但是當交易量的需求成長到超過整體網路可以處理的量時，可能會造成一筆一直不會被確認的交易。</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(請看提示)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>建議值:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>自訂:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation type="vanished">(手續費智慧演算法還沒準備好。通常都要等幾個區塊才行...)</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="vanished">正常</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="vanished">快速</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>一次付給多個收款人</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>增加收款人</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>把表單中的所有欄位清空。</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>零散錢:</translation>
    </message>
    <message>
        <source>Confirmation time target:</source>
        <translation type="vanished">目標確認時間:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>全部清掉</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>餘額:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>確認付款動作</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>複製數目</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>複製金額</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>複製手續費</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>複製計費後金額</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>複製位元組數</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>複製零散金額</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>複製找零金額</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 給 %2</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>你確定要付錢出去嗎？</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>加做交易手續費</translation>
    </message>
    <message>
        <source>Total Amount %1</source>
        <translation>總金額 %1</translation>
    </message>
    <message>
        <source>or</source>
        <translation>或</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>確認付款金額</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation>收款位址無效。請再檢查看看。</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>付款金額必須大於零。</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>金額超過餘額了。</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>包含 %1 的交易手續費後，總金額超過你的餘額了。</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation>發現有重複的位址: 每個位址只能出現一次。</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>製造交易失敗了！</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>交易因為以下原因被拒絕了: %1</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>高於 %1 的手續費會被認為是不合理。</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>付款的要求過期了。</translation>
    </message>
    <message numerus="yes">
        <source>%n block(s)</source>
        <translation type="vanished">
            <numerusform>%n 個區塊</numerusform>
        </translation>
    </message>
    <message>
        <source>Pay only the required fee of %1</source>
        <translation>只付必要的手續費 %1</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin Turmalina address</source>
        <translation>警告: Bitcoin Turmalina 位址無效</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>警告: 不明的找零位址</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation>自定找零位址確認</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>選擇的找零位址並不屬於這個錢包。部份或是全部的錢會被送到這個位址去。你確定嗎？</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(無標記)</translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 satoshis in fee, while &quot;total at least&quot; pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>金額:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>付給:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>標記:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>選擇先前使用過的位址</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>這是一筆正常的付款。</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to send the payment to</source>
        <translation>接收付款的 Bitcoin Turmalina 位址</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>貼上剪貼簿裡的位址</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>刪掉這個項目</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less dogecoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>手續費會從要付款出去的金額中扣掉。因此收款人會收到比輸入的金額還要少的 dogecoin。如果有多個收款人的話，手續費會平均分配來扣除。</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>從付款金額減去手續費</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>訊息:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>這是個沒有驗證過身份的付款要求。</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>這是個已經驗證過身份的付款要求。</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>請輸入這個位址的標記，來把它加進去已使用過位址的清單。</translation>
    </message>
    <message>
        <source>A message that was attached to the dogecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin Turmalina network.</source>
        <translation>附加在 Bitcoin Turmalina 付款協議的資源識別碼(URI)中的訊息，會和交易內容一起存起來，給你自己做參考。注意: 這個訊息不會送到 Bitcoin Turmalina 網路上。</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>付給:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>備註:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>請輸入這個位址的標記來把它加進位址簿中</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>正在關閉 %1 中...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation> 在這個視窗不見以前，請不要關掉電腦。</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>簽章 - 簽署或驗證訊息</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>簽署訊息</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive dogecoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>你可以用自己的位址簽署訊息或合約，來證明你可以從該位址收款。但是請小心，不要簽署語意含糊不清，或隨機產生的內容，因為釣魚式詐騙可能會用騙你簽署的手法來冒充是你。只有在語句中的細節你都同意時才簽署。</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to sign the message with</source>
        <translation>用來簽署訊息的 Bitcoin Turmalina 位址</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>選擇先前使用過的位址</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>貼上剪貼簿裡的位址</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>請在這裡輸入你想簽署的訊息</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>簽章</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>複製目前的簽章到系統剪貼簿</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin Turmalina address</source>
        <translation>簽署這個訊息來證明這個 Bitcoin Turmalina 位址是你的</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>簽署訊息</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>重設所有訊息簽署欄位</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>全部清掉</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>驗證訊息</translation>
    </message>
    <message>
        <source>Enter the receiver&apos;s address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>請在下面輸入收款人的位址，訊息(請確定完整複製了所包含的換行，空格，跳位符號等等)，以及簽章，來驗證這個訊息。請小心，除了訊息內容以外，不要對簽章本身過度解讀，以避免被用「中間人攻擊法」詐騙。請注意，通過驗證的簽章只能證明簽章人確實可以從該位址收款，不能證明任何交易中的付款人身份！</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address the message was signed with</source>
        <translation>簽署這個訊息的 Bitcoin Turmalina 位址</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin Turmalina address</source>
        <translation>驗證這個訊息來確定是用指定的 Bitcoin Turmalina 位址簽署的</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>驗證訊息</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>重設所有訊息驗證欄位</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>請按一下「簽署訊息」來產生簽章</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>輸入的位址無效。</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>請檢查位址是否正確後再試一次。</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>輸入的位址沒有對應到你的任何密鑰。</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>錢包解鎖已取消。</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>沒有對應輸入位址的密鑰。</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>訊息簽署失敗。</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>訊息簽署好了。</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>沒辦法把這個簽章解碼。</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>請檢查簽章是否正確後再試一次。</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>這個簽章跟訊息的數位摘要不符。</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>訊息驗證失敗。</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>訊息驗證沒錯。</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TestPeerDialog</name>
    <message>
        <source>Test Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try Peer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>到下 %n 個區塊生出來前可修改</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>到 %1 前可修改</translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation>跟一個目前確認 %1 次的交易互相衝突</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation type="vanished">%1 次/離線中</translation>
    </message>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation>0 次/未確認，%1</translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation>在記憶池中</translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation>不在記憶池中</translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation>已中止</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1 次/未確認</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>確認 %1 次</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>狀態</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation type="vanished">，還沒成功公告出去</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation type="vanished">
            <numerusform>，已公告給 %n 個節點</numerusform>
        </translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>來源</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>生產出來</translation>
    </message>
    <message>
        <source>From</source>
        <translation>來源</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>To</source>
        <translation>目的</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>自己的位址</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>只能看</translation>
    </message>
    <message>
        <source>label</source>
        <translation>標記</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>入帳</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>再等 %n 個區塊生出來後成熟</numerusform>
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>不被接受</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>出帳</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>出帳總額</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>入帳總額</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>交易手續費</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>淨額</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>訊息</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>附註</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>交易識別碼</translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation>交易總大小</translation>
    </message>
    <message>
        <source>Output index</source>
        <translation>輸出索引</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>商家</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>生產出來的錢要再等 %1 個區塊生出來後才成熟可以用。當區塊生產出來時會公布到網路上，來被加進區塊鏈。如果加失敗了，狀態就會變成「不被接受」，而且不能夠花。如果在你生產出區塊的幾秒鐘內，也有其他節點生產出來的話，就有可能會發生這種情形。</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>除錯資訊</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>交易</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>輸入</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>金額</translation>
    </message>
    <message>
        <source>true</source>
        <translation>是</translation>
    </message>
    <message>
        <source>false</source>
        <translation>否</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>這個版面顯示這次交易的詳細說明</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation>交易 %1 的明細</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>種類</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標記:</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation>
            <numerusform>到下 %n 個區塊生出來前可修改</numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>到 %1 前可修改</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation type="vanished">離線中</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>未確認</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation>已中止</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>確認中(已經 %1 次，建議至少 %2 次)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>已確認(%1 次)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>有衝突</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>未成熟(確認 %1 次，會在 %2 次後可用)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation type="vanished">沒有其他節點收到這個區塊，也許它不會被接受！</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>生產出來但是不被接受</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>收款</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>收款自</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>付給自己</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>開採所得</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>只能看</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(不適用)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(無標記)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>交易狀態。把游標停在欄位上會顯示確認次數。</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>收到交易的日期和時間。</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>交易的種類。</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>不論如何有一個只能觀看的地只有參與這次的交易</translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation>使用者定義的交易動機或理由。</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>要減掉或加進餘額的金額。</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>這星期</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>這個月</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>上個月</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>今年</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>指定範圍...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>收款</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>付款</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>給自己</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>開採所得</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>其它</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>請輸入要搜尋的位址或標記</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>最小金額</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>中止交易</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>複製位址</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>複製標記</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>複製金額</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>複製交易識別碼</translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation>複製交易原始資料</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>複製完整交易明細</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>編輯標記</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>顯示交易明細</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>匯出交易記錄</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>逗點分隔資料檔(*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>已確認</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>只能觀看的</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>種類</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標記:</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>位址</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>識別碼</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>匯出失敗</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>儲存交易記錄到 %1 時發生錯誤。</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>匯出成功</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>交易記錄已經成功儲存到 %1 了。</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>範圍:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>到</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>金額顯示單位。可以點選其他單位。</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>沒有載入錢包。</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>付款</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>匯出</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>將目前分頁的資料匯出存成檔案</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>備份錢包</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>錢包資料檔(*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>備份失敗</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>儲存錢包資料到 %1 時發生錯誤。</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>備份成功</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>錢包的資料已經成功儲存到 %1 了。</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>選項:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>指定資料目錄</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>連線到某個節點來取得其它節點的位址，然後斷線</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>指定自己的公開位址</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>接受指令列和 JSON-RPC 指令
</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect/-noconnect)</source>
        <translation>是否接受外來連線(預設值: 當沒有 -proxy 或 -connect/-noconnect 時為 1)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s); -noconnect or -connect=0 alone to disable automatic connections</source>
        <translation>只連線到指定的節點。用 -noconnect 或是 -connect=0 可以關閉自動連線。</translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation>依據 MIT 軟體授權條款散布，詳情請見附帶的 %s 檔案或是 %s</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>如果沒有提供 &lt;category&gt; 或是值為 1 就會輸出所有的除錯資訊。</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>設定的修剪值小於最小需求的 %d 百萬位元組(MiB)。請指定大一點的數字。</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>修剪模式：錢包的最後同步狀態是在被修剪掉的區塊資料中。你需要用 -reindex 參數執行(會重新下載整個區塊鏈)</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>在修剪模式下沒辦法重新掃描區塊鏈。你需要配合使用 -reindex 參數來重新下載整個區塊鏈。</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>錯誤: 發生了致命的內部錯誤，詳情請看 debug.log</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>交易付款時每千位元組(kB)的交易手續費(單位是 %s，預設值: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>正在修剪區塊資料庫中...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>用護靈模式在背景執行並接受指令</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>無法啟動 HTTP 伺服器。詳情請看除錯紀錄。</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina Core</source>
        <translation>Bitcoin Turmalina Core</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>%s 開發人員</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>當沒有足夠的資料計算預估手續費時，所使用的手續費費率(單位是 %s/kB, 預設值: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>接受從白名點節點收到的轉發交易，即使沒有(符合準則)轉發出去(預設值: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>和指定的位址繫結，並且一直在指定位址聽候連線。IPv6 請用 [主機]:通訊埠 這種格式</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>沒辦法鎖定資料目錄 %s。%s 可能已經在執行了。</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>清掉錢包裡的所有交易，並且在下次啟動時，使用 -rescan 來從區塊鏈中復原回來。</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t enable HD on a already existing non-HD wallet</source>
        <translation>載入 %s 發生錯誤：不能對已存在的非 HD 錢包啟用 HD 功能。</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>讀取錢包檔 %s 時發生錯誤！所有的密鑰都正確讀取了，但是交易資料或位址簿資料可能會缺少或不正確。</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation type="vanished">當錢包有交易改變時要執行的指令(指令中的 %s 會被取代成交易識別碼)</translation>
    </message>
    <message>
        <source>Extra transactions to keep in memory for compact block reconstructions (default: %u)</source>
        <translation>為了將摘要區塊完整回組而額外保留在記憶體中的交易數量(預設值: %u)</translation>
    </message>
    <message>
        <source>If this block is in the chain assume that it and its ancestors are valid and potentially skip their script verification (0 to verify all, default: %s, testnet: %s)</source>
        <translation>假設已經在區塊鏈中的區塊以及其先前的區塊都合法，因此對它們略過指令碼驗證(0 表示一律要驗證，預設值: %s, 測試網路: %s)</translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation>跟其他節點的時間差最高可接受的中位數值。本機所認為的時間可能會被其他節點影響，往前或往後在這個值之內。(預設值: %u 秒)</translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation>允許一次錢包交易或未加工交易付出的最高總手續費(單位是 %s)；設定太低的話，可能會無法進行資料量大的交易(預設值: %s)</translation>
    </message>
    <message>
        <source>Please check that your computer&apos;s date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>請檢查電腦日期和時間是否正確！%s 沒辦法在時鐘不準的情況下正常運作。</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>如果你覺得 %s 有用，可以幫助我們。關於這個軟體的更多資訊請見 %s。</translation>
    </message>
    <message>
        <source>Reduce storage requirements by enabling pruning (deleting) of old blocks. This allows the pruneblockchain RPC to be called to delete specific blocks, and enables automatic pruning of old blocks if a target size in MiB is provided. This mode is incompatible with -txindex and -rescan. Warning: Reverting this setting requires re-downloading the entire blockchain. (default: 0 = disable pruning blocks, 1 = allow manual pruning via RPC, &gt;%u = automatically prune block files to stay under the specified target size in MiB)</source>
        <translation>修剪(刪除)掉老舊區塊以降低需要的儲存空間。這樣會增加一個 RPC 指令 pruneblockchain，可以使用它來刪除指定的區塊；也可以指定目標儲存空間大小，以啟用對老舊區塊的自動修剪功能。這個模式跟 -txindex 和 -rescan 參數不相容。警告: 還原回不修剪模式會需要重新下載一整個區塊鏈。(預設值: 0 表示不修剪區塊，1 表示允許使用 RPC 指令做修剪，&gt;%u 的值表示為區塊資料的目標大小，單位是百萬位元組，MiB)</translation>
    </message>
    <message>
        <source>Set lowest fee rate (in %s/kB) for transactions to be included in block creation. (default: %s)</source>
        <translation>設定製造區塊時，所要包含交易每千位元組的最低手續費(單位是 %s)。(預設值: %s)</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>設定指令碼驗證的執行緒數目 (%u 到 %d，0 表示程式自動決定，小於 0 表示保留處理器核心不用的數目，預設值: %d)</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer&apos;s date and time being set incorrectly. Only rebuild the block database if you are sure that your computer&apos;s date and time are correct</source>
        <translation>區塊資料庫中有來自未來的區塊。可能是你電腦的日期時間不對。如果確定電腦日期時間沒錯的話，就重建區塊資料庫看看。</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>這是個還沒發表的測試版本 - 使用請自負風險 - 請不要用來開採或做商業應用</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>沒辦法將資料庫倒轉回分岔前的狀態。必須要重新下載區塊鍊。</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>是否要使用「通用即插即用」協定(UPnP)，來設定聽候連線的通訊埠的對應(預設值: 當有聽候連線且沒有指定 -proxy 參數時為 1)</translation>
    </message>
    <message>
        <source>Username and hashed password for JSON-RPC connections. The field &lt;userpw&gt; comes in the format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. A canonical python script is included in share/rpcuser. The client then connects normally using the rpcuser=&lt;USERNAME&gt;/rpcpassword=&lt;PASSWORD&gt; pair of arguments. This option can be specified multiple times</source>
        <translation>JSON-RPC 連線要用的使用者名稱和雜湊密碼。&lt;userpw&gt; 的格式是：&lt;使用者名稱&gt;:&lt;調味值&gt;$&lt;雜湊值&gt;。在 share/rpcuser 目錄下有一個示範的 python 程式。之後客戶端程式就可以用這對參數正常連線：rpcuser=&lt;使用者名稱&gt; 和 rpcpassword=&lt;密碼&gt;。這個選項可以給很多次。</translation>
    </message>
    <message>
        <source>Wallet will not create transactions that violate mempool chain limits (default: %u)</source>
        <translation>錢包軟體不會產生違反記憶池交易鏈限制的交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>警告: 位元幣網路對於區塊鏈結的決定目前有分歧！有些礦工看來會有問題。</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>警告: 我們和某些連線的節點對於區塊鏈結的決定不同！你可能需要升級，或是需要等其它的節點升級。</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>改變 -txindex 參數後，必須要用 -reindex-chainstate 參數來重建資料庫</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>錢包檔 %s 壞掉了，搶救失敗</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>參數 -maxmempool 至少要給 %d 百萬位元組(MB)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; 可以是:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>對使用者代理字串添加註解</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>啟動時嘗試從壞掉的錢包檔復原密鑰</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>區塊製造選項:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: &apos;%s&apos;</source>
        <translation>沒辦法解析 -%s 參數指定的位址: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Chain selection options:</source>
        <translation>區塊鏈選項:</translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation>找零的索引值超出範圍</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>連線選項:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>版權所有 (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>發現區塊資料庫壞掉了</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>除錯與測試選項</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>不要載入錢包，並且拿掉錢包相關的 RPC 功能請求。</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>你想要現在重建區塊資料庫嗎？</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>開啟傳送區塊雜湊值到目標 ZeroMQ 位址 &lt;address&gt; 去</translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation>開啟傳送交易雜湊值到目標 ZeroMQ 位址 &lt;address&gt; 去</translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation>開啟傳送區塊原始資料到目標 ZeroMQ 位址 &lt;address&gt; 去</translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation>開啟傳送交易原始資料到目標 ZeroMQ 位址 &lt;address&gt; 去</translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation>對交易暫存池啟用替代交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>初始化區塊資料庫時發生錯誤</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>初始化錢包資料庫環境 %s 時發生錯誤！</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>載入檔案 %s 時發生錯誤</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>載入檔案 %s 時發生錯誤: 錢包損毀了</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>載入檔案 %s 時發生錯誤: 這個錢包需要新版的 %s</translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t disable HD on a already existing HD wallet</source>
        <translation>載入 %s 發生錯誤：不能對已存在的 HD 錢包停用 HD 功能。</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>載入區塊資料庫時發生錯誤</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>打開區塊資料庫時發生錯誤</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>錯誤: 磁碟空間很少！</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>在任意的通訊埠聽候失敗。如果你希望這樣的話，可以設定 -listen=0.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>正在匯入中...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>創世區塊不正確或找不到。資料目錄錯了嗎？</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>初始化時的基本檢查失敗了。%s 就要關閉了。</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>無效的 -onion 位址: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>參數 -%s=&lt;金額&gt; 指定的金額無效: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>設定 -fallbackfee=&lt;金額&gt; 的金額無效: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>在記憶體暫存池中保持最多 &lt;n&gt; 個百萬位元組的交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>正在載入禁止連線名單中...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>認證 cookie 資料的位置(預設值: 同資料目錄)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>檔案描述元不足。</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>只和 &lt;net&gt; 網路上的節點連線(ipv4, ipv6, 或 onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>顯示說明訊息後結束</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>顯示版本後結束</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>修剪值不能設定為負的。</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>修剪模式和 -txindex 參數不相容。</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>從磁碟裡的區塊檔 blk*.dat 重建區塊鏈狀態和區塊索引</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>從目前已編索引的區塊資料重建區塊鏈狀態</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>正在倒轉回區塊鏈之前的狀態...</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>設定資料庫快取大小是多少百萬位元組(MB，範圍: %d 到 %d，預設值: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>設定區塊大小上限成多少位元組(預設值: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>指定錢包檔(會在資料目錄中)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>原始碼可以在 %s 取得。</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>沒辦法繫結在這台電腦上的 %s 。%s 可能已經在執行了。</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>忽略了不再支援的 -benchmark 參數，請改用 -debug=bench</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>忽略了不再支援的 -debugnet 參數，請改用 -debug=net</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>找到不再支援的 -tor 參數，請改用 -onion 參數。</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>使用通用隨插即用 (UPnP) 協定來設定對應的服務連接埠(預設值: %u)</translation>
    </message>
    <message>
        <source>Use the test chain</source>
        <translation>使用測試區塊鏈</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>使用者代理註解(%s)中含有不安全的字元。</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>正在驗證區塊資料...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>正在驗證錢包資料...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>錢包檔 %s 沒有在資料目錄 %s 裡面</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>錢包除錯與測試選項:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>錢包需要重寫: 請重新啓動 %s 來完成</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>錢包選項:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>允許指定的來源建立 JSON-RPC 連線。&lt;ip&gt; 的有效值可以是一個單獨位址(像是 1.2.3.4)，一個網段/網段罩遮值(像是 1.2.3.4/255.255.255.0)，或是網段/CIDR值(像是 1.2.3.4/24)。這個選項可以設定多次。</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>和指定的位址繫結，並且把連線過來的節點放進白名單。IPv6 請用 [主機]:通訊埠 這種格式</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>和指定的位址繫結以聽候 JSON-RPC 連線。IPv6 請用 [主機]:通訊埠 這種格式。這個選項可以設定多次。(預設值: 跟所有網路界面上的位址繫結)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>用系統預設權限來造出新的檔案，而不是用使用者權限罩遮(umask)值 077 (只有在關掉錢包功能時才有作用)。</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>找出自己的網際網路位址(預設值: 當有聽候連線且沒有指定 -externalip 或 -proxy 時為 1)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>錯誤: 聽候外來連線失敗(回傳錯誤 %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="vanished">當收到相關警示，或發現相當長的分支時，所要執行的指令(指令中的 %s 會被取代成警示訊息)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>當處理轉發的交易、挖礦、或製造交易時，如果每千位元組(kB)的手續費比這個值(單位是 %s)低，就視為沒付手續費(預設值: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>當沒有設定 paytxfee 時，自動包含可以讓交易能在平均 n 個區塊內開始確認的手續費(預設值: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>-maxtxfee=&lt;amount&gt;: &apos;%s&apos; 的金額無效 (必須大於最低轉發手續費 %s 以避免交易無法確認)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>轉發和開採時，對只帶資料的交易的大小上限(預設值: %u)</translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation>對每個代理連線使用隨機產生的憑證。這個選項會開啟 Tor 的串流隔離(預設值: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>設定高優先度或低手續費的交易資料大小上限成多少位元組(預設值: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>扣除手續費後的交易金額太少而不能傳送</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>在 BIP32 開始作用後，啟用階層式可預期性密鑰產生方式(HD)。只有在產生新錢包或第一次啟動時才有作用。</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>在白名單中的節點不會因為偵測到阻斷服務攻擊(DoS)而被停用。來自這些節點的交易也一定會被轉發，即使說交易本來就在記憶池裡了也一樣。適用於像是閘道伺服器。</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>回到非修剪的模式需要用 -reindex 參數來重建資料庫。這會導致重新下載整個區塊鏈。</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(預設值: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>接受公開的REST請求 (預設值: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>自動產生 Tor 隱藏服務(預設值: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>透過 SOCKS5 代理伺服器連線</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>讀取資料庫時發生錯誤，要關閉了。</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>啟動時從其它來源的 blk000??.dat 檔匯入區塊</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>資訊</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation>設定 -paytxfee=&lt;金額&gt; 的金額無效: &apos;%s&apos; (至少要有 %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation>指定在 -whitelist 的網段無效: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>保持最多 &lt;n&gt; 無法連結的交易在記憶體 (預設: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation>指定 -whitebind 時必須包含通訊埠: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>節點轉發選項:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC 伺服器選項:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>因為系統的限制，將 -maxconnections 參數從 %d 降到了 %d</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>啟動時重新掃描區塊鏈，來尋找錢包可能漏掉的交易。</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>在終端機顯示追蹤或除錯資訊，而不是寫到檔案 debug.log 中</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>盡可能送出不用付手續費的交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>顯示所有的除錯選項 (用法: --help --help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>客戶端軟體啓動時把 debug.log 檔縮小(預設值: 當沒有 -debug 時為 1)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>簽署交易失敗</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>交易金額太少而付不起手續費</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>這套軟體屬於實驗性質。</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>Tor 控制埠密碼(預設值: 空白)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>開啟聽候 onion 連線時的 Tor 控制埠號碼(預設值: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>交易金額太小</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>根據交易手續費準則，本交易的位元量過大</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>交易位元量太大</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>無法和這台電腦上的 %s 繫結(回傳錯誤 %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>啟動時把錢包檔案升級成最新的格式</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>JSON-RPC 連線使用者名稱</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>警告: 不明的交易規則被啟用了(versionbit %i)</translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation>是否要用只要區塊模式運作(預設值: %u)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>正在砍掉錢包中的所有交易...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>ZeroMQ 通知選項:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>JSON-RPC 連線密碼</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation type="vanished">當最新區塊改變時要執行的指令(指令中的 %s 會被取代成區塊雜湊值)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>允許對 -addnode, -seednode, -connect 的參數使用域名查詢 </translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>正在載入位址資料...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 表示保留交易描述資料，像是帳戶使用者和付款請求資訊；2 表示丟掉交易描述資料)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>參數 -maxtxfee 設定了很高的金額！這可是你一次交易就有可能付出的最高手續費。</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>不要讓交易留在記憶池中超過 &lt;n&gt; 個小時(預設值: %u)</translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation>轉發和開採時，交易資料中每個 sigop 的等同位元組數(預設值: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>當製造交易時，如果每千位元組(kB)的手續費比這個值(單位是 %s)低，就視為沒付手續費(預設值: %s)</translation>
    </message>
    <message>
        <source>Force relay of transactions from whitelisted peers even if they violate local relay policy (default: %d)</source>
        <translation>強制轉發從白名點節點收到的交易，即使它們違反了本機的轉發準則(預設值: %d)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>使用 -checkblocks 檢查區塊的仔細程度(0 到 4，預設值: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>維護全部交易的索引，用在 getrawtransaction 這個 RPC 請求(預設值: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>避免與亂搞的節點連線的秒數(預設: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>輸出除錯資訊(預設值: %u, 不一定要指定 &lt;category&gt;)</translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect/-noconnect)</source>
        <translation>是否允許在節點位址數目不足時，使用域名查詢來搜尋節點 (預設值: 當沒用 -connect/-noconnect 時為 1)</translation>
    </message>
    <message>
        <source>Sets the serialization of raw transaction or block hex returned in non-verbose mode, non-segwit(0) or segwit(1) (default: %d)</source>
        <translation>設定非冗長模式時，回傳的交易原始資料或區塊位元值的序列化形式：無 segwit 為 0，或是有 segwit 為 1 (預設值: %d)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>支援用布倫過濾器來過濾區塊和交易(預設值: %u)</translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation>這是當預估手續費還沒計算出來時，付款交易預設會付的手續費。</translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard.</source>
        <translation type="vanished">此產品包含了由 OpenSSL Project 所開發的 OpenSSL Toolkit 軟體 %s, 由 Eric Young 撰寫的加解密軟體，以及由 Thomas Bernard 所撰寫的 UPnP 軟體。</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>網路版本字串的總長度(%i)超過最大長度(%i)了。請減少 uacomment 參數的數目或長度。</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>試著保持輸出流量在目標值以下，單位是每 24 小時的百萬位元組(MiB)數，0 表示沒有限制(預設值: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>找到不再支援的 -socks 參數。現在只支援 SOCKS5 協定的代理伺服器，因此不可以指定 SOCKS 協定版本了。</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>忽略不支援的參數 -whitelistalwaysrelay，請改用 -whitelistrelay 和 -whitelistforcerelay​ 的組合。</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>使用另外的 SOCK5 代理伺服器，來透過 Tor 隱藏服務跟其他節點聯絡(預設值: %s)</translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It&apos;s possible unknown rules are in effect</source>
        <translation>警告: 有礦工正在開採不明版本的區塊！這表示有不明的交易規則正在作用中</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>警告: 錢包檔壞掉，但資料被救回來了！原來的檔案 %s 改儲存為 %s，在目錄 %s 下。 如果餘額或交易資料有誤的話，你應該要從備份資料復原回來。</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given IP address (e.g. 1.2.3.4) or CIDR notated network (e.g. 1.2.3.0/24). Can be specified multiple times.</source>
        <translation>把來自指定位址(例如：1.2.3.4)或 CIDR 格式網段(例如：1.2.3.0/24)的節點放進白名單。這個選項可以設定多次。</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation>%s 的設定值異常大！</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(預設值: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>是否一定要用域名查詢來搜尋節點(預設值: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>啓動時檢查的區塊數(預設值: %u, 指定 0 表示全部)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>在除錯輸出內容中包含網際網路位址(預設值: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>無效的 -proxy 位址: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation>密鑰池已經乾了，請先執行 keypoolrefill</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>在通訊埠 &lt;port&gt; 聽候 JSON-RPC 連線(預設值: %u, 或若為測試網路: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>在通訊埠 &lt;port&gt; 聽候連線(預設值: %u, 或若為測試網路: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>維持與節點連線數的上限為 &lt;n&gt; 個(預設值: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>讓錢包能公告交易</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>每個連線的接收緩衝區大小上限為 &lt;n&gt;*1000 個位元組(預設值: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>每個連線的傳送緩衝區大小上限為 &lt;n&gt;*1000 個位元組(預設值: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>在除錯輸出內容前附加時間(預設值: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>允許轉發和開採只帶資料的交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>允許轉發非 P2SH 的多簽章交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Send transactions with full-RBF opt-in enabled (default: %u)</source>
        <translation>送出允許提高手續費(full-RBF)的交易(預設值: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>設定密鑰池大小為 &lt;n&gt; (預設值: %u)</translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation>設定 BIP141 區塊重量的最大值(預設值: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>設定處理 RPC 服務請求的執行緒數目(預設值: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>指定設定檔(預設值: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>指定連線在幾毫秒後逾時 (最少值: 1, 預設值: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>指定行程識別碼檔案(預設值: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>傳送交易時可以花還沒確認的零錢(預設值: %u)</translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation>正在啟動網路執行緒...</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation>錢包軟體會付多於最小轉發費用的手續費。</translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation>這是你每次交易付款時最少要付的手續費。</translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation>這是你交易付款時所要付的手續費。</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>與亂搞的節點斷線的臨界值 (預設: %u)</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation>交易金額不能是負的</translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation>交易造成記憶池中的交易鏈太長</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation>交易必須至少要有一個收款人</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>在 -onlynet 指定了不明的網路別: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>累積金額不足</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>正在載入區塊索引...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>增加一個要連線的節線，並試著保持對它的連線暢通</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>正在載入錢包資料...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>沒辦法把錢包格式降級</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>沒辦法把預設位址寫進去</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>正在重新掃描...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>載入完成</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <source>Bitcoin Core and Bitcoin Turmalina Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-discardthreshold is set very high! This is the output amount that the wallet will discard (to fee) if it is smaller than this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered dust, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered non-standard and will not be accepted or relayed, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash, %i is replaced by block number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid amount for -discardthreshold=&lt;amount&gt;: &apos;%s&apos; (must be at least the dust limit of %s to prevent stuck transactions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify directory where to write backups and data dumps (default datadir/backups)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The minimum transaction output size (in %s) used to validate wallet transactions and discard change (to fee) (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard. Paper wallet art provided by Anacoluthia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amaze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many generous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Such expensive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Namecoin-compatible AuxPow API structure, (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID, %i with block height, with a value of 0 if tx is no longer in chaintip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable BIP-70 PaymentServer (default: 0)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
