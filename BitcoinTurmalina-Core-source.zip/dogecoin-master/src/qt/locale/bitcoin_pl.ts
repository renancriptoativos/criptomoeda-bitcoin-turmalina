<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl">
<context>
    <name>AddPeerDialog</name>
    <message>
        <source>Add Peer</source>
        <translation>Dodaj peera</translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation>Wprowadź szczegóły peera poniżej.</translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation>Bądź ostrożny! Nie ufaj ślepo nikomu, kto każe Ci dodać jego węzeł.</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation>Wprowadź adres peera</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation>Wprowadź port peera</translation>
    </message>
    <message>
        <source>Add!</source>
        <translation>Dodaj!</translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation>Proszę wprowadzić adres.</translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation>Proszę wprowadzić prawidłowy adres peera.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Kliknij prawy przycisk myszy, aby edytować adres lub etykietę</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Utwórz nowy adres</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nowy</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Skopiuj aktualnie wybrany adres do schowka</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiuj</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Z&amp;amknij</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Usuń zaznaczony adres z listy</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportuj dane z aktywnej karty do pliku</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksportuj</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Wybierz adres, na który chcesz wysłać monety</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Wybierz adres, na który chcesz otrzymać monety</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>W&amp;ybierz</translation>
    </message>
    <message>
        <source>Such sending addresses</source>
        <translation>Adresy wysyłania</translation>
    </message>
    <message>
        <source>Much receiving addresses</source>
        <translation>Adresy odbioru</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Tutaj znajdują się adresy Bitcoin Turmalina na które wysyłasz płatności. Zawsze sprawdzaj ilość i adres odbiorcy przed wysyłką monet.</translation>
    </message>
    <message>
        <source>These are your Bitcoin Turmalina addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>To są twoje adresy Bitcoin Turmalina do odbierania płatności. Zaleca się używanie nowych adresów odbiorczych dla każdej transakcji.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Kopiuj adres</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopiuj &amp;Etykietę</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edytuj</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Eksportuj listę adresów</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Plik *.CSV (dane rozdzielane przecinkami)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksportowanie nie powiodło się</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Wystąpił błąd podczas próby zapisu listy adresów do %1. Proszę spróbować ponownie.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(brak etykiety)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Okienko Hasła</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Wpisz hasło</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nowe hasło</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Powtórz nowe hasło</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Wprowadź nowe hasło do portfela.&lt;br/&gt;Proszę używać hasła złożonego z &lt;b&gt;10 lub więcej losowych znaków&lt;/b&gt; albo &lt;b&gt;8 lub więcej słów.&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Zaszyfruj portfel</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Ta operacja wymaga hasła do portfela aby odblokować portfel.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Odblokuj portfel</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Ta operacja wymaga hasła portfela, aby go odszyfrować.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Odszyfruj portfel</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Zmień hasło</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Podaj stare i nowe hasło do portfela.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Potwierdź szyfrowanie portfela</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DOGECOINS&lt;/b&gt;!</source>
        <translation>Uwaga: jeśli zaszyfrujesz swój portfel i zgubisz hasło &lt;b&gt;STRACISZ WSZYSTKIE SWOJE DOGECOINY&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Jesteś pewien, że chcesz zaszyfrować swój portfel?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Portfel zaszyfrowany</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your dogecoins from being stolen by malware infecting your computer.</source>
        <translation>%1 zamknie się aby dokończyć proces szyfrowania. Pamiętaj, że szyfrowanie portfela nie zabezpiecza w pełni Twoich Dogecoinów przed kradzieżą przez wirusy lub trojany mogące zainfekować Twój komputer.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>WAŻNE: Wszystkie wykonane wcześniej kopie pliku portfela powinny być zamienione na nowe, szyfrowane pliki. Z powodów bezpieczeństwa, poprzednie kopie nieszyfrowanych plików portfela staną się bezużyteczne jak tylko zaczniesz korzystać z nowego, szyfrowanego portfela.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Szyfrowanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Szyfrowanie portfela nie powiodło się z powodu wewnętrznego błędu. Twój portfel nie został zaszyfrowany.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Podane hasła nie są takie same.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Odblokowanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Wprowadzone hasło do odszyfrowania portfela jest niepoprawne.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Odszyfrowanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Hasło do portfela zostało pomyślnie zmienione.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Ostrzeżenie: Caps Lock jest włączony!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP / maska podsieci</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Blokada do</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Podpisz wiado&amp;mość...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronizacja z siecią...</translation>
    </message>
    <message>
        <source>&amp;Wow</source>
        <translation>P&amp;odsumowanie</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Węzeł</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Pokazuje ogólny widok portfela</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transakcje</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Przeglądaj historię transakcji</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Zakończ</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Zamknij program</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;O %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Pokaż informacje o %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Pokazuje informacje o Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opcje...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Zmień opcje konfiguracji dla %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Zaszyfruj Portf&amp;el</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Wykonaj kopię zapasową...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Zmień hasło...</translation>
    </message>
    <message>
        <source>Such &amp;sending addresses...</source>
        <translation type="vanished">Adresy wysyłania...</translation>
    </message>
    <message>
        <source>Much &amp;receiving addresses...</source>
        <translation type="vanished">Adresy odbioru...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Otwórz URI...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Ponowne indeksowanie bloków na dysku...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin Turmalina address</source>
        <translation>Wyślij monety na adres Dogecoinowy</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Zapasowy portfel w innej lokalizacji</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Zmień hasło użyte do szyfrowania portfela</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Okno debugowania</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Otwórz konsolę debugowania i diagnostyki</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Zweryfikuj wiadomość...</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina</source>
        <translation>Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Portfel</translation>
    </message>
    <message>
        <source>&amp;Such Send</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <source>&amp;Much Receive</source>
        <translation>Odbie&amp;rz</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Pokaż / Ukryj</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Pokazuje lub ukrywa główne okno</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Szyfruj klucze prywatne, które są w twoim portfelu</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin Turmalina addresses to prove you own them</source>
        <translation>Podpisz wiadomości swoim adresem Dogecoinowym, aby udowodnić jego posiadanie</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin Turmalina addresses</source>
        <translation>Zweryfikuj wiadomość, aby upewnić się, że została podpisana podanym adresem Dogecoinowym.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Plik</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>P&amp;referencje</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Pomo&amp;c</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Pasek zakładek</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and dogecoin: URIs)</source>
        <translation>Żądaj płatności (generuje kod QR oraz Dogecoinowe URI)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Pokaż listę adresów i etykiet użytych do wysyłania</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Pokaż listę adresów i etykiet użytych do odbierania</translation>
    </message>
    <message>
        <source>Open a dogecoin: URI or payment request</source>
        <translation>Otwórz Dogecoinowe: URI lub żądanie zapłaty</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Opcje linii komend</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Bitcoin Turmalina network</source>
        <translation>
            <numerusform>%n aktywne połączenie do sieci Bitcoin Turmalina</numerusform>
            <numerusform>%n aktywnych połączeń do sieci Bitcoin Turmalina</numerusform>
            <numerusform>%n aktywnych połączeń do sieci Bitcoin Turmalina</numerusform>
        </translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Indeksowanie bloków na dysku...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Przetwarzanie bloków na dysku...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation>
            <numerusform>Przetworzono %n blok historii transakcji.</numerusform>
            <numerusform>Przetworzono %n bloków historii transakcji.</numerusform>
            <numerusform>Przetworzono %n bloków historii transakcji.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 za</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Ostatni otrzymany blok został wygenerowany %1 temu.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transakcje po tym momencie nie będą jeszcze widoczne.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Aktualny</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin Turmalina command-line options</source>
        <translation>Pokaż pomoc %1 aby zobaczyć listę wszystkich opcji lnii poleceń.</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1 klient</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Trwa synchronizacja...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Data: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Kwota: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Typ: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Etykieta: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Adres: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transakcja wysłana</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transakcja przychodząca</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Portfel jest &lt;b&gt;zaszyfrowany&lt;/b&gt; i obecnie &lt;b&gt;odblokowany&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Portfel jest &lt;b&gt;zaszyfrowany&lt;/b&gt; i obecnie &lt;b&gt;zablokowany&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Print paper wallets</source>
        <translation>&amp;Drukuj papierowy portfel</translation>
    </message>
    <message>
        <source>Print paper wallets</source>
        <translation>Drukuj papierowy portfel</translation>
    </message>
    <message>
        <source>&amp;Such sending addresses...</source>
        <translation>&amp;Adresy wysyłania...</translation>
    </message>
    <message>
        <source>&amp;Much receiving addresses...</source>
        <translation>&amp;Adresy odbioru...</translation>
    </message>
    <message>
        <source>&amp;Import Private Key...</source>
        <translation>&amp;Importuj Klucz Prywatny...</translation>
    </message>
    <message>
        <source>Import a Bitcoin Turmalina private key</source>
        <translation>Importuj klucz prywatny Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Kliknij, aby wyłączyć aktywność sieciową.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Aktywność sieciowa wyłączona.</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Kliknij, aby ponownie włączyć aktywność sieciową.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Synchronizowanie nagłówków (%1%)...</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Łączenie do peerów...</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation>Generowanie kluczy HD jest &lt;b&gt;włączone&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>Generowanie kluczy HD jest &lt;b&gt;wyłączone&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Runaway exception</source>
        <translation>Wyjątek wykonania</translation>
    </message>
    <message>
        <source>A fatal error occurred. Bitcoin Turmalina can no longer continue safely and will quit.</source>
        <translation>Wystąpił błąd krytyczny. Bitcoin Turmalina nie może już bezpiecznie kontynuować i zakończy działanie.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Wybór monet</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Ilość:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bajtów:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Kwota:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Opłata:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Pył:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Po opłacie:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Reszta:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>Zaznacz/Odznacz wszystko</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Widok drzewa</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Widok listy</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Otrzymano z opisem</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Otrzymano z adresem</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Potwierdzenia</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potwierdzony</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiuj adres</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiuj etykietę</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Skopiuj ID transakcji</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Zablokuj niewydane</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Odblokuj niewydane</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Skopiuj ilość</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Skopiuj prowizję</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Skopiuj ilość po opłacie</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Skopiuj ilość bajtów</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopiuj pył</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Skopiuj resztę</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 zablokowane)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>tak</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nie</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation>Ta etykieta staje się czerwona jeżeli którykolwiek odbiorca otrzymuje kwotę mniejszą niż obecny próg pyłu.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu(s) per input.</source>
        <translation type="vanished">Waha się +/- %1 koinu na wejście.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(brak etykiety)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>reszta z %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(reszta)</translation>
    </message>
    <message>
        <source>Can vary +/- %1 koinu per input.</source>
        <translation>Waha się +/- %1 koinu za wejście.</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Zmień adres</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etykieta</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Etykieta skojarzona z tym wpisem na liście adresów</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Ten adres jest skojarzony z wpisem na liście adresów. Może być zmodyfikowany jedynie dla adresów wysyłających.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adres</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nowy adres odbiorczy</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nowy adres wysyłania</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Zmień adres odbioru</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Zmień adres wysyłania</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Nie można było odblokować portfela.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Generowanie nowego klucza nie powiodło się.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Bitcoin Turmalina address.</source>
        <translation>Wprowadzony adres &quot;%1&quot; nie jest prawidłowym adresem Bitcoin Turmalina.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Wprowadzony adres &quot;%1&quot; już istnieje w książce adresowej</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Będzie utworzony nowy folder danych.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>nazwa</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Katalog już istnieje. Dodaj %1 jeśli masz zamiar utworzyć tutaj nowy katalog.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Ścieżka już istnieje i nie jest katalogiem.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Nie można było tutaj utworzyć folderu.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>wersja</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Informacje o %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Opcje konsoli</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Użycie:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>opcje konsoli</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>Opcje interfejsu</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Katalog danych używany podczas uruchamiania programu (domyślny: %u)</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Wybierz język, na przykład &quot;de_DE&quot; (domyślnie: język systemowy)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Uruchom zminimalizowany</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Ustaw certyfikaty główne SSL dla żądań płatności (domyślnie: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Wyświetl okno powitalne podczas uruchamiania (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Zresetuj wszystkie ustawienia zmienione w GUI</translation>
    </message>
</context>
<context>
    <name>ImportKeysDialog</name>
    <message>
        <source>Import Private Key</source>
        <translation>Importuj Klucz Prywatny</translation>
    </message>
    <message>
        <source>&amp;Import Private Key</source>
        <translation>&amp;Importuj Klucz Prywatny</translation>
    </message>
    <message>
        <source>Private Key:</source>
        <translation>Klucz Prywatny:</translation>
    </message>
    <message>
        <source>Private key to import into your wallet</source>
        <translation>Klucz prywatny do zaimportowania do twojego portfela</translation>
    </message>
    <message>
        <source>Label for this private key in your wallet</source>
        <translation>Etykieta tego klucza prywatnego w twoim portfelu</translation>
    </message>
    <message>
        <source>Label (optional):</source>
        <translation>Etykieta (opcjonalnie):</translation>
    </message>
    <message>
        <source>Rescan</source>
        <translation>Skanuj ponownie</translation>
    </message>
    <message>
        <source>Reset this form.</source>
        <translation>Zresetuj ten formularz.</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Resetuj</translation>
    </message>
    <message>
        <source>&amp;Import</source>
        <translation>&amp;Importuj</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>Invalid private key; please check and try again!</source>
        <translation>Nieprawidłowy klucz prywatny; sprawdź i spróbuj ponownie!</translation>
    </message>
    <message>
        <source>Invalid address generated from private key; please check and try again!</source>
        <translation>Nieprawidłowy adres wygenerowany z klucza prywatnego; sprawdź i spróbuj ponownie!</translation>
    </message>
    <message>
        <source>Failed to add private key.</source>
        <translation>Nie udało się dodać klucza prywatnego.</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Ponowne skanowanie...</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Witaj</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Witaj w %1.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>Ponieważ jest to pierwsze uruchomienie programu, możesz wybrać gdzie %1 będzie przechowywał swoje dane.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Bitcoin Turmalina block chain. At least %2GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>%1 pobierze i będzie przechowywał kopię łańcucha bloków Bitcoin Turmalina. W wybranym katalogu zostanie zapisanych %2GB danych, a z czasem ta ilość będzie rosła. Portfel będzie przechowywany w tym samym katalogu.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Użyj domyślnego folderu danych</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Użyj wybranego folderu dla danych</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation>Błąd: podany folder danych &quot;%1&quot; nie mógł zostać utworzony.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation>
            <numerusform>%n GB dostępnego wolnego miejsca</numerusform>
            <numerusform>%n GB dostępnego wolnego miejsca</numerusform>
            <numerusform>%n GB dostępnego wolnego miejsca</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation>
            <numerusform>(z %n GB potrzebnego)</numerusform>
            <numerusform>(z %n GB potrzebnych)</numerusform>
            <numerusform>(z %n GB potrzebnych)</numerusform>
        </translation>
    </message>
    <message>
        <source>Choose data directory</source>
        <translation>Wybierz katalog danych</translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>Pozostało bloków</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Nieznane...</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Czas ostatniego bloku</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Postęp</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation>Przyrost postępu na godzinę</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>obliczanie...</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>Przewidywany czas zakończenia synchronizacji</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ukryj</translation>
    </message>
    <message>
        <source>Unknown. Syncing Headers (%1)...</source>
        <translation>Nieznane. Synchronizowanie nagłówków (%1)...</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet&apos;s balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the dogecoin network, as detailed below.</source>
        <translation>Ostatnie transakcje mogą nie być jeszcze widoczne, a zatem saldo portfela może być nieprawidłowe. Te informacje będą poprawne, gdy portfel zakończy synchronizację z siecią dogecoin, zgodnie z poniższym opisem.</translation>
    </message>
    <message>
        <source>Attempting to spend dogecoins that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation>Próba wydania dogecoinów, których dotyczą niewyświetlone jeszcze transakcje, nie zostanie zaakceptowana przez sieć.</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Otwórz URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Otwórz żądanie zapłaty z URI lub pliku</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Otwórz żądanie zapłaty z pliku</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Wybierz plik żądania zapłaty do otwarcia</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>Główne</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Automatycznie uruchom %1 po zalogowaniu do systemu.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>Uruchamiaj %1 wraz z zalogowaniem do &amp;systemu</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Wielkość bufora bazy &amp;danych</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Liczba wątków &amp;weryfikacji skryptu</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Akceptuj połączenia z zewnątrz</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Zezwól na połączenia przychodzące</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>Adres IP serwera proxy (np. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Minimalizuje zamiast zakończyć działanie programu przy zamykaniu okna. Kiedy ta opcja jest włączona, program zakończy działanie po wybieraniu Zamknij w menu.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Zewnętrzne URL podglądu transakcji (np. eksplorator bloków), które będą wyświetlały się w menu kontekstowym, w zakładce transakcji. %s będzie zamieniany w adresie na hash transakcji. Oddziel wiele adresów pionową kreską |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Zewnętrzny URL podglądu transakcji</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktywne opcje linii komend, które nadpisują powyższe opcje:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Przywróć wszystkie domyślne ustawienia klienta.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>Z&amp;resetuj ustawienia</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Sieć</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = automatycznie, &lt;0 = zostaw tyle wolnych rdzeni)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Portfel</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Ekspert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Włącz funk&amp;cje kontoli monet</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Jeżeli wyłączysz możliwość wydania niezatwierdzonej wydanej reszty, reszta z transakcji nie będzie mogła zostać wykorzystana, dopóki ta transakcja nie będzie miała przynajmniej jednego potwierdzenia. To także ma wpływ na obliczanie Twojego salda.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>Wydaj niepotwierdzoną re&amp;sztę</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin Turmalina client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatycznie otwiera port klienta Bitcoin Turmalina na routerze. Ta opcja dzieła tylko jeśli twój router wspiera UPnP i jest ono włączone.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapuj port używając &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a SOCKS5 proxy.</source>
        <translation>Połącz się z siecią Bitcoin Turmalina poprzez proxy SOCKS5.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>Połącz przez proxy SO&amp;CKS5 (domyślne proxy):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP proxy:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port proxy (np. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Użyto do połączenia z peerami przy pomocy:</translation>
    </message>
    <message>
        <source>Shows, if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Pokazuje, czy wspierane domyślnie proxy SOCKS5 jest używane do łączenia się z peerami w tej sieci</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Bitcoin Turmalina network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Połącz się z siecią Bitcoin Turmalina przy pomocy oddzielnego SOCKS5 proxy dla sieci TOR</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services:</source>
        <translation>Użyj oddzielnego proxy SOCKS5 aby osiągnąć węzły w ukrytych usługach Tor:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Okno</translation>
    </message>
    <message>
        <source>&amp;Hide the icon from the system tray.</source>
        <translation>Ukryj ikonę z zasobnika systemowego.</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>Ukryj ikonę zasobnika</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Pokazuj tylko ikonę przy zegarku po zminimalizowaniu okna.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimalizuj do zasobnika systemowego zamiast do paska zadań</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimalizuj przy zamknięciu</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Wyświetlanie</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Język &amp;użytkownika:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>Można tu ustawić język interfejsu uzytkownika. Ustawienie przyniesie skutek po ponownym uruchomieniu %1.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Jednostka pokazywana przy kwocie:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Wybierz podział jednostki pokazywany w interfejsie oraz podczas wysyłania monet.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Wybierz pokazywanie lub nie funkcji kontroli monet.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>default</source>
        <translation>domyślny</translation>
    </message>
    <message>
        <source>none</source>
        <translation>żaden</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Potwierdź reset ustawień</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Wymagany restart programu, aby uaktywnić zmiany.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Program zostanie wyłączony. Czy chcesz kontynuować?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Ta zmiana może wymagać ponownego uruchomienia klienta.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Adres podanego proxy jest nieprawidłowy</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation>Wyłącza niektóre zaawansowane funkcje ale wszystkie bloki będą nadal w pełni sprawdzane. Przywrócenie tego ustawienia wymaga ponownego pobrania całego łańcucha bloków. Rzeczywiste wykorzystanie dysku może być nieco wyższe.</translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation>Ogranicz przechowywanie łańcucha bloków do</translation>
    </message>
    <message>
        <source>GB</source>
        <translation>GB</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation>Przywrócenie tego ustawienia wymaga ponownego pobrania całego łańcucha bloków.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin Turmalina network after a connection is established, but this process has not completed yet.</source>
        <translation>Wyświetlana informacja może być nieaktualna. Twój portfel synchronizuje się automatycznie z siecią Bitcoin Turmalina, zaraz po tym jak uzyskano połączenie, ale proces ten nie został jeszcze ukończony.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Tylko podglądaj:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Dostępne:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Twoje obecne saldo</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>W toku:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Suma transakcji, które nie zostały jeszcze potwierdzone, a które nie zostały wliczone do twojego obecnego salda</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Niedojrzały:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Balans wydobytych monet, które jeszcze nie dojrzały</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Salda</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Ogółem:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Twoje obecne saldo</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Twoje obecne saldo na podglądanym adresie</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Możliwe do wydania:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Ostatnie transakcje</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Niepotwierdzone transakcje na podglądanych adresach</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Wykopane monety na podglądanych adresach które jeszcze nie dojrzały</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Łączna kwota na podglądanych adresach</translation>
    </message>
    <message>
        <source>Helpful tip of the day:</source>
        <translation>Pomocna wskazówka dnia:</translation>
    </message>
    <message>
        <source>Tip</source>
        <translation>Wskazówka</translation>
    </message>
    <message>
        <source>Never share your wallet.dat file with anyone</source>
        <translation>Nigdy nie udostępniaj nikomu swojego pliku wallet.dat</translation>
    </message>
    <message>
        <source>For advanced operations, use the console in &apos;Help&apos; -&gt; &apos;Debug Window&apos;</source>
        <translation>Aby wykonać zaawansowane operacje, użyj konsoli w &apos;Pomoc&apos; -&gt; &apos;Okno debugowania&apos;</translation>
    </message>
    <message>
        <source>Encrypt your wallet with a strong passphrase for maximum security</source>
        <translation>Zaszyfruj swój portfel silnym hasłem, aby zapewnić maksymalne bezpieczeństwo</translation>
    </message>
    <message>
        <source>Make sure to keep your wallet software updated</source>
        <translation>Pamiętaj o aktualizowaniu oprogramowania portfela</translation>
    </message>
    <message>
        <source>Backup your private key to recover your coins, using &apos;File&apos; &gt; &apos;Backup Wallet&apos;</source>
        <translation>Utwórz kopię zapasową klucza prywatnego aby móc odzyskać monety, używając &apos;Plik&apos; &gt; &apos;Wykonaj kopię zapasową&apos;</translation>
    </message>
    <message>
        <source>Always do your own research before using an external cryptocurrency service</source>
        <translation>Zawsze przeprowadź własne badania przed skorzystaniem z zewnętrznej usługi kryptowalutowej</translation>
    </message>
    <message>
        <source>Never share your private key with anyone</source>
        <translation>Nigdy nie udostępniaj nikomu swojego klucza prywatnego</translation>
    </message>
    <message>
        <source>Who owns the private keys, owns the coins</source>
        <translation>Kto jest właścicielem kluczy prywatnych, jest właścicielem monet</translation>
    </message>
    <message>
        <source>To see ongoing development and contribute, check out the Bitcoin Turmalina Core repository on GitHub</source>
        <translation>Aby zobaczyć ciągły rozwój i wnieść swój wkład, sprawdź repozytorium Bitcoin Turmalina Core na GitHub</translation>
    </message>
    <message>
        <source>Services that claim to double your dogecoins are always ponzi schemes</source>
        <translation>Usługi, które obiecują podwoić Twoje monety Bitcoin Turmalina, są zawsze schematami ponzi</translation>
    </message>
</context>
<context>
    <name>PaperWalletDialog</name>
    <message>
        <source>Print Your Paper Wallets</source>
        <translation>Wydrukuj Swoje Papierowe Portfele</translation>
    </message>
    <message>
        <source>Very New Address</source>
        <translation>Nowy adres</translation>
    </message>
    <message>
        <source>So Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <source>Many Wallets?</source>
        <translation>Ile portfeli?</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Key:</source>
        <translation>Klucz publiczny:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Warning: Network Activity Detected</source>
        <translation>Ostrzeżenie: wykryto aktywność sieciową</translation>
    </message>
    <message>
        <source>It is recommended to disconnect from the internet before printing paper wallets. Even though paper wallets are generated on your local computer, it is still possible to unknowingly have malware that transmits your screen to a remote location. It is also recommended to print to a local printer vs a network printer since that network traffic can be monitored. Some advanced printers also store copies of each printed document. Proceed with caution relative to the amount of value you plan to store on each address.</source>
        <translation>Przed drukowaniem portfeli papierowych zaleca się odłączenie od Internetu. Mimo że portfele papierowe są generowane na komputerze lokalnym, nadal istnieje możliwość nieświadomego posiadania złośliwego oprogramowania, które przesyła ekran do zdalnej lokalizacji. Zaleca się również drukowanie na drukarce lokalnej, a nie na drukarce sieciowej, ponieważ można monitorować ruch sieciowy. Niektóre zaawansowane drukarki przechowują również kopie każdego drukowanego dokumentu. Postępuj ostrożnie, biorąc pod uwagę wartość, jaką planujesz przechowywać pod każdym adresem.</translation>
    </message>
    <message>
        <source>Error encoding Address into QR Code.</source>
        <translation>Błąd kodowania adresu do kodu QR.</translation>
    </message>
    <message>
        <source>Error encoding private key into QR Code.</source>
        <translation>Błąd kodowania klucza prywatnego do kodu QR.</translation>
    </message>
    <message>
        <source>Printing Error</source>
        <translation>Błąd drukowania</translation>
    </message>
    <message>
        <source>failed to open file, is it writable?</source>
        <translation>nie udało się otworzyć pliku, czy jest zapisywalny?</translation>
    </message>
    <message>
        <source>Load Paper Wallets</source>
        <translation>Ładowanie Portfeli Papierowych</translation>
    </message>
    <message>
        <source>The paper wallet printing process has begun.&lt;br/&gt;Please wait for the wallets to print completely and verify that everything printed correctly.&lt;br/&gt;Check for misalignments, ink bleeding, smears, or anything else that could make the private keys unreadable.&lt;br/&gt;Now, enter the number of BTURM you wish to send to each wallet:</source>
        <translation>Rozpoczął się proces drukowania portfela papierowego.&lt;br/&gt;Poczekaj, aż portfele zostaną całkowicie wydrukowane i sprawdź, czy wszystko zostało wydrukowane poprawnie.&lt;br/&gt;Sprawdź, czy nie ma przesunięć, wycieków atramentu, rozmazów lub czegokolwiek innego, co mogłoby spowodować, że klucze prywatne będą nieczytelne.&lt;br/&gt;Teraz wprowadź liczbę BTURM, które chcesz wysłać do każdego portfela:</translation>
    </message>
    <message>
        <source>Paper wallet %1</source>
        <translation>Portfel papierowy %1</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to Paper Wallet &lt;span style=&apos;font-family: monospace;&apos;&gt;%2&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Coins</source>
        <translation>Wyślij monety</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Adres odbiorcy jest nieprawidłowy, sprawdź ponownie.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0</source>
        <translation>Kwota musi być większa niż 0</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Kwota przekracza dostepne saldo.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the transaction fee is included</source>
        <translation>Suma przewyższa dostepne saldo po uwzględnieniu opłaty transakcyjnej</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Znaleziono zduplikowany adres, można wysłać na każdy adres tylko raz na operację wysyłania.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Tworzenie transakcji nie powiodło się!</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Czy jesteś pewny że chcesz wysłać?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>dodano jako opłata transakcyjna</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Całkowita kwota %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>lub</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Potwierdź wysłanie monet</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Transakcja została odrzucona! Może się tak zdarzyć jeśli niektóre monety w portfelu zostały już wydane, na przykład jeśli użyto kopii wallet.dat, a monety zostały wydane w kopii ale nie zostały oznaczone jako wydane tutaj.</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>Błąd żądania płatności</translation>
    </message>
    <message>
        <source>Cannot start dogecoin: click-to-pay handler</source>
        <translation>Nie można uruchomić protokołu Bitcoin Turmalina: kliknij-by-zapłacić</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>Obsługa URI</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Żądanie płatności upłynęło.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>Żądanie płatności nie jest zainicjowane.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Niezweryfikowane żądania płatności do własnych skryptów płatności są niewspierane.</translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation>Nieprawidłowe żądanie płatności</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Zwrot z %1</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>Żądanie płatności nie może zostać przetworzone.</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Błędna odpowiedź z serwera %1</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Błąd żądania sieci</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Płatność potwierdzona</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Adres URL żądania płatności jest nieprawidłowy: %1</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Adres płatności jest nieprwidłowy %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Bitcoin Turmalina address or malformed URI parameters.</source>
        <translation>Nie można przeanalizować identyfikatora URI! Może to być spowodowane nieważnym adresem Bitcoin Turmalina lub nieprawidłowymi parametrami URI.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Obsługa pliku żądania płatności</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Nie można odczytać pliku żądania płatności! Może to być spowodowane nieprawidłowym plikiem żądania płatności.</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Żądanie płatności odrzucone</translation>
    </message>
    <message>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation>Sieć żądania płatności nie jest zgodna z siecią klienta.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (below discard threshold).</source>
        <translation>Żądana kwota płatności %1 jest zbyt niska (poniżej progu odrzucenia).</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>Żądanie płatności %1 jest zbyt duże (%2 bajty, dozwolone %3 bajty).</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Błąd komunikacji z %1: %2</translation>
    </message>
    <message>
        <source>BIP70 payment requests are deprecated and disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation>Żądania płatności BIP70 są przestarzałe i domyślnie wyłączone. Uruchom ponownie z -enable-bip70, jeśli absolutnie musisz korzystać z tej funkcji. &lt;br/&gt;Używaj tej funkcji z najwyższą ostrożnością.</translation>
    </message>
    <message>
        <source>Payment request file handling is disabled by default. Restart with -enable-bip70 if you absolutely have to use this functionality.

Use this functionality with extreme caution.</source>
        <translation>Obsługa plików żądań płatności jest domyślnie wyłączona. Uruchom ponownie z -enable-bip70, jeśli absolutnie musisz korzystać z tej funkcji. &lt;br/&gt;Używaj tej funkcji z najwyższą ostrożnością.</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Aplikacja kliencka</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Węzeł/Usługi</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation>Identyfikator węzła</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Ping</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>Wysłane bajty</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>Odebrane bajty</translation>
    </message>
</context>
<context>
    <name>PeerTools</name>
    <message>
        <source>Error: Node address is invalid</source>
        <translation>Błąd: Adres węzła jest nieprawidłowy</translation>
    </message>
    <message>
        <source>Error: Peer-to-peer functionality missing or disabled</source>
        <translation>Błąd: Funkcjonalność peer-to-peer niedostępna lub wyłączona</translation>
    </message>
    <message>
        <source>Attempted to one try node.</source>
        <translation>Próba jednorazowego podłaczenia do węzła</translation>
    </message>
    <message>
        <source>Error: Unable to add node</source>
        <translation>Błąd: Nie można dodać węzła</translation>
    </message>
    <message>
        <source>Node not found in connected nodes</source>
        <translation>Nie znaleziono węzła w podłączonych węzłach</translation>
    </message>
    <message>
        <source>Disconnected the node: </source>
        <translation>Rozłączono węzeł: </translation>
    </message>
    <message>
        <source>Returned OK.</source>
        <translation>Zwrócono OK.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>Enter a Bitcoin Turmalina address (e.g. %1)</source>
        <translation>Wprowadź adres Dogecoinowy (np. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Żaden</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>NIEDOSTĘPNE</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n sekunda</numerusform>
            <numerusform>%n sekund</numerusform>
            <numerusform>%n sekund</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n minuta</numerusform>
            <numerusform>%n minut</numerusform>
            <numerusform>%n minut</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 i %2</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 kB</source>
        <translation>%1 kB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation>
            <numerusform>%n godzina</numerusform>
            <numerusform>%n godzin</numerusform>
            <numerusform>%n godzin</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation>
            <numerusform>%n dzień</numerusform>
            <numerusform>%n dni</numerusform>
            <numerusform>%n dni</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation>
            <numerusform>%n tydzień</numerusform>
            <numerusform>%n tygodnie</numerusform>
            <numerusform>%n tygodnie</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation>
            <numerusform>%n rok</numerusform>
            <numerusform>%n lata</numerusform>
            <numerusform>%n lata</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 didn&apos;t yet exit safely...</source>
        <translation>%1 nie zakończył się jeszcze bezpiecznie...</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: %1</source>
        <translation>Błąd: %1</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>Błąd: Wskazany folder danych &quot;%1&quot; nie istnieje.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>Błąd: Nie można przeanalizować pliku konfiguracyjnego: %1. Używaj tylko składni klucz=wartość.</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Zapisz obraz...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Kopiuj obraz</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Zapisz Kod QR</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>Obraz PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>NIEDOSTĘPNE</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Wersja klienta</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Informacje</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Okno debugowania</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Używana wersja BerkeleyDB</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Katalog danych</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Czas uruchomienia</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Sieć</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Liczba połączeń</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Łańcuch bloków</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktualna liczba bloków</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Memory Pool (obszar pamięci)</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Obecna liczba transakcji</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Zużycie pamięci</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Otrzymane</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Wysłane</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Węzły</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Blokowane węzły</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Wybierz węzeł żeby zobaczyć szczegóły.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Biała lista</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Kierunek</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Blok startowy</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Zsynchronizowane nagłówki</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Zsynchronizowane bloki</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Aplikacja kliencka</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Otwórz plik dziennika debugowania %1 z obecnego katalogu z danymi. Może to potrwać kilka sekund przy większych plikach.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Zmniejsz rozmiar czcionki</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Zwiększ rozmiar czcionki</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Usługi</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Punkty karne</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Czas połączenia</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Ostatnio wysłano</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Ostatnio odebrano</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Czas odpowiedzi</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>Czas trwania nadmiarowego pingu</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Czas odpowiedzi</translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation>Minimalny czas odpowiedzi</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Przesunięcie czasu</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Czas ostatniego bloku</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsola</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>$Ruch sieci</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Wyczyść</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Kwota ogólna</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Wejście:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Wyjście:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Plik logowania debugowania</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Wyczyść konsolę</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;godzina</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;dzień</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;tydzień</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;rok</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>&amp;Rozłącz</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>Zbanuj na</translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>&amp;Odblokuj</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Witaj w konsoli %1 RPC.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Użyj strzałek do przewijania historii i &lt;b&gt;Ctrl-L&lt;/b&gt; aby wyczyścić ekran.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Wpisz &lt;b&gt;help&lt;/b&gt; aby uzyskać listę dostępnych komend.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(id węzła: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>przez %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>nigdy</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Wejściowy</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Wyjściowy</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>Connected peers</source>
        <translation>Podłączone peery</translation>
    </message>
    <message>
        <source>Add new peer</source>
        <translation>Dodaj nowego peera</translation>
    </message>
    <message>
        <source>Remove peer</source>
        <translation>Usuń peera</translation>
    </message>
    <message>
        <source>One try peer</source>
        <translation>Jednorazowe podłączenie peera</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramification of a command.</source>
        <translation>OSTRZEŻENIE: Oszuści byli aktywni, mówiąc użytkownikom, aby wpisywali tutaj polecenia, kradnąc zawartość ich portfela. Nie używaj tej konsoli bez pełnego zrozumienia konsekwencji danego polecenia.</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation>Aktywność sieciowa została wyłączona</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>Remove Peer</source>
        <translation>Usuń peera</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the peer: </source>
        <translation>Czy na pewno chcesz usunąć peera: </translation>
    </message>
    <message>
        <source>No peer was selected.</source>
        <translation>Nie wybrano żadnego peera.</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Ilość:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etykieta:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Wiadomość:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Użyj jednego z poprzednio użytych adresów odbiorczych. Podczas ponownego używania adresów występują problemy z bezpieczeństwem i prywatnością. Nie korzystaj z tej opcji, chyba że odtwarzasz żądanie płatności wykonane już wcześniej.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>U&amp;żyj ponownie istniejącego adresu odbiorczego (niepolecane)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin Turmalina network.</source>
        <translation>Opcjonalna wiadomość do dołączenia do żądania płatności, która będzie wyświetlana, gdy żądanie zostanie otwarte. Uwaga: wiadomość ta nie zostanie wysłana wraz z płatnością w sieci Bitcoin Turmalina.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Opcjonalna etykieta do skojarzenia z nowym adresem odbiorczym.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Użyj tego formularza do zażądania płatności. Wszystkie pola są &lt;b&gt;opcjonalne&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Opcjonalna kwota żądania. Zostaw puste lub zero by nie zażądać konkretnej kwoty.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Wyczyść wszystkie pola formularza.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Wyczyść</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Żądanie historii płatności</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Żądaj płatności</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Pokaż wybrane żądanie (robi to samo co dwukrotne kliknięcie pozycji)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Pokaż</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Usuń zaznaczone z listy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Kopiuj URI:</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiuj etykietę</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Kopiuj wiadomość</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Kod QR</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopiuj &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopiuj &amp;adres</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Zapisz obraz...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Zażądaj płatności do %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Informacje o płatności</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Wiadomość</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Wynikowy identyfikator URI jest zbyt długi, spróbuj zmniejszyć tekst etykiety / komunikatu.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Błąd kodowania URI do kodu QR.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Wiadomość</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(brak etykiety)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(brak wiadomości)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>Zażądano</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(brak kwoty)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Wyślij monety</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Funkcje kontroli monet</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Wejścia...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>zaznaczone automatycznie</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Niewystarczające środki!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Ilość:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Bajtów:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Kwota:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Opłata:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Po opłacie:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Reszta:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Kiedy ta opcja jest wybrana, to jeżeli adres reszty jest pusty lub nieprawidłowy, to reszta będzie wysyłana na nowo wygenerowany adres.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Niestandardowe zmiany adresu</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Opłata transakcyjna:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Wybierz...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>zwiń opcje opłaty</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>za kilobajt</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 koinu and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 koinu in fee, while &quot;total at least&quot; pays 1000 koinu. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Jeżeli własna opłata zostanie ustawiona na 1000 koinu, a transakcja będzie miała tylko 250 bajtów, to &quot;za kilobajt&quot; płaci tylko 250 koinu, podczas gdy, &quot;razem przynajmniej&quot; płaci 1000 koinu. Przy transakcjach większych niż kilobajt, w obu przypadkach płaci za każdy kilobajt.</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ukryj</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>razem przynajmniej</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks. But be aware that this can end up in a never confirming transaction once there is more demand for dogecoin transactions than the network can process.</source>
        <translation>Zapłacenie tylko minimalnej opłaty jest nadal wystarczające, dopóki jest mniejszy wolumen transakcji niż miejsca w blokach. Należy jednak mieć świadomość, że może skończyć się to niezatwierdzeniem nigdy transakcji, gdy jest większe zapotrzebowanie na transakcje Dogecoina niż sieć może przetworzyć.</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(przeczytaj podpowiedź)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Zalecane:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Własna:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation type="vanished">(Sprytne opłaty nie są jeszcze zainicjowane. Trwa to zwykle kilka bloków...)</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="vanished">normalnie</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="vanished">szybko</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Wyślij do wielu odbiorców na raz</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Dodaj Odbio&amp;rcę</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Wyczyść wszystkie pola formularza.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Pył:</translation>
    </message>
    <message>
        <source>Confirmation time target:</source>
        <translation type="vanished">Docelowy czas potwierdzenia:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Wyczyść &amp;wszystko</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Potwierdź akcję wysyłania</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>Wy&amp;syłka</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Skopiuj ilość</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Skopiuj prowizję</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Skopiuj ilość po opłacie</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Skopiuj ilość bajtów</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopiuj pył</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Skopiuj resztę</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 do %2</translation>
    </message>
    <message>
        <source>or</source>
        <translation>lub</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Kwota do zapłacenia musi być większa od 0.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Utworzenie transakcji nie powiodło się!</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Żądanie płatności upłynęło.</translation>
    </message>
    <message>
        <source>Pay only the required fee of %1</source>
        <translation>Zapłać tylko wymaganą opłatę w wysokości %1</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin Turmalina address</source>
        <translation>Ostrzeżenie: nieprawidłowy adres Bitcoin Turmalina</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Ostrzeżenie: Nieznany adres reszty</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(brak etykiety)</translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation>Korzystanie z opłaty domyślnej może skutkować wysłaniem transakcji, która potwierdzi się w kilka godzin lub dni (lub nigdy). Rozważ wybranie opłaty ręcznie lub poczekaj, aż sprawdzisz poprawność całego łańcucha.</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation>Uwaga: Oszacowanie opłaty za transakcje jest aktualnie niemożliwe.</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 satoshis and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 satoshis in fee, while &quot;total at least&quot; pays 1000 satoshis. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorytet:</translation>
    </message>
    <message>
        <source>low</source>
        <translation>niski</translation>
    </message>
    <message>
        <source>high</source>
        <translation>wysoki</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Czy na pewno chcesz wysłać?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>dodano jako opłata transakcyjna</translation>
    </message>
    <message>
        <source>Total Amount %1</source>
        <translation>Całkowita kwota %1</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Potwierdź wysyłanie monet</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation>Adres odbiorcy jest nieprawidłowy, sprawdź ponownie.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Kwota przekracza dostepne saldo.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Suma przekracza twoje saldo, gdy doliczymy %1 prowizji transakcyjnej.</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation>Duplikat adresu znaleziony: adresy powinny zostać użyte tylko raz.</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>Transakcja została odrzucona z następującym powodem: %1</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>Opłata wyższa niż %1 jest uznawana za absurdalnie dużą.</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation>Potwierdź zmianę adresu własnego</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>Wybrany adres reszty nie jest częścią tego portfela. Dowolne lub wszystkie środki w twoim portfelu mogą być wysyłane na ten adres. Jesteś pewny?</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Su&amp;ma:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Zapłać &amp;dla:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etykieta:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Wybierz wcześniej użyty adres</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>To jest standardowa płatność</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to send the payment to</source>
        <translation>Adres Bitcoin Turmalina, na który wysłać płatność</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Wklej adres ze schowka</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Usuń ten wpis</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less dogecoins than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>Opłata zostanie odjęta od kwoty wysyłanej. Odbiorca otrzyma mniej niż Dogecoinów wpisanych w polu kwoty. Jeśli wybrano kilku odbiorców, opłata jest podzielona równo.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>Odejmij od wysokości opłaty</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Wiadomość:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>To żądanie zapłaty nie zostało zweryfikowane.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>To żądanie zapłaty jest zweryfikowane.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Wprowadź etykietę dla tego adresu by dodać go do listy użytych adresów</translation>
    </message>
    <message>
        <source>A message that was attached to the dogecoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin Turmalina network.</source>
        <translation>Wiadomość, która została dołączona do URI Dogecoina, która będzie przechowywana wraz z transakcją w celach informacyjnych. Uwaga: Ta wiadomość nie będzie rozsyłana w sieci Bitcoin Turmalina.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Wpłać do:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Notatka:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Wprowadź etykietę dla tego adresu, aby dodać go do książki adresowej</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 się zamyka...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Nie wyłączaj komputera dopóki to okno nie zniknie.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Podpisy - Podpisz / zweryfikuj wiadomość</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Podpi&amp;sz Wiadomość</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive dogecoins sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Możesz podpisywać wiadomości swoimi adresami aby udowodnić, że jesteś ich właścicielem. Uważaj, aby nie podpisywać niczego co wzbudza Twoje podejrzenia, ponieważ ktoś może stosować phishing próbując nakłonić Cię do ich podpisania. Akceptuj i podpisuj tylko w pełni zrozumiałe komunikaty i wiadomości.</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address to sign the message with</source>
        <translation>Adres Bitcoin Turmalina, za pomocą którego podpisać wiadomość</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Wybierz wcześniej użyty adres</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Wklej adres ze schowka</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Tutaj wprowadź wiadomość, którą chcesz podpisać</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Podpis</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopiuje aktualny podpis do schowka systemowego</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin Turmalina address</source>
        <translation>Podpisz wiadomość aby dowieść, że ten adres jest twój</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Podpisz Wiado&amp;mość</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Zresetuj wszystkie pola podpisanej wiadomości</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Wyczyść &amp;wszystko</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Zweryfikuj wiadomość</translation>
    </message>
    <message>
        <source>Enter the receiver&apos;s address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Wpisz adres, wiadomość oraz sygnaturę (podpis) odbiorcy (upewnij się, że dokładnie skopiujesz wszystkie zakończenia linii, spacje, tabulacje itp.). Uważaj by nie dodać więcej do podpisu niż do samej podpisywanej wiadomości by uniknąć ataku man-in-the-middle. 
Zwróć uwagę, że poprawnie zweryfikowana wiadomość potwierdza to, że nadawca posiada klucz do adresu, natomiast nie potwierdza to, że poprawne wysłanie jakiejkolwiek transakcji!</translation>
    </message>
    <message>
        <source>The Bitcoin Turmalina address the message was signed with</source>
        <translation>Adres Bitcoin Turmalina, którym została podpisana wiadomość</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin Turmalina address</source>
        <translation>Zweryfikuj wiadomość, aby upewnić się, że została podpisana odpowiednim adresem Bitcoin Turmalina.</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Zweryfikuj Wiado&amp;mość</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Resetuje wszystkie pola weryfikacji wiadomości</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Odblokowanie portfela zostało anulowane.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Klucz prywatny dla podanego adresu nie jest dostępny.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Podpisanie wiadomości nie powiodło się.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Wiadomość podpisana.</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Kliknij &quot;Podpisz Wiadomość&quot; żeby uzyskać podpis</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Podany adres jest nieprawidłowy.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Proszę sprawdzić adres i spróbować ponownie.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Wprowadzony adres nie odnosi się do klucza.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Podpis nie może zostać zdekodowany.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Sprawdź podpis i spróbuj ponownie.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Podpis nie odpowiada skrótowi wiadomości.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Weryfikacja wiadomości nie powiodła się.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Wiadomość zweryfikowana.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TestPeerDialog</name>
    <message>
        <source>Test Peer</source>
        <translation>Test Peera</translation>
    </message>
    <message>
        <source>Enter the peer details below.</source>
        <translation>Wprowadź dane peera poniżej.</translation>
    </message>
    <message>
        <source>Be careful! Do not blindly trust anyone that tells you to add their node.</source>
        <translation>Bądź ostrożny! Nie ufaj ślepo nikomu, kto każe Ci dodać jego węzeł.</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s address</source>
        <translation>Wprowadź adres peera</translation>
    </message>
    <message>
        <source>Enter the peer&apos;s port</source>
        <translation>Wprowadź port peera</translation>
    </message>
    <message>
        <source>Test!</source>
        <translation>Przetestuj!</translation>
    </message>
    <message>
        <source>Please enter an address.</source>
        <translation>Proszę wprowadzić adres.</translation>
    </message>
    <message>
        <source>Please enter a valid peer address.</source>
        <translation>Proszę wprowadzić prawidłowy adres peera.</translation>
    </message>
    <message>
        <source>Try Peer</source>
        <translation>Wypróbuj Peera</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Źródło</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Wygenerowano</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Od</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>nieznane</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Do</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>własny adres</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>tylko-obserwowany</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etykieta</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Wiadomość</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation>sprzeczny z transakcją posiadającą %1 potwierdzeń</translation>
    </message>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation>0/niepotwierdzone, %1</translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation>w kolejce w pamięci</translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation>nie wysłane do kolejki w pamięci</translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation>porzucone</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/niezatwierdzone</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 potwierdzeń</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Uznanie</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>dojrzeje po %n kolejnym bloku</numerusform>
            <numerusform>dojrzeje po %n kolejnych blokach</numerusform>
            <numerusform>dojrzeje po %n kolejnych blokach</numerusform>
        </translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>niezaakceptowane</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debet</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Łączne obciążenie</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Łączne uznanie</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Opłata transakcyjna</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Kwota netto</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ID transakcji</translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation>Rozmiar transakcji</translation>
    </message>
    <message>
        <source>Output index</source>
        <translation>Indeks wyjściowy</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Kupiec</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Wygenerowane monety muszą dojrzeć przez %1 bloków zanim będzie można je wydać. Gdy wygenerowałeś blok, został on rozgłoszony w sieci w celu dodania do łańcucha bloków. Jeżeli nie uda mu się wejść do łańcucha jego status zostanie zmieniony na &quot;nie zaakceptowano&quot; i nie będzie można go wydać. Może się to czasami zdarzyć, jeśli inny węzeł wygeneruje blok w odstępie kilku sekund od twojego.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Informacje debugowania</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transakcja</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Wejścia</translation>
    </message>
    <message>
        <source>true</source>
        <translation>prawda</translation>
    </message>
    <message>
        <source>false</source>
        <translation>fałsz</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ten panel pokazuje szczegółowy opis transakcji</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation>Szczegóły %1</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation type="vanished">Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Niepotwierdzone</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation>Porzucone</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>Skonfliktowane</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Wygenerowane ale nie zaakceptowane</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Wysłane do</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>tylko-obserwowany</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(brak etykiety)</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Potwierdzanie (%1 z %2 rekomendowanych potwierdzeń)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Potwierdzono (%1 potwierdzeń)</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Niedojrzała (%1 potwierdzeń, będzie dostępna po %2)</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Otrzymane przez</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Otrzymano od</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Płatność do siebie</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Wydobyto</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(brak)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status transakcji. Najedź na pole, aby zobaczyć liczbę potwierdzeń.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Data i czas odebrania transakcji.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Rodzaj transakcji.</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Czy adres tylko-obserwowany jest lub nie użyty w tej transakcji.</translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation>Zdefiniowana przez użytkownika intencja/cel transakcji.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Kwota odjęta z lub dodana do konta.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Dzisiaj</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>W tym tygodniu</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>W tym miesiącu</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>W zeszłym miesiącu</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>W tym roku</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Zakres...</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Wysłane do</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiuj adres</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiuj etykietę</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Skopiuj ID transakcji</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Plik *.CSV (dane rozdzielane przecinkami)</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksportowanie nie powiodło się</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Otrzymane przez</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Do siebie</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Wydobyto</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Inne</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Wprowadź adres lub etykietę żeby wyszukać</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimalna kwota</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>Porzuć transakcję</translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation>Skopiuj surową transakcję</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>Skopiuj pełne detale transakcji</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Edytuj etykietę</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Wyświetl szczegóły transakcji</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Eksport historii transakcji</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potwierdzony</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Tylko-obserwowany</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Wystąpił błąd przy próbie zapisu historii transakcji do %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Eksport powiódł się</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Historia transakcji została zapisana do %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Zakres:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>do</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Jednostka w jakiej pokazywane są kwoty. Kliknij aby wybrać inną.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Nie załadowano żadnego portfela.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Wyślij monety</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Eksportuj</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportuj dane z aktywnej karty do pliku</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Kopia zapasowa portfela</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Dane portfela (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Nie udało się wykonać kopii zapasowej</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Wystąpił błąd przy próbie zapisu pliku portfela do %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Wykonano kopię zapasową</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Dane portfela zostały poprawnie zapisane w %1.</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Opcje:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Wskaż folder danych</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Podłącz się do węzła aby otrzymać adresy peerów i rozłącz</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Podaj swój publiczny adres</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Akceptuj linię poleceń oraz polecenia JSON-RPC</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied or if &lt;category&gt; = 1, output all debugging information.</source>
        <translation>Jeżeli &lt;category&gt; nie zostanie określona lub &lt;category&gt; = 1, wyświetl wszystkie informacje debugowania.</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>Przycinanie skonfigurowano poniżej minimalnych %d MiB. Proszę użyć wyższej liczby.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Przycinanie: ostatnia synchronizacja portfela wykracza poza przycięte dane. Musisz użyć -reindex (pobrać cały ciąg bloków ponownie w przypadku przyciętego węzła)</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Ponowne skanowanie nie jest możliwe w trybie przycinania. Będzie trzeba użyć -reindex, co pobierze ponownie cały łańcuch bloków.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Błąd: Wystąpił fatalny błąd wewnętrzny, sprawdź szczegóły w debug.log</translation>
    </message>
    <message>
        <source>Fee (in %s/kB) to add to transactions you send (default: %s)</source>
        <translation>Prowizja (w %s/kB) dodawana do wysyłanych transakcji (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Przycinanie zapisu bloków...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Uruchom w tle jako daemon i przyjmuj polecenia</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Uruchomienie serwera HTTP nie powiodło się. Zobacz dziennik debugowania, aby uzyskać więcej szczegółów.</translation>
    </message>
    <message>
        <source>Bitcoin Turmalina Core</source>
        <translation>Rdzeń Dogecoina</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>Deweloperzy %s</translation>
    </message>
    <message>
        <source>A fee rate (in %s/kB) that will be used when fee estimation has insufficient data (default: %s)</source>
        <translation>Stawka prowizji (w %s/kB), która będzie użyta, gdy oszacowane dane o prowizjach nie będą wystarczające (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Accept relayed transactions received from whitelisted peers even when not relaying transactions (default: %d)</source>
        <translation>Akceptuj przekazywane transakcje otrzymane od użytkowników z białej listy nawet gdy przekazywanie transakcji nie jest włączone (domyślnie: %d)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Skojarz z podanym adresem i nasłuchuj na nim. Użyj formatu [host]:port dla IPv6</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Nie można uzyskać blokady na katalogu z danymi %s. %s najprawdopodobniej jest już uruchomiony.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Usuwa wszystkie transakcje w portfelu i tylko odtwarza te części z łańcucha bloków poprzez -rescan przy starcie</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Błąd odczytu %s! Wszystkie klucze zostały odczytane poprawnie, ale może brakować  danych transakcji lub wpisów w książce adresowej, lub mogą one być nieprawidłowe.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation type="vanished">Wykonaj polecenie, kiedy transakcja portfela ulegnie zmianie (%s w poleceniu zostanie zastąpione przez TxID)</translation>
    </message>
    <message>
        <source>Please check that your computer&apos;s date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Proszę sprawdzić czy data i czas na Twoim komputerze są poprawne! Jeżeli ustawienia zegara będą złe, %s nie będzie działał prawidłowo.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Ustaw liczbę wątków skryptu weryfikacyjnego (%u do %d, 0 = auto, &lt;0 = zostaw tyle rdzeni wolnych, domyślnie: %d)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening and no -proxy)</source>
        <translation>Użyj UPnP do mapowania portu nasłuchu (domyślnie: 1 gdy nasłuchuje i brak -proxy)</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex-chainstate to change -txindex</source>
        <translation>Musisz przebudować bazę używając -reindex-chainstate aby zmienić -txindex</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s uszkodzony, odtworzenie się nie powiodło</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool musi być przynajmniej %d MB</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; mogą być:</translation>
    </message>
    <message>
        <source>Append comment to the user agent string</source>
        <translation>Dodaj komentarz do pola user agent</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet on startup</source>
        <translation>Próbuj odzyskać klucze prywatne z uszkodzonego portfela podczas uruchamiania.</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Opcje tworzenia bloku:</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: &apos;%s&apos;</source>
        <translation>Nie można rozpoznać -%s adresu: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Opcje połączenia:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Prawa autorskie (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Wykryto uszkodzoną bazę bloków</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Opcje debugowania/testowania:</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Nie ładuj portfela i wyłącz wywołania RPC portfela</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Czy chcesz teraz przebudować bazę bloków?</translation>
    </message>
    <message>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation>Włącz wyświetlanie hasha bloku w &lt;address&gt;</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Błąd inicjowania bazy danych bloków</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Błąd inicjowania środowiska bazy portfela %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Błąd ładowania %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Błąd ładowania %s: Uszkodzony portfel</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Błąd ładowania %s: Portfel wymaga nowszej wersji %s</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Błąd ładowania bazy bloków</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Błąd otwierania bazy bloków</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Błąd: Mało miejsca na dysku!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Próba nasłuchiwania na jakimkolwiek porcie nie powiodła się. Użyj -listen=0 jeśli tego chcesz.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importowanie…</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Nieprawidłowy lub brak bloku genezy. Błędny folder_danych dla sieci?</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Wstępna kontrola poprawności nie powiodła się. %s wyłącza się.</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Nieprawidłowy adres -onion: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Nieprawidłowa kwota dla -%s=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Nieprawidłowa kwota dla -fallbackfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep the transaction memory pool below &lt;n&gt; megabytes (default: %u)</source>
        <translation>Utrzymuj obszar pamięci dla transakcji poniżej &lt;n&gt; MB (default: %u)</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Ładowanie listy zablokowanych...</translation>
    </message>
    <message>
        <source>Location of the auth cookie (default: data dir)</source>
        <translation>Lokalizacja autoryzacyjnego pliku cookie (domyślnie: ścieżka danych)</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Brak wystarczającej liczby deskryptorów plików. </translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Łącz z węzłami tylko w sieci &lt;net&gt; (IPv4, IPv6 lub onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Wyświetl ten tekst pomocy i wyjdź</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Wyświetl wersję i wyjdź</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>Przycinanie nie może być skonfigurowane z negatywną wartością.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>Tryb ograniczony jest niekompatybilny z -txindex.</translation>
    </message>
    <message>
        <source>Rebuild chain state and block index from the blk*.dat files on disk</source>
        <translation>Odbuduj stan lańcucha i indeks bloków z obecnych na dysku plików blk*.dat</translation>
    </message>
    <message>
        <source>Rebuild chain state from the currently indexed blocks</source>
        <translation>Odbuduj stan łańcucha z aktualnie zindeksowanych bloków</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Ustaw wielkość pamięci podręcznej w megabajtach (%d do %d, domyślnie: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Ustaw maksymalną wielkość bloku w bajtach (domyślnie: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Określ plik portfela (w obrębie folderu danych)</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>Kod źródłowy dostępny jest z %s.</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Nie można przywiązać do %s na tym komputerze. %s prawdopodobnie jest już uruchomiony.</translation>
    </message>
    <message>
        <source>Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Niewspierany argument -benchmark zignorowany, użyj -debug=bench.</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Niewspierany argument -debugnet zignorowany, użyj -debug=net.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Znaleziono nieprawidłowy argument -tor, użyj -onion.</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>Użyj UPnP do przekazania portu nasłuchu (domyślnie : %u)</translation>
    </message>
    <message>
        <source>User Agent comment (%s) contains unsafe characters.</source>
        <translation>Komentarz User Agent (%s) zawiera niebezpieczne znaki.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Weryfikacja bloków...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Weryfikacja portfela...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Portfel %s znajduje się poza folderem danych %s</translation>
    </message>
    <message>
        <source>Wallet debugging/testing options:</source>
        <translation>Opcje debugowania/testowania portfela:</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Portfel wymaga przepisania: zrestartuj %s aby ukończyć</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Opcje portfela:</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>Pozwól na połączenia JSON-RPC z podanego źródła. Jako &lt;ip&gt; prawidłowe jest pojedyncze IP (np. 1.2.3.4), podsieć/maska (np. 1.2.3.4/255.255.255.0) lub sieć/CIDR (np. 1.2.3.4/24). Opcja ta może być użyta wiele razy.</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>Podepnij się do podanego adresu i dodawaj do białej listy węzły łączące się z nim. Użyj notacji [host]:port dla IPv6</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Powiąż się z podanym adresem, aby nasłuchiwać połączenia JSON-RPC. Użyj notacji [host]:port dla IPv6. Ta opcja może być określona kilka razy (domyślnie: powiąż ze wszystkimi interfejsami)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Twórz nowe pliki z domyślnymi dla systemu uprawnieniami, zamiast umask 077 (skuteczne tylko przy wyłączonej funkcjonalności portfela)</translation>
    </message>
    <message>
        <source>Discover own IP addresses (default: 1 when listening and no -externalip or -proxy)</source>
        <translation>Odkryj własny adres IP (domyślnie: 1 kiedy w trybie nasłuchu i brak -externalip lub -proxy)</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Błąd: Nasłuchiwanie połączeń przychodzących nie powiodło się (nasłuch zwrócił błąd %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="vanished">Uruchom polecenie przy otrzymaniu odpowiedniego powiadomienia lub gdy zobaczymy naprawdę długie rozgałęzienie (%s w poleceniu jest podstawiane za komunikat)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for relaying, mining and transaction creation (default: %s)</source>
        <translation>Opłaty (w %s/Kb) mniejsze niż ta, będą traktowane jako zerowe przy tworzeniu, przesyłaniu i zatwierdzaniu transakcji (domyślnie: %s)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Jeżeli nie ustawiono paytxfee, dołącz wystarczająca opłatę, aby transakcja mogła zostać zatwierdzona w ciągu średniej ilości n bloków (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Niewłaściwa ilość dla -maxtxfee=&lt;ilość&gt;: &apos;%s&apos; (musi wynosić przynajmniej minimalną wielkość %s aby zapobiec utknięciu transakcji)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maksymalny rozmiar danych w transakcji przekazującej dane które przekazujemy i wydobywamy (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Ustaw maksymalny rozmiar transakcji o wysokim priorytecie/niskiej prowizji w bajtach (domyślnie: %d)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>Zbyt niska kwota transakcji do wysłania po odjęciu opłaty</translation>
    </message>
    <message>
        <source>Use hierarchical deterministic key generation (HD) after BIP32. Only has effect during wallet creation/first start</source>
        <translation>Użyj hierarchicznej deterministycznej metody generowania kluczy (HD) zgodnie z BIP32. Ma znaczenie tylko podczas tworzenia portfela/pierwszego startu.</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Węzły z białej listy nie mogą zostać zbanowane za ataki DoS, a ich transakcje będą zawsze przekazywane, nawet jeżeli będą znajdywać się już w pamięci, przydatne np. dla bramek płatniczych</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(domyślnie: %u)</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Akceptuj publiczne żądania REST (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation>Stwórz automatycznie ukrytą usługę Tora (domyślnie: %d)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Połącz przez SOCKS5 proxy</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Błąd odczytu z bazy danych, wyłączam się.</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file on startup</source>
        <translation>Importuj bloki z zewnętrznego pliku blk000??.dat podczas uruchamiania programu</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation>Nieprawidłowa kwota dla -paytxfee=&lt;amount&gt;: &apos;%s&apos; (musi być co najmniej %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation>Nieprawidłowa maska sieci określona w -whitelist: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Przechowuj w pamięci maksymalnie &lt;n&gt; transakcji nie możliwych do połączenia (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation>Musisz określić port z -whitebind: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Opcje przekaźnikowe węzła:</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>Opcje serwera RPC:</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Zmniejszanie -maxconnections z %d do %d z powodu ograniczeń systemu.</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions on startup</source>
        <translation>Przeskanuj podczas ładowania programu łańcuch bloków w poszukiwaniu zaginionych transakcji portfela</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Wyślij informację/raport do konsoli zamiast do pliku debug.log.</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Wyślij bez opłaty jeżeli to możliwe (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Pokaż wszystkie opcje odpluskwiania (użycie: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Zmniejsz plik debug.log przy starcie programu (domyślnie: 1 jeśli nie użyto -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Podpisywanie transakcji nie powiodło się</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>Zbyt niska kwota transakcji by zapłacić opłatę</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>To oprogramowanie eksperymentalne.</translation>
    </message>
    <message>
        <source>Tor control port password (default: empty)</source>
        <translation>Hasło zabezpieczające portu kontrolnego Tora (domyślnie: puste)</translation>
    </message>
    <message>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation>Port kontrolny sieci Tor jeśli onion listening jest włączone (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Zbyt niska kwota transakcji </translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transakcja jest zbyt duża dla tej opłaty</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transakcja zbyt duża</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Nie można przywiązać do %s na tym komputerze (przywiązanie zwróciło błąd %s)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format on startup</source>
        <translation>Zaktualizuj portfel do najnowszego formatu podczas ładowania programu</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Nazwa użytkownika dla połączeń JSON-RPC</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Usuwam wszystkie transakcje z portfela...</translation>
    </message>
    <message>
        <source>ZeroMQ notification options:</source>
        <translation>Opcje powiadomień ZeroMQ:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Hasło do połączeń JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation type="vanished">Wykonaj polecenie kiedy najlepszy blok ulegnie zmianie (%s w komendzie zastanie zastąpione przez hash bloku)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Zezwól -addnode, -seednode i -connect na łączenie się z serwerem DNS</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Wczytywanie adresów...</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = zachowaj wysłane metadane np. właściciel konta i informacje o żądaniach płatności, 2 = porzuć wysłane metadane)</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee ma ustawioną badzo dużą wartość! Tak wysokie opłaty mogą być zapłacone w jednej transakcji.</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Nie trzymaj w pamięci transakcji starszych niż &lt;n&gt; godz. (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Fees (in %s/kB) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Opłaty (w %s/Kb) mniejsze niż ta będą traktowane jako bez opłaty przy tworzeniu transakcji (domyślnie: %s)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Jak dokładna jest weryfikacja bloków przy -checkblocks (0-4, domyślnie: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Utrzymuj pełny indeks transakcji, używany przy wywołaniu RPC getrawtransaction (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Czas w sekundach, przez jaki nietrzymające się zasad węzły nie będą mogły ponownie się podłączyć (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Wypuść informacje debugowania (domyślnie: %u, podanie &lt;category&gt; jest opcjonalne)</translation>
    </message>
    <message>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation>Wspieraj filtrowanie bloków i transakcji używając Filtrów Blooma (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Total length of network version string (%i) exceeds maximum length (%i). Reduce the number or size of uacomments.</source>
        <translation>Całkowita długość łańcucha wersji (%i) przekracza maksymalną dopuszczalną długość (%i). Zmniejsz ilość lub rozmiar parametru uacomments.</translation>
    </message>
    <message>
        <source>Tries to keep outbound traffic under the given target (in MiB per 24h), 0 = no limit (default: %d)</source>
        <translation>Próbuje utrzymać ruch wychodzący poniżej zadanego (w MiB na 24h), 0 = bez limitu (domyślnie: %d)</translation>
    </message>
    <message>
        <source>Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Znaleziono niewspierany argument -socks. Wybieranie wersji SOCKS nie jest już możliwe, wsparcie programu obejmuje tylko proxy SOCKS5</translation>
    </message>
    <message>
        <source>Unsupported argument -whitelistalwaysrelay ignored, use -whitelistrelay and/or -whitelistforcerelay.</source>
        <translation>Niewspierany argument -whitelistalwaysrelay zignorowany, użyj -whitelistrelay i/lub -whitelistforcerelay.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Użyj oddzielnego prozy SOCKS5 aby osiągnąć węzły w ukrytych usługach Tor (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Warning: Wallet file corrupt, data salvaged! Original %s saved as %s in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Ostrzeżenie: Odtworzono dane z uszkodzonego pliku portfela! Oryginalny %s został zapisany jako %s w %s; jeśli twoje saldo lub transakcje są niepoprawne powinieneś odtworzyć kopię zapasową.</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation>%s jest ustawione bardzo wysoko!</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(domyślnie: %s)</translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Zawsze wypytuj o adresy węzłów poprzez podejrzenie w DNS (domyślnie: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Ile bloków sprawdzić przy starcie (domyślnie: %u, 0 = wszystkie)</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>Dołącz adresy IP do logowania (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Nieprawidłowy adres -proxy: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Nasłuchuj połączeń JSON-RPC na &lt;port&gt; (domyślnie: %u lub testnet: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>Nasłuchuj połączeń na &lt;port&gt; (domyślnie: %u lub testnet: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Utrzymuj maksymalnie &lt;n&gt; połączeń z węzłami (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>Spraw by portfel dokonał transmisji transakcji</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maksymalny bufor odbioru na połączenie, &lt;n&gt;*1000 bajtów (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maksymalny bufor wysyłania na połączenie, &lt;n&gt;*1000 bajtów (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Dołączaj znacznik czasu do logowania (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>Przekazuj i wydobywaj transakcje zawierające dane (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Przekazuj transakcje multisig inne niż P2SH (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Ustaw rozmiar puli kluczy na &lt;n&gt; (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Ustaw liczbę wątków do obsługi RPC (domyślnie: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Wskaż plik konfiguracyjny (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Wskaż czas oczekiwania na połączenie w milisekundach (minimum: 1, domyślnie: %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Wskaż plik pid (domyślnie: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Wydawaj niepotwierdzoną resztę podczas wysyłania transakcji (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Próg, po którym nastąpi rozłączenie węzłów nietrzymających się zasad (domyślnie: %u)</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation>Kwota transakcji musi być dodatnia</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation>Transakcja wymaga co najmniej jednego odbiorcy</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Nieznana sieć w -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Niewystarczające środki</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Ładowanie indeksu bloku...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Dodaj węzeł do podłączenia się i próbuj utrzymać to połączenie</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Wczytywanie portfela...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Nie można dezaktualizować portfela</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Nie można zapisać domyślnego adresu</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Ponowne skanowanie...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Wczytywanie zakończone</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>Bitcoin Core and Bitcoin Turmalina Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-discardthreshold is set very high! This is the output amount that the wallet will discard (to fee) if it is smaller than this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect/-noconnect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered dust, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount under which a transaction output is considered non-standard and will not be accepted or relayed, in %s (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect only to the specified node(s); -noconnect or -connect=0 alone to disable automatic connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equivalent bytes per sigop in transactions for relay and mining (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t enable HD on a already existing non-HD wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash, %i is replaced by block number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extra transactions to keep in memory for compact block reconstructions (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force relay of transactions from whitelisted peers even if they violate local relay policy (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If this block is in the chain assume that it and its ancestors are valid and potentially skip their script verification (0 to verify all, default: %s, testnet: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid amount for -discardthreshold=&lt;amount&gt;: &apos;%s&apos; (must be at least the dust limit of %s to prevent stuck transactions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum allowed median peer time offset adjustment. Local perspective of time may be influenced by peers forward or backward by this amount. (default: %u seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum total fees (in %s) to use in a single wallet transaction or raw transaction; setting this too low may abort large transactions (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect/-noconnect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reduce storage requirements by enabling pruning (deleting) of old blocks. This allows the pruneblockchain RPC to be called to delete specific blocks, and enables automatic pruning of old blocks if a target size in MiB is provided. This mode is incompatible with -txindex and -rescan. Warning: Reverting this setting requires re-downloading the entire blockchain. (default: 0 = disable pruning blocks, 1 = allow manual pruning via RPC, &gt;%u = automatically prune block files to stay under the specified target size in MiB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set lowest fee rate (in %s/kB) for transactions to be included in block creation. (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sets the serialization of raw transaction or block hex returned in non-verbose mode, non-segwit(0) or segwit(1) (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify directory where to write backups and data dumps (default datadir/backups)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer&apos;s date and time being set incorrectly. Only rebuild the block database if you are sure that your computer&apos;s date and time are correct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The minimum transaction output size (in %s) used to validate wallet transactions and discard change (to fee) (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit %s and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard. Paper wallet art provided by Anacoluthia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username and hashed password for JSON-RPC connections. The field &lt;userpw&gt; comes in the format: &lt;USERNAME&gt;:&lt;SALT&gt;$&lt;HASH&gt;. A canonical python script is included in share/rpcuser. The client then connects normally using the rpcuser=&lt;USERNAME&gt;/rpcpassword=&lt;PASSWORD&gt; pair of arguments. This option can be specified multiple times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wallet will not create transactions that violate mempool chain limits (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: Unknown block versions being mined! It&apos;s possible unknown rules are in effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given IP address (e.g. 1.2.3.4) or CIDR notated network (e.g. 1.2.3.0/24). Can be specified multiple times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amaze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chain selection options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change index out of range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable transaction replacement in the memory pool (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error loading %s: You can&apos;t disable HD on a already existing HD wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Many generous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send transactions with full-RBF opt-in enabled (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set maximum BIP141 block weight (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Such expensive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Namecoin-compatible AuxPow API structure, (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the test chain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whether to operate in a blocks only mode (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID, %i with block height, with a value of 0 if tx is no longer in chaintip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable BIP-70 PaymentServer (default: 0)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
